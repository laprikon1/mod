using InnoVault.GameSystem;
using InnoVault.TileProcessors;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using ReLogic.Graphics;
using Steamworks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Terraria;
using Terraria.Audio;
using Terraria.Chat;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.GameContent.Events;
using Terraria.GameContent.ItemDropRules;
using Terraria.GameContent.UI.States;
using Terraria.GameInput;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ModLoader.Core;
using Terraria.ModLoader.IO;
using Terraria.ObjectData;
using Terraria.Social;

namespace InnoVault
{
    /// <summary>
    /// 一个通用的方法库
    /// </summary>
    public static class VaultUtils
    {
        #region Math
        /// <summary>
        /// 弧度分母
        /// </summary>
        public const float atoR = MathHelper.Pi / 180;

        /// <summary>
        /// 表示一个完整的圆周角度（2π），约为 6.2832 弧度
        /// </summary>
        public const float TwoPi = MathF.PI * 2;

        /// <summary>
        /// 表示两个完整的圆周角度（4π），约为 12.5664 弧度
        /// </summary>
        public const float FourPi = MathF.PI * 4;

        /// <summary>
        /// 表示一个半圆周角度（3π），约为 9.4248 弧度
        /// </summary>
        public const float ThreePi = MathF.PI * 3;

        /// <summary>
        /// 表示三分之一圆周角度（π/3），约为 1.0472 弧度（60度）
        /// </summary>
        public const float PiOver3 = MathF.PI / 3f;

        /// <summary>
        /// 表示五分之一圆周角度（π/5），约为 0.6283 弧度（36度）
        /// </summary>
        public const float PiOver5 = MathF.PI / 5f;

        /// <summary>
        /// 表示六分之一圆周角度（π/6），约为 0.5236 弧度（30度）
        /// </summary>
        public const float PiOver6 = MathF.PI / 6f;

        /// <summary>
        /// 二次缓动的入场效果
        /// </summary>
        /// <remarks>该曲线呈加速状态</remarks>
        public static float EaseQuadIn(float x) => x * x;

        /// <summary>
        /// 二次缓动的出场效果
        /// </summary>
        /// <remarks>该曲线呈减速状态</remarks>
        public static float EaseQuadOut(float x) => 1f - EaseQuadIn(1f - x);

        /// <summary>
        /// 二次缓动的入场和出场效果
        /// </summary>
        /// <remarks>前半段为加速，后半段为减速</remarks>
        public static float EaseQuadInOut(float x) => (x < 0.5f) ? 2f * x * x : -2f * x * x + 4f * x - 1f;

        /// <summary>
        /// 三次缓动的入场效果
        /// </summary>
        /// <remarks>该曲线呈加速状态</remarks>
        public static float EaseCubicIn(float x) => x * x * x;

        /// <summary>
        /// 三次缓动的出场效果
        /// </summary>
        /// <remarks>该曲线呈减速状态</remarks>
        public static float EaseCubicOut(float x) => 1f - EaseCubicIn(1f - x);

        /// <summary>
        /// 三次缓动的入场和出场效果
        /// </summary>
        /// <remarks>前半段为加速，后半段为减速</remarks>
        public static float EaseCubicInOut(float x) => (x < 0.5f) ? 4f * x * x * x : 4f * x * x * x - 12f * x * x + 12f * x - 3f;

        /// <summary>
        /// 四次缓动的入场效果
        /// </summary>
        /// <remarks>该曲线呈加速状态</remarks>
        public static float EaseQuarticIn(float x) => x * x * x * x;

        /// <summary>
        /// 四次缓动的出场效果
        /// </summary>
        /// <remarks>该曲线呈减速状态</remarks>
        public static float EaseQuarticOut(float x) => 1f - EaseQuarticIn(1f - x);

        /// <summary>
        /// 四次缓动的入场和出场效果
        /// </summary>
        /// <remarks>前半段为加速，后半段为减速</remarks>
        public static float EaseQuarticInOut(float x) => (x < 0.5f) ? 8f * x * x * x * x : -8f * x * x * x * x + 32f * x * x * x - 48f * x * x + 32f * x - 7f;

        /// <summary>
        /// 五次缓动的入场效果
        /// </summary>
        /// <remarks>该曲线呈加速状态</remarks>
        public static float EaseQuinticIn(float x) => x * x * x * x * x;

        /// <summary>
        /// 五次缓动的出场效果
        /// </summary>
        /// <remarks>该曲线呈减速状态</remarks>
        public static float EaseQuinticOut(float x) => 1f - EaseQuinticIn(1f - x);

        /// <summary>
        /// 五次缓动的入场和出场效果
        /// </summary>
        /// <remarks>前半段为加速，后半段为减速</remarks>
        public static float EaseQuinticInOut(float x) => (x < 0.5f) ? 16f * x * x * x * x * x : 16f * x * x * x * x * x - 80f * x * x * x * x + 160f * x * x * x - 160f * x * x + 80f * x - 15f;

        /// <summary>
        /// 圆形缓动的入场效果
        /// </summary>
        /// <remarks>该曲线模拟圆形运动，呈加速状态</remarks>
        public static float EaseCircularIn(float x) => 1f - (float)Math.Sqrt(1.0 - Math.Pow(x, 2));

        /// <summary>
        /// 圆形缓动的出场效果
        /// </summary>
        /// <remarks>该曲线模拟圆形运动，呈减速状态</remarks>
        public static float EaseCircularOut(float x) => (float)Math.Sqrt(1.0 - Math.Pow(x - 1.0, 2));

        /// <summary>
        /// 圆形缓动的入场和出场效果
        /// </summary>
        /// <remarks>前半段为加速，后半段为减速，模拟圆形运动</remarks>
        public static float EaseCircularInOut(float x) => (x < 0.5f) ? (1f - (float)Math.Sqrt(1.0 - Math.Pow(x * 2, 2))) * 0.5f : (float)((Math.Sqrt(1.0 - Math.Pow(-2 * x + 2, 2)) + 1) * 0.5);

        /// <summary>
        /// 指数缓出函数<br/>
        /// 速度起初极快并迅速减缓，在接近结束时趋于平缓<br/>
        /// 常用于需要强烈减速感的动画
        /// </summary>
        public static float EaseOutExpo(float t) => t >= 1f ? 1f : 1f - (float)Math.Pow(2, -10 * t);

        /// <summary>
        /// 三次缓出函数<br/>
        /// 起初快速加速，随后平滑减速<br/>
        /// 常用于自然的物体停止效果
        /// </summary>
        public static float EaseOutCubic(float t) {
            t = MathHelper.Clamp(t, 0, 1);
            t = 1 - (float)Math.Pow(1 - t, 3);
            return t;
        }

        /// <summary>
        /// 三次缓出函数的简化版<br/>
        /// 功能等同于 EaseOutCubic
        /// </summary>
        public static float EaseOut(float t) {
            return 1f - (float)Math.Pow(1f - t, 3f);
        }

        /// <summary>
        /// 二次缓入函数<br/>
        /// 从慢到快加速，适合平滑启动的动画
        /// </summary>
        public static float EaseInQuad(float t) => t * t;

        /// <summary>
        /// 二次缓出函数<br/>
        /// 从快到慢减速，适合平滑停止的动画
        /// </summary>
        public static float EaseOutQuad(float t) => 1f - (1f - t) * (1f - t);

        /// <summary>
        /// 反向缓入缓出函数<br/>
        /// 在开始和结束阶段略有“回弹”效果<br/>
        /// 常用于强调弹性或动感的过渡
        /// </summary>
        public static float EaseInOutBack(float t) {
            const float c1 = 1.70158f;
            const float c2 = c1 * 1.525f;
            t = MathHelper.Clamp(t, 0, 1);
            return t < 0.5f
                ? (float)(Math.Pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2f
                : (float)(Math.Pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2f;
        }

        /// <summary>
        /// 反向缓出函数<br/>
        /// 在结束阶段会略微超出目标后反弹回终点<br/>
        /// 常用于产生弹性离场的视觉效果
        /// </summary>
        public static float EaseOutBack(float t) {
            const float c1 = 1.70158f;
            const float c3 = c1 + 1f;
            return 1f + c3 * (float)Math.Pow(t - 1, 3) + c1 * (float)Math.Pow(t - 1, 2);
        }

        /// <summary>
        /// 三次缓入缓出函数<br/>
        /// 前半段加速 后半段减速<br/>
        /// 常用于平滑的镜像对称运动
        /// </summary>
        public static float EaseInOutCubic(float t) {
            return t < 0.5f
                ? 4f * t * t * t
                : 1f - (float)Math.Pow(-2f * t + 2f, 3) / 2f;
        }

        /// <summary>
        /// 三次缓入函数<br/>
        /// 起始阶段缓慢 加速度随时间增加
        /// </summary>
        public static float EaseInCubic(float t) {
            return t * t * t;
        }

        /// <summary>
        /// 二次缓入缓出函数<br/>
        /// 前半部分加速 后半部分减速<br/>
        /// 常用于平滑自然的过渡动画
        /// </summary>
        public static float EaseInOutQuad(float t) {
            return t < 0.5f ? 2f * t * t : 1f - (float)Math.Pow(-2f * t + 2f, 2) / 2f;
        }

        /// <summary>
        /// 二次贝塞尔曲线<br/>
        /// 由三个控制点定义的平滑曲线<br/>
        /// 用于简单插值或平滑路径计算
        /// </summary>
        public static Vector2 Bezier(Vector2 a, Vector2 b, Vector2 c, float t) {
            float u = 1f - t;
            return u * u * a + 2f * u * t * b + t * t * c;
        }

        /// <summary>
        /// 三次贝塞尔曲线<br/>
        /// 由四个控制点定义的高阶平滑曲线<br/>
        /// 适用于复杂轨迹与自然运动插值
        /// </summary>
        public static Vector2 CubicBezier(float t, Vector2 p0, Vector2 p1, Vector2 p2, Vector2 p3) {
            float u = 1f - t;
            float tt = t * t;
            float uu = u * u;
            float uuu = uu * u;
            float ttt = tt * t;
            Vector2 p = uuu * p0;
            p += 3f * uu * t * p1;
            p += 3f * u * tt * p2;
            p += ttt * p3;
            return p;
        }

        /// <summary>
        /// 正弦缓出函数<br/>
        /// 使用正弦曲线模拟平滑的停止运动<br/>
        /// 常用于自然的轻缓收尾效果
        /// </summary>
        public static float EaseOutSine(float t) {
            return (float)Math.Sin(t * MathHelper.PiOver2);
        }

        /// <summary>
        /// 弹性缓出函数<br/>
        /// 末段围绕终点衰减振荡后落定，常用于带弹性的弹出与归位<br/>
        /// 输入会被限制在 [0, 1]，两端精确返回 0 与 1
        /// </summary>
        public static float EaseOutElastic(float t) {
            if (t <= 0f) {
                return 0f;
            }
            if (t >= 1f) {
                return 1f;
            }
            const float c4 = TwoPi / 3f;
            return (float)(Math.Pow(2, -10 * t) * Math.Sin((t * 10 - 0.75) * c4) + 1);
        }

        /// <summary>
        /// 两点间简略取值
        /// </summary>
        /// <param name="vr1"></param>
        /// <param name="vr2"></param>
        /// <returns></returns>
        public static Vector2 To(this Vector2 vr1, Vector2 vr2) => vr2 - vr1;

        /// <summary>
        /// 由该实体到目标点的向量
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="targetCenter"></param>
        /// <returns></returns>
        public static Vector2 To(this Entity entity, Vector2 targetCenter) => entity.Center.To(targetCenter);

        /// <summary>
        /// 将一个二维函数填充为三维
        /// </summary>
        /// <param name="vector"></param>
        /// <returns></returns>
        public static Vector3 ToVector3(this Vector2 vector) => new Vector3(vector.X, vector.Y, 0);

        /// <summary>
        /// 将一个二维函数填充为三维
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="fullZ">需要填充的Z轴向量</param>
        /// <returns></returns>
        public static Vector3 ToVector3(this Vector2 vector, float fullZ) => new Vector3(vector.X, vector.Y, fullZ);

        /// <summary>
        /// 简单安全的获取一个单位向量，如果出现非法情况则会返回 <see cref="Vector2.UnitY"/>
        /// </summary>
        public static Vector2 UnitVector(this Vector2 vr) => vr.SafeNormalize(Vector2.UnitY);

        /// <summary>
        /// 获取一个垂直于该向量的单位向量
        /// </summary>
        public static Vector2 GetNormalVector(this Vector2 vr) {
            Vector2 nVr = new(vr.Y, -vr.X);
            return Vector2.Normalize(nVr);
        }

        /// <summary>
        /// 将制定角度转化为指定模长的向量
        /// </summary>
        /// <param name="radius"></param>
        /// <param name="theta"></param>
        /// <returns></returns>
        public static Vector2 RodingToVer(float radius, float theta) => theta.ToRotationVector2() * radius;

        /// <summary>
        /// 随机生成一个二维向量，长度在指定的整数区间 [min, max) 内<br/>
        /// 向量方向均匀分布在单位圆上
        /// </summary>
        /// <param name="min">向量最小长度（包含）</param>
        /// <param name="max">向量最大长度（不包含）</param>
        /// <returns>随机向量</returns>
        public static Vector2 RandVr(int min, int max) {
            return Main.rand.NextVector2Unit() * Main.rand.Next(min, max);
        }

        /// <summary>
        /// 随机生成一个二维向量，长度在 [0, max) 的整数范围内<br/>
        /// 向量方向均匀分布在单位圆上
        /// </summary>
        /// <param name="max">向量最大长度（不包含）</param>
        /// <returns>随机向量</returns>
        public static Vector2 RandVr(int max) {
            return Main.rand.NextVector2Unit() * Main.rand.Next(0, max);
        }

        /// <summary>
        /// 随机生成一个二维向量，长度在指定的浮点区间 [min, max) 内<br/>
        /// 向量方向均匀分布在单位圆上
        /// </summary>
        /// <param name="min">向量最小长度（包含）</param>
        /// <param name="max">向量最大长度（不包含）</param>
        /// <returns>随机向量</returns>
        public static Vector2 RandVr(float min, float max) {
            return Main.rand.NextVector2Unit() * Main.rand.NextFloat(min, max);
        }

        /// <summary>
        /// 随机生成一个二维向量，长度在 [0, max) 的浮点范围内<br/>
        /// 向量方向均匀分布在单位圆上
        /// </summary>
        /// <param name="max">向量最大长度（不包含）</param>
        /// <returns>随机向量</returns>
        public static Vector2 RandVr(float max) {
            return Main.rand.NextVector2Unit() * Main.rand.NextFloat(0, max);
        }

        /// <summary>
        /// 将角度（弧度制）转换为 [0, 1) 的归一化值<br/>
        /// 输入角度可为负数，返回值表示角度在单位圆上的位置比例<br/>
        /// 例如：0 → 0，π → 0.5，2π → 0
        /// </summary>
        /// <param name="radian">输入的角度（弧度制）</param>
        /// <returns>角度归一化后对应的比例（范围 [0, 1)）</returns>
        public static float GetCorrectRadian(float radian) {
            return radian < 0
                ? (MathHelper.TwoPi + radian) / MathHelper.TwoPi
                : radian / MathHelper.TwoPi;
        }

        /// <summary>
        /// 在指定角度范围内生成一个随机方向的向量，并返回指定长度<br/>
        /// 注意：输入的角度为 <b>度数</b> 而非弧度<br/>
        /// 例如：输入 (0, 90, 10)，则返回在第一象限内的一个长度为 10 的随机向量
        /// </summary>
        /// <param name="startAngle">起始角度（度数）</param>
        /// <param name="endAngle">结束角度（度数）</param>
        /// <param name="length">返回向量的长度</param>
        /// <returns>在角度区间内的随机方向向量</returns>
        public static Vector2 RandVrInAngleRange(float startAngle, float endAngle, float length) {
            float range = endAngle - startAngle;
            float angleRad = (startAngle + Main.rand.NextFloat() * range) * MathHelper.Pi / 180f;

            return new Vector2(MathF.Cos(angleRad), MathF.Sin(angleRad)) * length;
        }

        /// <summary>
        /// 色彩混合
        /// </summary>
        /// <param name="percent"></param>
        /// <param name="colors"></param>
        /// <returns></returns>
        public static Color MultiStepColorLerp(float percent, params Color[] colors) {
            if (colors == null || colors.Length == 0) {
                return Color.White;
            }
            if (colors.Length == 1) {
                return colors[0];
            }

            percent = MathHelper.Clamp(percent, 0f, 1f);
            int lastIndex = colors.Length - 1;
            float per = 1f / lastIndex;

            int currentID = Math.Min((int)(percent / per), lastIndex - 1); //防止索引溢出
            float lerpFactor = (percent - per * currentID) / per;

            return Color.Lerp(colors[currentID], colors[currentID + 1], lerpFactor);
        }

        /// <summary>
        /// 检测一个圆形是否与目标矩形相交
        /// </summary>
        /// <param name="circleCenter">圆心的坐标</param>
        /// <param name="radius">圆的半径</param>
        /// <param name="targetRectangle">目标矩形的边界框</param>
        /// <returns>返回 true 如果圆形与矩形相交，否则返回 false</returns>
        public static bool CircleIntersectsRectangle(Vector2 circleCenter, float radius, Rectangle targetRectangle) {
            //计算矩形最近点到圆心的距离
            float nearestX = MathHelper.Clamp(circleCenter.X, targetRectangle.Left, targetRectangle.Right);
            float nearestY = MathHelper.Clamp(circleCenter.Y, targetRectangle.Top, targetRectangle.Bottom);

            //检测最近点与圆心的距离是否小于等于半径
            float deltaX = circleCenter.X - nearestX;
            float deltaY = circleCenter.Y - nearestY;

            return (deltaX * deltaX + deltaY * deltaY) <= (radius * radius);
        }

        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Vector2 topLeft, int width, int height) => new Rectangle((int)topLeft.X, (int)topLeft.Y, width, height);
        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Vector2 topLeft, int size) => new Rectangle((int)topLeft.X, (int)topLeft.Y, size, size);
        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Vector2 topLeft, Vector2 size) => new Rectangle((int)topLeft.X, (int)topLeft.Y, (int)size.X, (int)size.Y);
        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Vector2 topLeft, Point size) => new Rectangle((int)topLeft.X, (int)topLeft.Y, size.X, size.Y);

        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Point16 topLeft, int width, int height) => new Rectangle(topLeft.X, topLeft.Y, width, height);
        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Point16 topLeft, int size) => new Rectangle(topLeft.X, topLeft.Y, size, size);
        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Point16 topLeft, Point16 size) => new Rectangle(topLeft.X, topLeft.Y, size.X, size.Y);
        /// <summary>
        /// 创建一个矩形
        /// </summary>
        public static Rectangle GetRectangle(this Point16 topLeft, Point size) => new Rectangle(topLeft.X, topLeft.Y, size.X, size.Y);

        /// <summary>
        /// 根据两个点创建包含它们的矩形，不要求点顺序，自动判断区域
        /// </summary>
        public static Rectangle GetRectangleFromPoints(this Vector2 p1, Vector2 p2) {
            float x = Math.Min(p1.X, p2.X);
            float y = Math.Min(p1.Y, p2.Y);
            float width = Math.Abs(p1.X - p2.X) + 1;
            float height = Math.Abs(p1.Y - p2.Y) + 1;
            return new Rectangle((int)x, (int)y, (int)width, (int)height);
        }
        /// <summary>
        /// 根据两个点创建包含它们的矩形，不要求点顺序，自动判断区域
        /// </summary>
        public static Rectangle GetRectangleFromPoints(this Point16 p1, Point16 p2) {
            int x = Math.Min(p1.X, p2.X);
            int y = Math.Min(p1.Y, p2.Y);
            int width = Math.Abs(p1.X - p2.X) + 1;
            int height = Math.Abs(p1.Y - p2.Y) + 1;
            return new Rectangle(x, y, width, height);
        }

        /// <summary>
        /// 计算一个渐进速度值
        /// </summary>
        /// <param name="thisCenter">本体位置</param>
        /// <param name="targetCenter">目标位置</param>
        /// <param name="speed">速度</param>
        /// <param name="shutdownDistance">停摆范围</param>
        /// <returns></returns>
        public static float AsymptoticVelocity(this Vector2 thisCenter, Vector2 targetCenter, float speed, float shutdownDistance) {
            Vector2 toMou = targetCenter - thisCenter;
            float thisSpeed = toMou.LengthSquared() > shutdownDistance * shutdownDistance ? speed : MathHelper.Min(speed, toMou.Length());
            return thisSpeed;
        }

        /// <summary>
        /// 平滑地将当前角度旋转到目标角度，限制每次更新的最大变化量
        /// 该方法确保采用最短旋转路径，并正确处理角度环绕
        /// </summary>
        /// <param name="currentAngle">当前角度（弧度）</param>
        /// <param name="targetAngle">目标角度（弧度）</param>
        /// <param name="maxChange">每次更新允许的最大角度变化量（弧度），必须为非负数</param>
        /// <returns>新的角度（弧度），向目标角度靠近但不超过最大变化量</returns>
        /// <remarks>
        /// 此方法适用于游戏或动画中的平滑旋转，例如角色或摄像机的转向
        /// 角度会被归一化到 [-π, π] 范围，以避免大角度值引发的问题
        /// 方法会自动选择最短旋转路径，即使跨越 -π/π 边界
        /// </remarks>
        /// <exception cref="System.ArgumentOutOfRangeException">如果 maxChange 小于 0，则抛出异常</exception>
        public static float RotTowards(this float currentAngle, float targetAngle, float maxChange) {
            if (maxChange < 0f) {
                maxChange *= -1;
            }

            //归一化角度到 [-π, π]
            currentAngle = MathHelper.WrapAngle(currentAngle);
            targetAngle = MathHelper.WrapAngle(targetAngle);

            //计算最短路径的角度差
            float delta = MathHelper.WrapAngle(targetAngle - currentAngle);

            //限制变化量
            delta = MathHelper.Clamp(delta, -maxChange, maxChange);

            //返回新的角度并再次归一化
            return MathHelper.WrapAngle(currentAngle + delta);
        }

        #endregion

        #region System
        /// <summary>
        /// 发送游戏文本并记录日志内容
        /// </summary>
        /// <param name="obj">需要输入的内容</param>
        /// <param name="mod">打印的模组对象，如果为默认值<see langword="null"/>，则不会在日志中输出记录</param>
        public static void LoggerDomp(this object obj, Mod mod = null) {
            string text;
            if (obj == null) {
                text = "ERROR is Null";
            }
            else {
                text = obj.ToString();
            }

            Text(text, Color.Red);

            mod?.Logger.Info(text);
        }

        /// <summary>
        /// 获取当前时间戳字符串（格式：yyyy-MM-dd）
        /// </summary>
        public static string GetTimeStamp() => DateTime.Now.ToString("yyyy-MM-dd");

        /// <summary>
        /// 生成乱码字符串
        /// </summary>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string GenerateRandomString(int length) {
            const string characters = "!@#$%^&*()-_=+[]{}|;:'\",.<>/?`~0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] result = new char[length];

            for (int i = 0; i < length; i++) {
                result[i] = characters[Main.rand.Next(characters.Length)];
            }

            return new string(result);
        }

        /// <summary>
        /// 将比特数组按给定大小进行分割
        /// </summary>
        /// <param name="fullBytes"></param>
        /// <param name="maxChunkSize"></param>
        /// <returns></returns>
        public static List<byte[]> SplitBytes(byte[] fullBytes, int maxChunkSize) {
            List<byte[]> chunks = new();

            int totalLength = fullBytes.Length;
            int offset = 0;

            while (offset < totalLength) {
                int chunkSize = Math.Min(maxChunkSize, totalLength - offset);
                byte[] chunk = new byte[chunkSize];
                Array.Copy(fullBytes, offset, chunk, 0, chunkSize);
                chunks.Add(chunk);
                offset += chunkSize;
            }

            return chunks;
        }

        /// <summary>
        /// 安全地从 <see cref="MemberInfo"/> 获取指定类型的 <see cref="Attribute"/>
        /// </summary>
        /// <typeparam name="T">目标特性类型</typeparam>
        /// <param name="member">要扫描的成员</param>
        /// <param name="onError">错误回调，参数依次是错误类型阶段("metadata"/"instantiate")和异常对象</param>
        /// <returns>找到的特性实例，如果没有或出错则返回 <see langword="null"/></returns>
        public static T GetAttributeSafely<T>(MemberInfo member, Action<string, Exception> onError = null) where T : Attribute {
            try {
                //元数据预筛选
                if (!CustomAttributeData.GetCustomAttributes(member).Any(a => a.AttributeType == typeof(T))) {
                    return null;
                }

                //安全实例化特性
                try {
                    return member.GetCustomAttribute<T>();
                } catch (Exception exAttr) {
                    onError?.Invoke("Instantiate", exAttr);
                    return null;
                }
            } catch (Exception exMeta) {
                onError?.Invoke("Metadata", exMeta);
                return null;
            }
        }

        /// <summary>
        /// 安全地从 <see cref="Type"/> 获取指定类型的 <see cref="Attribute"/>
        /// </summary>
        /// <typeparam name="T">目标特性类型</typeparam>
        /// <param name="type">要扫描的类型</param>
        /// <param name="onError">错误回调，参数依次是错误类型阶段("metadata"/"instantiate")和异常对象</param>
        /// <returns>找到的特性实例，如果没有或出错则返回 <see langword="null"/></returns>
        public static T GetAttributeSafely<T>(Type type, Action<string, Exception> onError = null) where T : Attribute {
            try {
                //元数据预筛选
                if (!CustomAttributeData.GetCustomAttributes(type).Any(a => a.AttributeType == typeof(T))) {
                    return null;
                }

                //安全实例化特性
                try {
                    return type.GetCustomAttribute<T>();
                } catch (Exception exAttr) {
                    onError?.Invoke("Instantiate", exAttr);
                    return null;
                }
            } catch (Exception exMeta) {
                onError?.Invoke("Metadata", exMeta);
                return null;
            }
        }

        /// <summary>
        /// 获取给定类型所有外层类，从最近的到最外层
        /// </summary>
        public static IEnumerable<Type> GetDeclaringTypes(this Type type) {
            var current = type.DeclaringType;
            while (current != null) {
                yield return current;
                current = current.DeclaringType;
            }
        }

        /// <summary>
        /// 构建一个字典，表示每个类型及其直接内部类
        /// </summary>
        public static Dictionary<Type, List<Type>> GetNestedTypeTree(this Type type, BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic) {
            var result = new Dictionary<Type, List<Type>>();
            BuildTree(type, result, flags);
            return result;
        }

        private static void BuildTree(Type type, Dictionary<Type, List<Type>> dict, BindingFlags flags) {
            var nestedTypes = new List<Type>(type.GetNestedTypes(flags));
            dict[type] = nestedTypes;

            foreach (var nested in nestedTypes) {
                BuildTree(nested, dict, flags);
            }
        }

        /// <summary>
        /// 将 <see cref="List{T}"/> 直接序列化为原始字节数组（无额外开销，适合高性能存储）
        /// </summary>
        /// <typeparam name="T">
        /// 必须是值类型（struct），且字段布局为固定大小的非托管类型：<br/>
        /// -不包含引用类型字段（如 string、class、List 等）<br/>
        /// -无自动属性（除非编译器生成的字段也是值类型）<br/>
        /// -建议使用 [StructLayout(LayoutKind.Sequential)] 保证内存布局顺序
        /// </typeparam>
        /// <param name="list">要序列化的结构体列表</param><br/>
        /// <returns>按内存布局直接拷贝生成的字节数组</returns>
        /// <remarks>
        /// 注意事项：<br/>
        /// 1.这是“裸内存拷贝”，不能跨平台传输（不同架构/编译器可能布局不同）<br/>
        /// 2.如果需要跨平台或长期存储，应考虑使用 BinaryWriter 或 protobuf 进行可移植序列化<br/>
        /// 3.如果结构体中有 bool，C# 默认占 1 字节，但对齐填充会增加额外字节<br/>
        /// 4.适合短期内在内存中缓存、或本地快速存取的临时数据<br/>
        /// 5.使用结构体内部不能包含引用类型成员
        /// </remarks>
        public static byte[] SerializeBytes<T>(List<T> list) where T : struct {
            int size = Marshal.SizeOf<T>();
            byte[] data = new byte[list.Count * size];
            T[] array = [.. list];

            var handle = GCHandle.Alloc(array, GCHandleType.Pinned);
            try {
                IntPtr ptr = handle.AddrOfPinnedObject();
                Marshal.Copy(ptr, data, 0, data.Length);
            } finally {
                handle.Free();
            }

            return data;
        }

        /// <summary>
        /// 从原始字节数组直接反序列化为 <see cref="List{T}"/>（必须是与 <see cref="SerializeBytes"/> 相同的类型）
        /// </summary>
        /// <typeparam name="T">
        /// 必须是值类型（struct），且字段布局与生成字节时一致
        /// </typeparam>
        /// <param name="data">原始结构体二进制数据</param>
        /// <returns>还原的结构体列表</returns>
        /// <remarks>
        /// 注意事项：<br/>
        /// 1.必须保证 data.Length 是 Marshal.SizeOf&lt;T&gt; 的整数倍，否则数据会不完整<br/>
        /// 2.读取的结构体必须与写入时的类型完全一致，否则会产生数据错位<br/>
        /// 3.同样不建议用于跨平台或跨版本数据<br/>
        /// 4.使用结构体内部不能包含引用类型成员
        /// </remarks>
        public static List<T> DeserializeBytes<T>(byte[] data) where T : struct {
            int size = Marshal.SizeOf<T>();
            int count = data.Length / size;
            T[] array = new T[count];

            var handle = GCHandle.Alloc(array, GCHandleType.Pinned);
            try {
                IntPtr ptr = handle.AddrOfPinnedObject();
                Marshal.Copy(data, 0, ptr, data.Length);
            } finally {
                handle.Free();
            }

            return [.. array];
        }

        /// <summary>
        /// 按照给定的进度逐步显示文本的一部分
        /// </summary>
        /// <param name="text">要显示的完整文本</param>
        /// <param name="progress">显示进度，范围从 0.0f 到 1.0f，0.0f 表示没有字符，1.0f 表示完整显示</param>
        /// <returns>根据进度显示的部分文本</returns>
        public static string GetTextProgressively(string text, float progress) {
            if (string.IsNullOrEmpty(text)) {
                return string.Empty;
            }
            progress = MathHelper.Clamp(progress, 0.0f, 1.0f);
            int charCountToShow = (int)(text.Length * progress);
            return text.Substring(0, charCountToShow);
        }

        /// <summary>
        /// 将输入文本自动换行以适应指定的最大宽度
        /// </summary>
        /// <param name="text">原始文本</param>
        /// <param name="textSize">文本尺寸（通常由字体测量得出）</param>
        /// <param name="maxWidth">允许的最大宽度</param>
        /// <returns>已处理的自动换行文本</returns>
        public static string WrapTextToWidth(string text, Vector2 textSize, float maxWidth) {
            //将文本转换为字符列表
            List<char> characters = text.ToList();
            List<char> wrappedText = new List<char>();
            float currentWidth = 0;
            float charWidth;

            //遍历每个字符，处理宽度限制与换行逻辑
            foreach (char character in characters) {
                //计算每个字符的平均宽度（假设等宽字体或字符均匀分布）
                charWidth = textSize.X / text.Length;

                //遇到换行符，直接重置当前宽度并加入换行符
                if (character == '\n') {
                    wrappedText.Add(character);
                    currentWidth = 0;
                }
                else {
                    //如果添加当前字符后宽度超出最大限制，插入换行符
                    if (currentWidth + charWidth > maxWidth) {
                        wrappedText.Add('\n');
                        currentWidth = 0;
                    }

                    //添加字符并更新当前宽度
                    wrappedText.Add(character);
                    currentWidth += charWidth;
                }
            }

            //返回处理后的文本
            return new string([.. wrappedText]);
        }

        /// <summary>
        /// 根据当前环境实现网页重定向如果是在Steam环境中，则会通过Steam的内置浏览器打开网页，
        /// 否则使用默认浏览器打开指定的URL
        /// </summary>
        /// <param name="str">要重定向的网页URL</param>
        /// <param name="inSteam">是否在Steam环境下打开（默认为true）</param>
        public static void WebRedirection(this string str, bool inSteam = true) {
            if (SocialAPI.Mode == SocialMode.Steam && inSteam) {
                //如果当前运行环境为Steam，并且指定在Steam中打开，则使用Steam内置浏览器
                SteamFriends.ActivateGameOverlayToWebPage(str);
            }
            else {
                //否则使用系统默认浏览器打开网页
                Utils.OpenToURL(str);
            }
        }

        /// <summary>
        /// 在给定的 Mod 数组中查找包含指定类型的 Mod 实例
        /// </summary>
        /// <param name="type">要查找的类型</param>
        /// <returns>如果找到包含该类型的 Mod，返回对应的 Mod 实例；否则返回 <see langword="null"/></returns>
        public static Mod FindModByType(Type type) => FindModByType(type, ModLoader.Mods);

        /// <summary>
        /// 在给定的 Mod 数组中查找包含指定类型的 Mod 实例
        /// </summary>
        /// <param name="type">要查找的类型</param>
        /// <param name="mods">Mod 实例的数组，用于搜索包含该类型的 Mod</param>
        /// <returns>如果找到包含该类型的 Mod，返回对应的 Mod 实例；否则返回 <see langword="null"/></returns>
        public static Mod FindModByType(Type type, Mod[] mods) {
            foreach (var mod in mods) {
                if (!VaultMod.ModTypeSetCache.TryGetValue(mod.Code, out var typeSet)) {
                    typeSet = [.. mod.GetCodeTypes()];
                    VaultMod.ModTypeSetCache[mod.Code] = typeSet;
                }

                if (typeSet.Contains(type)) {
                    return mod;
                }
            }
            return null;
        }

        /// <summary>
        /// 尝试将指定类型与其所属的 Mod 映射关系添加到字典中
        /// 如果无法找到与该类型对应的 Mod，会抛出异常
        /// </summary>
        /// <param name="typeByModHas">存储类型到 Mod 映射关系的字典</param>
        /// <param name="type">需要映射的类型</param>
        /// <param name="mods">当前已加载的所有 Mod 列表</param>
        /// <exception cref="ArgumentNullException">当无法找到与类型对应的 Mod 时，抛出异常</exception>
        public static void AddTypeModAssociation(Dictionary<Type, Mod> typeByModHas, Type type, Mod[] mods) {
            Mod mod = FindModByType(type, mods);
            if (mod != null) {
                typeByModHas.Add(type, mod);
            }
            else {
                string errorText = "试图添加其所属模组映射时，所属模组为Null";
                string errorText2 = "Attempted to add its associated mod mapping, but the associated mod is null";
                throw new ArgumentNullException(nameof(type), Translation(errorText, errorText2));
            }
        }

        /// <summary>
        /// 获取所有已加载Mod的代码中的所有类型返回一个包含所有类型的数组，
        /// 可以用于反射操作或动态类型检测
        /// </summary>
        /// <returns>所有Mod代码中的可加载类型数组</returns>
        public static Type[] GetAnyModCodeType() {
            if (VaultMod.AnyModCodeType == null) {
                //创建一个存储所有类型的列表
                List<Type> types = [];
                Mod[] mods = ModLoader.Mods;
                //使用 LINQ 将每个Mod的代码程序集中的所有可加载类型平铺到一个集合中
                types.AddRange(mods.SelectMany(mod => AssemblyManager.GetLoadableTypes(mod.Code)));
                VaultMod.AnyModCodeType = [.. types];
            }

            return VaultMod.AnyModCodeType;
        }

        /// <summary>
        /// 获取指定模组程序集中的全部可加载类型，同一个程序集只会枚举一次<br/>
        /// 返回的集合是共享缓存，不要修改；缓存会在加载完成与卸载时释放，之后再次调用会重建
        /// </summary>
        /// <param name="mod">目标模组，没有代码程序集时得到空集合</param>
        public static IReadOnlyList<Type> GetCodeTypes(this Mod mod) {
            Assembly code = mod?.Code;
            if (code == null) {
                return [];
            }

            if (!VaultMod.ModTypeArrayCache.TryGetValue(code, out Type[] types)) {
                types = AssemblyManager.GetLoadableTypes(code);
                VaultMod.ModTypeArrayCache[code] = types;
            }
            return types;
        }

        /// <summary>
        /// 在指定模组中按类型名查找类型，常用于不引用对方程序集时的反射对接<br/>
        /// 只含简名（如 <c>"ThoriumPlayer"</c>）时走缓存的简名索引，简名重复时取程序集内最先出现的那个；
        /// 含 <c>.</c> 时按全名（命名空间加类型名，嵌套类型用 <c>+</c>）精确查找
        /// </summary>
        /// <param name="mod">目标模组</param>
        /// <param name="typeName">类型简名或全名</param>
        /// <returns>找到的类型，模组为空、没有代码程序集或没有该类型时返回 <see langword="null"/></returns>
        public static Type FindTypeByName(this Mod mod, string typeName) {
            Assembly code = mod?.Code;
            if (code == null || string.IsNullOrEmpty(typeName)) {
                return null;
            }

            if (typeName.Contains('.')) {
                return code.GetType(typeName, false);
            }

            if (!VaultMod.ModTypeNameCache.TryGetValue(code, out var byName)) {
                byName = new Dictionary<string, Type>(StringComparer.Ordinal);
                foreach (Type type in mod.GetCodeTypes()) {
                    byName.TryAdd(type.Name, type);
                }
                VaultMod.ModTypeNameCache[code] = byName;
            }
            return byName.GetValueOrDefault(typeName);
        }

        /// <summary>
        /// 获取指定基类的所有子类列表
        /// </summary>
        /// <param name="baseType">基类的类型</param>
        /// <returns>子类列表</returns>
        [Obsolete("已过时 使用 VaultUtils.GetDerivedTypes")]
        public static List<Type> GetSubclassTypeList(Type baseType) {
            List<Type> subclasses = [];
            Type[] allTypes = GetAnyModCodeType();

            foreach (Type type in allTypes) {
                if (type.IsClass && !type.IsAbstract && baseType.IsAssignableFrom(type)) {
                    subclasses.Add(type);
                }
            }

            return subclasses;
        }

        /// <summary>
        /// 根据给定的类型列表，创建符合条件的类型实例，并将实例添加到输出列表中，该方法默认要求类型拥有无参构造
        /// </summary>
        [Obsolete("已经过时，使用 VaultUtils.GetDerivedInstances")]
        public static List<T> GetSubclassInstances<T>(bool parameterless = true) {
            List<Type> inTypes = GetSubclassTypeList(typeof(T));
            List<T> outInds = [];
            foreach (Type type in inTypes) {
                if (type != typeof(T)) {
                    object obj = parameterless ? Activator.CreateInstance(type) : RuntimeHelpers.GetUninitializedObject(type);
                    if (obj is T inds) {
                        outInds.Add(inds);
                    }
                }
            }
            return outInds;
        }

        /// <summary>
        /// 获取当前程序集（Assembly）中实现了指定接口（通过接口名称 `lname` 指定）的所有类的实例列表
        /// </summary>
        /// <typeparam name="T">接口类型，用于检查类是否实现该接口</typeparam>
        /// <returns>一个包含所有实现了指定接口的类实例的列表</returns>
        [Obsolete("已经过时，使用 VaultUtils.GetDerivedInstances")]
        public static List<T> GetSubInterface<T>() {
            string lname = typeof(T).Name;
            List<T> subInterface = new List<T>();
            Type[] allTypes = GetAnyModCodeType();

            foreach (Type type in allTypes) {
                if (type.IsClass && !type.IsAbstract && type.GetInterface(lname) != null) {
                    object obj = RuntimeHelpers.GetUninitializedObject(type);
                    if (obj is T instance) {
                        subInterface.Add(instance);
                    }
                }
            }

            return subInterface;
        }

        /// <summary>
        /// 获取程序集中指定基类型（类或接口）的集合
        /// </summary>
        /// <typeparam name="TBase">基类型，可以是类或接口</typeparam>
        /// <param name="allTypes">目标类型集合，默认为<see langword="null"/>，即自动初始化为全部模组的可加载类型</param>
        /// <returns>一个包含所有符合条件的实例的列表</returns>
        public static IList<Type> GetDerivedTypes<TBase>(Type[] allTypes = null) {
            IList<Type> types = [];
            Type baseType = typeof(TBase);

            allTypes ??= GetAnyModCodeType();

            foreach (Type type in allTypes) {
                //核心筛选逻辑:
                //类型必须是类 (IsClass)
                //类型不能是抽象类 (!IsAbstract)
                //类型必须可以赋值给 TBase (IsAssignableFrom)，这同时适用于类继承和接口实现
                //类型不能是基类型本身 (type != baseType)，避免自己实例化自己
                if (!type.IsClass || type.IsAbstract || !baseType.IsAssignableFrom(type) || type == baseType) {
                    continue;
                }

                types.Add(type);
            }

            return types;
        }

        /// <summary>
        /// 获取程序集中指定基类型（类或接口）的所有可实例化的派生类/实现类的实例
        /// </summary>
        /// <typeparam name="TBase">基类型，可以是类或接口</typeparam>
        /// <param name="allTypes">目标类型集合，默认为<see langword="null"/>，即自动初始化为全部模组的可加载类型</param>
        /// <param name="useUnsafeInitialization">如果为 true，则跳过构造函数；否则调用无参构造函数</param>
        /// <returns>一个包含所有符合条件的实例的列表</returns>
        public static List<TBase> GetDerivedInstances<TBase>(Type[] allTypes = null, bool useUnsafeInitialization = false) {
            List<TBase> instances = [];
            foreach (Type type in GetDerivedTypes<TBase>(allTypes)) {
                try {
                    object obj;
                    if (useUnsafeInitialization) {
                        obj = RuntimeHelpers.GetUninitializedObject(type);
                    }
                    else {
                        //确保有无参构造函数才进行创建
                        if (type.GetConstructor(Type.EmptyTypes) == null) {
                            VaultMod.LoggerError($"GetDerivedInstances:{type.GetHashCode()}", $"Type {type.Name} does not have a parameterless constructor and was skipped.");
                            continue;
                        }
                        obj = Activator.CreateInstance(type);
                    }

                    if (obj is TBase instance) {
                        instances.Add(instance);
                    }
                } catch (Exception ex) {
                    VaultMod.LoggerError($"GetDerivedInstances:{type.GetHashCode()}", $"Failed to create instance of type {type.Name}. Error: {ex.Message}");
                }
            }

            return instances;
        }

        /// <summary>
        /// 异步等待直到指定条件返回真或超时，期间以固定时间间隔检查条件状态<br/>
        /// 超时则通过取消令牌触发任务取消，适用于非阻塞等待某个状态的场景
        /// </summary>
        /// <param name="condition">判断是否满足等待结束的条件委托</param>
        /// <param name="checkIntervalMs">检查条件的时间间隔，单位毫秒，默认50毫秒</param>
        /// <param name="timeoutMs">等待的最大超时时间，单位毫秒，默认无限等待</param>
        public static async Task WaitUntilAsync(Func<bool> condition, int checkIntervalMs = 50, int timeoutMs = Timeout.Infinite) {
            var cancellationTokenSource = new CancellationTokenSource();
            if (timeoutMs != Timeout.Infinite) {
                cancellationTokenSource.CancelAfter(timeoutMs);
            }

            while (!condition()) {
                await Task.Delay(checkIntervalMs, cancellationTokenSource.Token);
            }
        }

        /// <summary>
        /// 如果目标文件不存在，则从指定Mod的内部资源复制文件到目标路径
        /// 同时会删除旧版本文件，包括无版本号视为 v0 的旧文件
        /// </summary>
        /// <param name="modName">模组内部名</param>
        /// <param name="resourcePath">模组内资源路径</param>
        /// <param name="targetPath">最终要保存的绝对路径</param>
        public static void EnsureFileFromMod(string modName, string resourcePath, string targetPath) {
            if (string.IsNullOrEmpty(modName)) {
                throw new ArgumentNullException(nameof(modName), "Mod name cannot be null or empty.");
            }
            if (string.IsNullOrEmpty(resourcePath)) {
                throw new ArgumentNullException(nameof(resourcePath), "Resource path cannot be null or empty.");
            }
            if (string.IsNullOrEmpty(targetPath)) {
                throw new ArgumentNullException(nameof(targetPath), "Target path cannot be null or empty.");
            }

            var mod = ModLoader.GetMod(modName) ?? throw new ArgumentException($"Mod '{modName}' not found.", nameof(modName));
            mod.EnsureFileFromMod(resourcePath, targetPath);
        }

        /// <summary>
        /// 如果目标文件不存在，则从指定Mod的内部资源复制文件到目标路径
        /// 同时会删除旧版本文件，包括无版本号视为 v0 的旧文件
        /// </summary>
        public static void EnsureFileFromMod(this Mod mod, string resourcePath, string targetPath) {
            if (mod == null) {
                throw new ArgumentNullException(nameof(mod), "Mod cannot be null.");
            }
            if (string.IsNullOrEmpty(resourcePath)) {
                throw new ArgumentNullException(nameof(resourcePath), "Resource path cannot be null or empty.");
            }
            if (string.IsNullOrEmpty(targetPath)) {
                throw new ArgumentNullException(nameof(targetPath), "Target path cannot be null or empty.");
            }

            try {
                if (!File.Exists(targetPath)) {
                    string directory = Path.GetDirectoryName(targetPath);
                    if (!string.IsNullOrEmpty(directory)) {
                        Directory.CreateDirectory(directory);
                    }

                    TryDeleteOldVersionFiles(targetPath);

                    using Stream modStream = mod.GetFileStream(resourcePath, true)
                        ?? throw new FileNotFoundException($"Resource '{resourcePath}' not found in mod '{mod.Name}'.");
                    using FileStream outputStream = File.Create(targetPath);
                    modStream.CopyTo(outputStream);
                }
            } catch (Exception ex) {
                VaultMod.Instance?.Logger?.Error($"Failed to ensure file from mod: {targetPath}\n{ex}");
                throw;
            }
        }

        /// <summary>
        /// 删除旧版本的同名文件，当前文件保留，其它旧版（包括无版本号视作v0）自动删除
        /// </summary>
        public static void TryDeleteOldVersionFiles(string targetPath) {
            try {
                string directory = Path.GetDirectoryName(targetPath);
                if (!Directory.Exists(directory)) {
                    VaultMod.Instance?.Logger?.Warn($"Directory does not exist: {directory}");
                    return;
                }

                string fileName = Path.GetFileNameWithoutExtension(targetPath);
                string extension = Path.GetExtension(targetPath);

                var match = Regex.Match(fileName, @"^(.+?)_v(\d+)$", RegexOptions.IgnoreCase);
                if (!match.Success) {
                    return;
                }

                string baseName = match.Groups[1].Value;
                if (!int.TryParse(match.Groups[2].Value, out int currentVersion)) {
                    VaultMod.Instance?.Logger?.Warn($"Invalid version number in file: {targetPath}");
                    return;
                }

                string[] files = Directory.GetFiles(directory, $"{baseName}*{extension}");
                foreach (string file in files) {
                    string otherName = Path.GetFileNameWithoutExtension(file);
                    if (file.Equals(targetPath, StringComparison.OrdinalIgnoreCase)) {
                        continue;
                    }

                    var otherMatch = Regex.Match(otherName, @$"^{Regex.Escape(baseName)}_v(\d+)$", RegexOptions.IgnoreCase);
                    if (otherMatch.Success) {
                        if (int.TryParse(otherMatch.Groups[1].Value, out int version) && version < currentVersion) {
                            TryDelete(file);
                        }
                    }
                    else if (otherName == baseName) {
                        TryDelete(file);
                    }
                }
            } catch (Exception ex) {
                VaultMod.LoggerError("@TryDeleteOldVersionFiles:Exception", $"Failed to delete old version files for: {targetPath}\n{ex}");
            }
        }

        private static void TryDelete(string filePath) {
            try {
                File.Delete(filePath);
            } catch (UnauthorizedAccessException) {
                VaultMod.LoggerError("@TryDelete:UnauthorizedAccessException", $"Access denied when deleting file: {filePath}");
            } catch (IOException ex) {
                VaultMod.LoggerError("@TryDelete:IOException", $"IO error when deleting file: {filePath}. It may be in use.\n{ex}");
            } catch (Exception ex) {
                VaultMod.LoggerError("@TryDelete:Exception", $"Unexpected error when deleting file: {filePath}\n{ex}");
            }
        }

        #endregion

        #region AI

        /// <summary>
        /// 让弹幕进行爆炸效果的操作
        /// </summary>
        /// <param name="projectile">要爆炸的投射物</param>
        /// <param name="blastRadius">爆炸效果的半径（默认为 120 单位）</param>
        /// <param name="explosionSound">爆炸声音的样式（默认为默认的爆炸声音）</param>
        /// <param name="spanSound">是否自行播放声音，默认为<see langword="true"/></param>
        public static void Explode(this Projectile projectile, int blastRadius = 120, SoundStyle explosionSound = default, bool spanSound = true) {
            Vector2 originalPosition = projectile.position;
            int originalWidth = projectile.width;
            int originalHeight = projectile.height;

            if (spanSound) {
                _ = SoundEngine.PlaySound(explosionSound == default ? SoundID.Item14 : explosionSound, projectile.Center);
            }

            projectile.position = projectile.Center;
            projectile.width = projectile.height = blastRadius * 2;
            projectile.position.X -= projectile.width / 2;
            projectile.position.Y -= projectile.height / 2;

            projectile.maxPenetrate = -1;
            projectile.penetrate = -1;
            projectile.usesLocalNPCImmunity = true;
            projectile.localNPCHitCooldown = -1;

            projectile.Damage();

            projectile.position = originalPosition;
            projectile.width = originalWidth;
            projectile.height = originalHeight;
        }

        /// <summary>
        /// 普通的追逐行为
        /// </summary>
        /// <param name="entity">需要操纵的实体</param>
        /// <param name="TargetCenter">目标地点</param>
        /// <param name="Speed">速度</param>
        /// <param name="ShutdownDistance">停摆距离</param>
        /// <returns></returns>
        public static Vector2 ChasingBehavior(this Entity entity, Vector2 TargetCenter, float Speed, float ShutdownDistance = 16) {
            if (entity == null) {
                return Vector2.Zero;
            }

            Vector2 ToTarget = TargetCenter - entity.Center;
            Vector2 ToTargetNormalize = ToTarget.SafeNormalize(Vector2.Zero);
            Vector2 speed = ToTargetNormalize * entity.Center.AsymptoticVelocity(TargetCenter, Speed, ShutdownDistance);
            entity.velocity = speed;
            return speed;
        }

        /// <summary>
        /// 更加缓和的追逐行为
        /// </summary>
        /// <param name="entity">需要操纵的实体</param>
        /// <param name="TargetCenter">目标地点</param>
        /// <param name="SpeedUpdates">速度的更新系数</param>
        /// <param name="HomingStrenght">追击力度</param>
        /// <returns></returns>
        public static Vector2 SmoothHomingBehavior(this Entity entity, Vector2 TargetCenter, float SpeedUpdates = 1, float HomingStrenght = 0.1f) {
            float targetAngle = entity.AngleTo(TargetCenter);
            float f = entity.velocity.ToRotation().RotTowards(targetAngle, HomingStrenght);
            Vector2 speed = f.ToRotationVector2() * entity.velocity.Length() * SpeedUpdates;
            entity.velocity = speed;
            return speed;
        }

        /// <summary>
        /// 寻找必要的玩家目标
        /// </summary>
        /// <param name="npc"></param>
        /// <returns></returns>
        public static Player FindPlayer(this NPC npc) {
            if (npc.target < 0 || npc.target >= 255 || !Main.player[npc.target].Alives()) {
                npc.FindClosestPlayer();
            }
            if (npc.target < 0 || npc.target >= 255 || !Main.player[npc.target].Alives()) {
                npc.target = 0;
            }
            return Main.player[npc.target];
        }

        /// <summary>
        /// 寻找距离指定位置最近的NPC
        /// </summary>
        /// <param name="origin">开始搜索的位置</param>
        /// <param name="maxDistanceToCheck">搜索NPC的最大距离</param>
        /// <param name="ignoreTiles">在检查障碍物时是否忽略瓦片</param>
        /// <param name="bossPriority">是否优先选择Boss</param>
        /// <param name="onHitNPCs">排除的NPC列表</param>
        /// <param name="chasedByNPC">额外的条件过滤，用于判断NPC是否应被考虑，如果该委托不为<see langword="null"/> 那么它的返回值将覆盖其他的筛选结果</param>
        /// <returns>距离最近的NPC</returns>
        public static NPC FindClosestNPC(this Vector2 origin, float maxDistanceToCheck, bool ignoreTiles = true
            , bool bossPriority = false, IEnumerable<NPC> onHitNPCs = null, Func<NPC, bool> chasedByNPC = null) {
            NPC closestTarget = null;
            float distance = maxDistanceToCheck;
            bool bossFound = false;

            foreach (var npc in Main.ActiveNPCs) {
                bool canChased = npc.CanBeChasedBy();
                if (onHitNPCs != null && onHitNPCs.Contains(npc)) {
                    canChased = false;
                }

                //Boss优先选择逻辑
                if (bossPriority && bossFound && !npc.boss && npc.type != NPCID.WallofFleshEye) {
                    canChased = false;
                }

                if (chasedByNPC != null && !chasedByNPC.Invoke(npc)) {
                    canChased = false;
                }

                if (!canChased) {
                    continue;
                }

                //计算NPC与起点的距离
                float extraDistance = (npc.width / 2f) + (npc.height / 2f);
                float actualDistance = Vector2.Distance(origin, npc.Center);

                //更新最近目标，瓦片阻挡的射线检测要沿途逐格取物块，只对已经在范围内的目标做
                if (actualDistance < distance + extraDistance && (ignoreTiles || Collision.CanHit(origin, 1, 1, npc.Center, 1, 1))) {
                    if (bossPriority && (npc.boss || npc.type == NPCID.WallofFleshEye)) {
                        bossFound = true;
                    }
                    distance = actualDistance;
                    closestTarget = npc;
                }
            }

            return closestTarget;
        }

        /// <summary>
        /// 尝试寻找距离指定位置最近的NPC
        /// </summary>
        /// <param name="origin">开始搜索的位置</param>
        /// <param name="npc">返回找到的NPC</param>
        /// <param name="maxDistanceToCheck">搜索NPC的最大距离</param>
        /// <param name="ignoreTiles">在检查障碍物时是否忽略瓦片</param>
        /// <param name="bossPriority">是否优先选择Boss</param>
        /// <param name="onHitNPCs">排除的NPC列表</param>
        /// <param name="chasedByNPC">额外的条件过滤，用于判断NPC是否应被考虑，如果该委托不为<see langword="null"/> 那么它的返回值将覆盖其他的筛选结果</param>
        /// <returns>是否成功找到NPC</returns>
        public static bool TryFindClosestNPC(this Vector2 origin, out NPC npc, float maxDistanceToCheck, bool ignoreTiles = true,
            bool bossPriority = false, IEnumerable<NPC> onHitNPCs = null, Func<NPC, bool> chasedByNPC = null) {
            npc = origin.FindClosestNPC(maxDistanceToCheck, ignoreTiles, bossPriority, onHitNPCs, chasedByNPC);
            return npc != null;
        }

        /// <summary>
        /// 寻找距离指定位置最近的玩家
        /// </summary>
        /// <param name="position">搜索起点</param>
        /// <param name="maxRange">最大搜索距离；如果为-1，则忽略范围限制</param>
        /// <param name="ignoreTiles">是否忽略瓦片遮挡</param>
        /// <param name="playerFilter">额外的玩家过滤器；若不为 <see langword="null"/>，将根据此委托结果决定玩家是否被考虑</param>
        /// <returns>距离最近的玩家；若无匹配玩家，返回 <see langword="null"/></returns>
        public static Player FindClosestPlayer(this Vector2 position, float maxRange = 3000f, bool ignoreTiles = true, Func<Player, bool> playerFilter = null) {
            Player closestPlayer = null;
            float minDistance = maxRange == -1f ? float.MaxValue : maxRange;

            foreach (Player player in Main.ActivePlayers) {
                if (!player.Alives()) {
                    continue;
                }

                if (playerFilter != null && !playerFilter(player)) {
                    continue;
                }

                float distance = Vector2.Distance(position, player.Center);

                if (distance <= minDistance) {
                    bool canHit = ignoreTiles || Collision.CanHit(position, 1, 1, player.Center, 1, 1);

                    if (canHit) {
                        minDistance = distance;
                        closestPlayer = player;
                    }
                }
            }

            return closestPlayer;
        }

        /// <summary>
        /// 尝试寻找距离指定位置最近的玩家
        /// </summary>
        /// <param name="position">搜索起点</param>
        /// <param name="player">返回找到的玩家</param>
        /// <param name="maxRange">最大搜索距离；如果为-1，则忽略范围限制</param>
        /// <param name="ignoreTiles">是否忽略瓦片遮挡</param>
        /// <param name="playerFilter">玩家过滤条件</param>
        /// <returns>是否成功找到玩家</returns>
        public static bool TryFindClosestPlayer(this Vector2 position, out Player player, float maxRange = 3000f, bool ignoreTiles = true, Func<Player, bool> playerFilter = null) {
            player = position.FindClosestPlayer(maxRange, ignoreTiles, playerFilter);
            return player != null;
        }

        /// <summary>
        /// 寻找距离指定位置最近的箱子
        /// </summary>
        /// <param name="point">搜索起点，单位为物块</param>
        /// <param name="maxRange">最大搜索距离；如果为-1，则忽略范围限制，单位为像素</param>
        /// <param name="ignoreTiles">是否忽略瓦片遮挡</param>
        /// <param name="chestFilter">可选的箱子过滤器；若为 <see langword="null"/> 则不过滤</param>
        /// <returns>距离最近且符合条件的 <see cref="Chest"/>，若无匹配项则为  <see langword="null"/></returns>
        public static Chest FindClosestChest(this Point16 point, float maxRange = 3000f, bool ignoreTiles = true, Func<Chest, bool> chestFilter = null)
            => FindClosestChest(point.ToWorldCoordinates(), maxRange, ignoreTiles, chestFilter);

        /// <summary>
        /// 寻找距离指定位置最近的箱子
        /// </summary>
        /// <param name="point">搜索起点，单位为物块</param>
        /// <param name="chest">返回的箱子实例</param>
        /// <param name="maxRange">最大搜索距离；如果为-1，则忽略范围限制，单位为像素</param>
        /// <param name="ignoreTiles">是否忽略瓦片遮挡</param>
        /// <param name="chestFilter">可选的箱子过滤器；若为 <see langword="null"/> 则不过滤</param>
        /// <returns>距离最近且符合条件的 <see cref="Chest"/>，若无匹配项则为  <see langword="null"/></returns>
        public static bool TryFindClosestChest(this Point16 point, out Chest chest, float maxRange = 3000f, bool ignoreTiles = true, Func<Chest, bool> chestFilter = null) {
            chest = FindClosestChest(point, maxRange, ignoreTiles, chestFilter);
            return chest != null;
        }

        /// <summary>
        /// 寻找距离指定位置最近的箱子
        /// </summary>
        /// <param name="position">搜索起点，单位为像素</param>
        /// <param name="maxRange">最大搜索距离；如果为-1，则忽略范围限制，单位为像素</param>
        /// <param name="ignoreTiles">是否忽略瓦片遮挡</param>
        /// <param name="chestFilter">可选的箱子过滤器；若为 <see langword="null"/> 则不过滤</param>
        /// <returns>距离最近且符合条件的 <see cref="Chest"/>，若无匹配项则为  <see langword="null"/></returns>
        public static Chest FindClosestChest(this Vector2 position, float maxRange = 3000f, bool ignoreTiles = true, Func<Chest, bool> chestFilter = null) {
            Chest closestChest = null;
            float minDistance = maxRange == -1f ? float.MaxValue : maxRange;

            foreach (Chest chest in Main.chest) {
                if (chest == null) {
                    continue;
                }

                if (chestFilter != null && !chestFilter(chest)) {
                    continue;
                }

                //箱子位置为左上角 Tile，需转换为世界坐标
                Vector2 chestWorldPos = new(chest.x * 16 + 8, chest.y * 16 + 8); //中心点

                float distance = Vector2.Distance(position, chestWorldPos);
                if (distance <= minDistance) {
                    bool canReach = ignoreTiles || Collision.CanHitLine(position, 0, 0, chestWorldPos, 0, 0);

                    if (canReach) {
                        minDistance = distance;
                        closestChest = chest;
                    }
                }
            }

            return closestChest;
        }

        /// <summary>
        /// 寻找距离指定位置最近的箱子
        /// </summary>
        /// <param name="position">搜索起点，单位为像素</param>
        /// <param name="chest">返回的箱子实例</param>
        /// <param name="maxRange">最大搜索距离；如果为-1，则忽略范围限制，单位为像素</param>
        /// <param name="ignoreTiles">是否忽略瓦片遮挡</param>
        /// <param name="chestFilter">可选的箱子过滤器；若为 <see langword="null"/> 则不过滤</param>
        /// <returns>距离最近且符合条件的 <see cref="Chest"/>，若无匹配项则为  <see langword="null"/></returns>
        public static bool TryFindClosestChest(Vector2 position, out Chest chest, float maxRange = 3000f, bool ignoreTiles = true, Func<Chest, bool> chestFilter = null) {
            chest = FindClosestChest(position, maxRange, ignoreTiles, chestFilter);
            return chest != null;
        }

        /// <summary>
        /// 尝试移除指定位置的箱子，并返回箱子内的所有物品（包括可选的箱子本身）
        /// </summary>
        /// <param name="point">目标 Tile 坐标，可以是箱子任意一格</param>
        /// <param name="items">返回被取出的物品列表（包含箱子本体时也会返回）</param>
        /// <param name="ignoreLocked">是否忽略上锁状态（<see langword="true"/> 时无视锁定直接移除）</param>
        /// <param name="dropChest"><see langword="true"/> 表示不额外掉落箱子物品，仅破坏箱子 <br/>(注:未起作用，箱子因为是多结构物块仍旧会掉落)；<br/>
        /// <see langword="false"/> 则将箱子本身加入掉落列表</param>
        /// <param name="netUpdate">多人模式下是否同步更新</param>
        /// <returns>
        /// <see langword="true"/> 表示箱子已成功移除并返回物品；<see langword="false"/> 表示操作失败（位置无效、未找到箱子、被锁定等）
        /// </returns>
        public static bool TryKillChest(Point16 point, out List<Item> items, bool ignoreLocked = false, bool dropChest = false, bool netUpdate = true) {
            //初始化返回列表
            items = [];

            //获取该位置箱子的左上角坐标（支持多格箱子）
            Point16? topLeft = GetTopLeftOrNull(point);
            if (topLeft == null) {
                return false;
            }

            point = topLeft.Value;

            //获取箱子索引
            int chestIndex = Chest.FindChest(point.X, point.Y);
            if (chestIndex == -1 || !Main.chest.IndexInRange(chestIndex)) {
                return false;
            }

            Chest chest = Main.chest[chestIndex];
            if (chest == null) {
                return false;
            }

            //检查锁定状态
            if (!ignoreLocked && Chest.IsLocked(chest.x, chest.y)) {
                return false;
            }

            //确保物品数组存在
            if (chest.item == null) {
                return false;
            }

            //复制并清空箱子物品
            for (int i = 0; i < Chest.maxItems; i++) {
                if (chest.item[i].IsAir) {
                    continue;
                }

                items.Add(chest.item[i].Clone());
                chest.item[i] = new Item();
            }

            //如果允许掉落箱子本身，将其加入掉落列表
            if (!dropChest) {
                int itemID = GetTileDrop(Framing.GetTileSafely(point));
                items.Add(new Item(itemID));
            }

            //破坏箱子 Tile
            WorldGen.KillTile(point.X, point.Y, noItem: !dropChest);

            //同步更新
            if (netUpdate && isSinglePlayer) {
                for (int i = 0; i < Chest.maxItems; i++) {
                    NetMessage.SendData(MessageID.SyncChestItem, -1, -1, null, chestIndex, i);
                }

                NetMessage.SendTileSquare(Main.myPlayer, point.X, point.Y);
            }

            return true;
        }

        /// <summary>
        /// 检测玩家是否有效且正常存活
        /// </summary>
        /// <returns>返回 <see langword="true"/> 表示活跃，返回 <see langword="false"/> 表示为空或者已经死亡的非活跃状态</returns>
        public static bool Alives(this Player player) => player != null && player.active && !player.dead;

        /// <summary>
        /// 检测弹幕是否有效且正常存活
        /// </summary>
        /// <returns>返回 <see langword="true"/> 表示活跃，返回 <see langword="false"/> 表示为空或者已经死亡的非活跃状态</returns>
        public static bool Alives(this Projectile projectile) => projectile != null && projectile.active && projectile.timeLeft > 0;

        /// <summary>
        /// 检测NPC是否有效且正常存活
        /// </summary>
        /// <returns>返回 <see langword="true"/> 表示活跃，返回 <see langword="false"/> 表示为空或者已经死亡的非活跃状态</returns>
        public static bool Alives(this NPC npc) => npc != null && npc.active && npc.timeLeft > 0;

        /// <summary>
        /// 检测物品是否有效且正常存活
        /// </summary>
        /// <returns>返回 <see langword="true"/> 表示活跃，返回 <see langword="false"/> 表示为空或者已经死亡的非活跃状态</returns>
        public static bool Alives(this Item item) => item != null && item.type > ItemID.None && item.stack > 0;

        #endregion

        #region Game
        /// <summary>
        /// 根据<see cref="Item.useAmmo"/>映射到对应的物品id之上
        /// </summary>
        public static Dictionary<int, int> AmmoIDToItemIDMapping { get; private set; } = new Dictionary<int, int>
        {
            { AmmoID.FallenStar, ItemID.FallenStar },
            { AmmoID.Gel, ItemID.Gel },
            { AmmoID.Arrow, ItemID.WoodenArrow },
            { AmmoID.Coin, ItemID.CopperCoin },
            { AmmoID.Bullet, ItemID.MusketBall },
            { AmmoID.Sand, ItemID.SandBlock },
            { AmmoID.Dart, ItemID.PoisonDart },
            { AmmoID.Rocket, ItemID.RocketI },
            { AmmoID.Flare, ItemID.Flare },
            { AmmoID.Snowball, ItemID.Snowball },
            { AmmoID.StyngerBolt, ItemID.StyngerBolt },
            { AmmoID.CandyCorn, ItemID.CandyCorn },
            { AmmoID.JackOLantern, ItemID.JackOLantern },
            { AmmoID.Stake, ItemID.Stake },
            { AmmoID.NailFriendly, ItemID.Nail },
            { AmmoID.None, ItemID.MusketBall },
        };

        /// <summary>
        /// 让一个射弹安全的对应到弹药物品
        /// </summary>
        public static Dictionary<int, int> ProjectileToSafeAmmoMap { get; private set; } = new Dictionary<int, int>() {
            { ProjectileID.BoneArrow, ItemID.BoneArrow},
            { ProjectileID.MoonlordArrow, ItemID.MoonlordArrow},
            { ProjectileID.ChlorophyteArrow, ItemID.ChlorophyteArrow},
            { ProjectileID.CursedArrow, ItemID.CursedArrow},
            { ProjectileID.FlamingArrow, ItemID.FlamingArrow},
            { ProjectileID.FrostburnArrow, ItemID.FrostburnArrow},
            { ProjectileID.HellfireArrow, ItemID.HellfireArrow},
            { ProjectileID.HolyArrow, ItemID.HolyArrow},
            { ProjectileID.IchorArrow, ItemID.IchorArrow},
            { ProjectileID.JestersArrow, ItemID.JestersArrow},
            { ProjectileID.ShimmerArrow, ItemID.ShimmerArrow},
            { ProjectileID.UnholyArrow, ItemID.UnholyArrow},
            { ProjectileID.VenomArrow, ItemID.VenomArrow},
            { ProjectileID.WoodenArrowFriendly, ItemID.WoodenArrow},
            { ProjectileID.ChumBucket, ItemID.ChumBucket},
            { ProjectileID.ChlorophyteBullet, ItemID.ChlorophyteBullet},
            { ProjectileID.CrystalBullet, ItemID.CrystalBullet},
            { ProjectileID.CursedBullet, ItemID.CursedBullet},
            { ProjectileID.ExplosiveBullet, ItemID.ExplodingBullet},
            { ProjectileID.GoldenBullet, ItemID.GoldenBullet},
            { ProjectileID.BulletHighVelocity, ItemID.HighVelocityBullet},
            { ProjectileID.IchorBullet, ItemID.IchorBullet},
            { ProjectileID.MoonlordBullet, ItemID.MoonlordBullet},
            { ProjectileID.MeteorShot, ItemID.MeteorShot},
            { ProjectileID.Bullet, ItemID.MusketBall},
            { ProjectileID.NanoBullet, ItemID.NanoBullet},
            { ProjectileID.PartyBullet, ItemID.PartyBullet},
            { ProjectileID.SilverBullet, ItemID.SilverBullet},
            { ProjectileID.VenomBullet, ItemID.VenomBullet},
            { ProjectileID.SnowBallFriendly, ItemID.Snowball},
        };

        /// <summary>
        /// 火箭弹药映射字典
        /// </summary>
        public static Dictionary<int, int> RocketAmmoMap { get; private set; } = new Dictionary<int, int>() {
            { ItemID.RocketI, ProjectileID.RocketI },
            { ItemID.RocketII, ProjectileID.RocketII },
            { ItemID.RocketIII, ProjectileID.RocketIII },
            { ItemID.RocketIV, ProjectileID.RocketIV },
            { ItemID.ClusterRocketI, ProjectileID.ClusterRocketI },
            { ItemID.ClusterRocketII, ProjectileID.ClusterRocketII },
            { ItemID.DryRocket, ProjectileID.DryRocket },
            { ItemID.WetRocket, ProjectileID.WetRocket },
            { ItemID.HoneyRocket, ProjectileID.HoneyRocket },
            { ItemID.LavaRocket, ProjectileID.LavaRocket },
            { ItemID.MiniNukeI, ProjectileID.MiniNukeRocketI },
            { ItemID.MiniNukeII, ProjectileID.MiniNukeRocketII },
        };

        /// <summary>
        /// 雪人类弹药映射字典
        /// </summary>
        public static Dictionary<int, int> SnowmanCannonAmmoMap { get; private set; } = new Dictionary<int, int>() {
            { ItemID.RocketI, ProjectileID.RocketSnowmanI },
            { ItemID.RocketII, ProjectileID.RocketSnowmanII },
            { ItemID.RocketIII, ProjectileID.RocketSnowmanIII },
            { ItemID.RocketIV, ProjectileID.RocketSnowmanIV },
            { ItemID.ClusterRocketI, ProjectileID.ClusterSnowmanRocketI },
            { ItemID.ClusterRocketII, ProjectileID.ClusterSnowmanRocketII },
            { ItemID.DryRocket, ProjectileID.DrySnowmanRocket },
            { ItemID.WetRocket, ProjectileID.WetSnowmanRocket },
            { ItemID.HoneyRocket, ProjectileID.HoneySnowmanRocket },
            { ItemID.LavaRocket, ProjectileID.LavaSnowmanRocket },
            { ItemID.MiniNukeI, ProjectileID.MiniNukeSnowmanRocketI },
            { ItemID.MiniNukeII, ProjectileID.MiniNukeSnowmanRocketII },
        };

        /// <summary>
        /// 是否处于愚人节
        /// </summary>
        public static bool IsAprilFoolsDay => DateTime.Now.Month == 4 && DateTime.Now.Day == 1;

        /// <summary>
        /// 是否处于入侵期间的事件缓存<br/>
        /// 外部模组可以自行添加更多额外判定，但务必做好维护
        /// </summary>
        public static event Func<bool> InvasionEvent;

        /// <summary>
        /// 是否处于入侵期间
        /// </summary>
        public static bool IsInvasion() {
            bool baseCheck = Main.invasionType > 0 || Main.pumpkinMoon || Main.snowMoon || DD2Event.Ongoing;

            if (InvasionEvent is null) {
                return baseCheck;
            }

            foreach (Func<bool> check in InvasionEvent.GetInvocationList().Cast<Func<bool>>()) {
                if (check()) {
                    return true;//任意一个 true 就算 true
                }
            }

            return baseCheck;
        }

        /// <summary>
        /// 获取生成源
        /// </summary>
        public static IEntitySource FromObjectGetParent(this object obj) {
            if (obj is Projectile projectile) {
                return projectile.GetSource_FromAI();
            }
            else if (obj is NPC nPC) {
                return nPC.GetSource_FromAI();
            }
            else if (obj is Player player) {
                return player.GetSource_FromAI();
            }
            else if (obj is Item item) {
                return item.GetSource_FromAI();
            }
            else if (obj is TileProcessor tp) {
                return new EntitySource_WorldEvent($"{tp.Position.X}:{tp.Position.Y}");
            }
            else if (obj is Chest chest) {
                return new EntitySource_WorldEvent($"{chest.x}:{chest.y}");
            }
            else if (obj is Point16 point) {
                return new EntitySource_WorldEvent($"{point.X}:{point.Y}");
            }
            return new EntitySource_Parent(Main.LocalPlayer, "NullSource");
        }

        /// <inheritdoc cref="TagCompound.Get{T}(string)" />
        public static ushort GetUShort(this TagCompound tag, string key) => tag.Get<ushort>(key);
        /// <inheritdoc cref="TagCompound.Get{T}(string)" />
        public static Point16 GetPoint16(this TagCompound tag, string key) => tag.Get<Point16>(key);
        /// <inheritdoc cref="TagCompound.Get{T}(string)" />
        public static RegionSaveData GetRegionSaveData(this TagCompound tag, string key = "region") => RegionSaveData.FromTag(tag.Get<TagCompound>(key));

        /// <summary>
        /// 调整武器的最终伤害数值  
        /// </summary>
        /// <param name="item">需要修改的物品实例</param>
        /// <param name="currentDamage">当前设定的伤害值</param>
        /// <param name="baseDamage">最初记录的基础伤害值</param>
        /// <param name="damage">引用传入的 <see cref="StatModifier"/>，将被直接修改</param>
        public static void ApplyWeaponDamageScaling(Item item, int currentDamage, int baseDamage, ref StatModifier damage) {
            //保留原始的乘法系数，用于后续修正
            float oldMultiplicative = damage.Multiplicative;
            //按当前与基础伤害比率缩放
            damage *= currentDamage / (float)baseDamage;
            //抵消掉旧的乘法系数，避免重复叠加
            damage /= oldMultiplicative;
            //校正因部分模组后置修改造成的基础偏差
            damage *= baseDamage / (float)item.damage;
            //应用物品前缀的伤害修正
            damage *= item.GetPrefixState().damageMult;
        }

        /// <summary>
        /// 调整武器的最终击退数值 
        /// </summary>
        /// <param name="item">需要修改的物品实例</param>
        /// <param name="currentKnockback">当前设定的击退值</param>
        /// <param name="baseKnockback">最初记录的基础击退值</param>
        /// <param name="knockback">引用传入的 <see cref="StatModifier"/>，将被直接修改</param>
        public static void ApplyWeaponKnockbackScaling(Item item, float currentKnockback, float baseKnockback, ref StatModifier knockback) {
            //按当前与基础击退比率缩放
            knockback *= currentKnockback / baseKnockback;
            //校正因部分模组后置修改造成的基础偏差
            knockback *= baseKnockback / item.knockBack;
            //应用物品前缀的击退修正
            knockback *= item.GetPrefixState().knockbackMult;
        }

        /// <summary>
        /// 对NPC造成伤害
        /// </summary>
        /// <param name="npc"></param>
        /// <param name="damage"></param>
        /// <param name="knockback"></param>
        /// <param name="hitDirection"></param>
        /// <returns></returns>
        public static int StrikeNPCNoInteraction(this NPC npc, int damage, float knockback, int hitDirection) {
            NPC.HitInfo hitInfo = new() {
                Damage = damage,
                Knockback = knockback,
                HitDirection = hitDirection
            };
            return npc.StrikeNPC(hitInfo);
        }

        /// <summary>
        /// 给玩家添加或延长Buff
        /// </summary>
        /// <param name="player">目标玩家对象</param>
        /// <param name="buffID">Buff 的 ID</param>
        /// <param name="addBuffTime">要增加的持续时间</param>
        /// <param name="maxBuffTime">Buff 的最大允许时间，-1 表示不限制</param>
        /// <param name="netUpdate">是否同步网络消息（多人模式时需要）</param>
        /// <returns>该Buff在玩家身上的最终持续时间</returns>
        public static int AddOrExtendBuff(this Player player, int buffID, int addBuffTime, int maxBuffTime = -1, bool netUpdate = true) {
            if (!player.Alives() || buffID <= 0 || addBuffTime <= 0) {
                return 0;
            }

            int finalTime = 0;

            if (player.HasBuff(buffID)) {
                //玩家已经拥有该 Buff → 延长时间
                for (int i = 0; i < player.buffTime.Length; i++) {
                    if (player.buffType[i] != buffID) {
                        continue;
                    }
                    //增加持续时间
                    player.buffTime[i] += addBuffTime;
                    //如果设置了最大值，进行上限限制
                    if (maxBuffTime > 0 && player.buffTime[i] > maxBuffTime) {
                        player.buffTime[i] = maxBuffTime;
                    }
                    finalTime = player.buffTime[i];
                    if (netUpdate) {
                        NetMessage.SendData(MessageID.AddPlayerBuff, -1, -1, null, player.whoAmI, buffID, player.buffTime[i]);
                    }
                    break;//找到对应Buff后即可退出循环
                }
            }
            else {
                //玩家尚未拥有该Buff就添加新Buff
                player.AddBuff(buffID, addBuffTime, netUpdate);
                //新增Buff的时间即为最终时间
                finalTime = addBuffTime;
            }

            return finalTime;
        }

        /// <summary>
        /// 将 <see cref="ModKeybind"/> 转换为可读字符串，用于在物品提示中显示玩家的实际按键绑定<br/>
        /// 支持多重绑定，以 “/” 分隔显示
        /// </summary>
        /// <param name="keybind">目标 ModKeybind</param>
        /// <param name="noneTip">无绑定时使用的占位符内容，默认为 [NONE] </param>
        /// <returns>格式化后的绑定字符串</returns>
        public static string ToTooltipString(this ModKeybind keybind, string noneTip = "[NONE]") {
            if (Main.dedServ || keybind == null) {
                return string.Empty;
            }

            List<string> assignedKeys = keybind.GetAssignedKeys();
            return (assignedKeys == null || assignedKeys.Count == 0) ? noneTip : string.Join(" / ", assignedKeys);
        }

        /// <summary>
        /// 在 <see cref="TooltipLine"/> 列表中，将占位符关键字替换为指定热键的实际绑定<br/>
        /// 可用于动态更新物品描述中的按键信息
        /// </summary>
        /// <param name="tooltips">待修改的 TooltipLine 列表</param>
        /// <param name="keybind">ModKeybind 实例</param>
        /// <param name="placeholder">占位符关键字（默认为 "[KEY]"）</param>
        /// <param name="noneTip">无绑定时使用的占位符内容，默认为 [NONE] </param>
        /// <param name="filterMod">若指定，仅替换来自该 Mod 的 TooltipLine</param>
        public static void InsertHotkeyBinding(this IList<TooltipLine> tooltips, ModKeybind keybind
            , string placeholder = "[KEY]", string noneTip = "[NONE]", string filterMod = null) {
            if (Main.dedServ || keybind == null || tooltips == null || tooltips.Count == 0) {
                return;
            }

            string bindingText = keybind.ToTooltipString(noneTip);
            tooltips.ReplacePlaceholder(placeholder, bindingText, filterMod);
        }

        /// <summary>
        /// 遍历 <see cref="TooltipLine"/> 列表，将包含指定占位符的文本替换为目标内容<br/>
        /// 可通过 modName 参数限制作用范围
        /// </summary>
        /// <param name="tooltips">TooltipLine 集合</param>
        /// <param name="placeholder">要查找的占位符</param>
        /// <param name="replacement">替换内容</param>
        /// <param name="modName">若不为空，仅替换来自该 Mod 的行</param>
        public static void ReplacePlaceholder(this IList<TooltipLine> tooltips, string placeholder, string replacement, string modName = null) {
            if (tooltips == null || string.IsNullOrEmpty(placeholder)) {
                return;
            }

            for (int i = 0; i < tooltips.Count; i++) {
                TooltipLine line = tooltips[i];
                if (!string.IsNullOrEmpty(modName) && !string.Equals(line.Mod, modName, StringComparison.OrdinalIgnoreCase)) {
                    continue;
                }

                if (line.Text?.Contains(placeholder) == true) {
                    line.Text = line.Text.Replace(placeholder, replacement ?? string.Empty);
                }
            }
        }

        /// <summary>
        /// 判断是否为物品自带的编号描述行（<c>Tooltip0</c>、<c>Tooltip1</c>…）<br/>
        /// tML 按本地化文本的行序生成这些行且行数没有上限，只匹配前几行会让超长描述的尾行残留，
        /// 与替换后的新文本叠加成重复内容
        /// </summary>
        public static bool IsItemTooltipBody(this TooltipLine line)
            => line.Name.StartsWith("Tooltip", StringComparison.Ordinal)
            && int.TryParse(line.Name.AsSpan("Tooltip".Length), out _);

        [UnsafeAccessor(UnsafeAccessorKind.Constructor)]
        private static extern TooltipLine NewTooltipLine(string mod, string name, string text);

        /// <summary>
        /// 复制一行提示，保留原来的所属模组名、文本、颜色、修饰词标记与隐藏状态<br/>
        /// 原版行的所属名是 <c>"Terraria"</c>，它不在已加载模组里，用公开构造函数只能把它改成某个模组的行，
        /// 因此这里通过内部构造函数原样保留；内部的 OneDropLogo 标记不复制
        /// </summary>
        public static TooltipLine Clone(this TooltipLine line) {
            TooltipLine clone;
            try {
                clone = NewTooltipLine(line.Mod, line.Name, line.Text);
            } catch (MissingMethodException) {
                //内部构造函数在 tML 更新后消失时退回公开构造函数，所属名找不到则记在 InnoVault 名下
                Mod owner = ModLoader.TryGetMod(line.Mod, out Mod found) ? found : VaultMod.Instance;
                clone = new TooltipLine(owner, line.Name, line.Text);
            }
            clone.OverrideColor = line.OverrideColor;
            clone.IsModifier = line.IsModifier;
            clone.IsModifierBad = line.IsModifierBad;
            if (!line.Visible) {
                clone.Hide();
            }
            return clone;
        }

        /// <summary>
        /// 检查索引是否在数组范围内
        /// </summary>
        public static bool IsValidIndex(this int index, Array array) => index >= 0 && index < array.Length;
        /// <summary>
        /// 检查索引是否在数组范围内
        /// </summary>
        public static bool IsValidIndex(this float index, Array array) => IsValidIndex(((int)index), array);

        /// <summary>
        /// 尝试根据索引获取玩家实例
        /// </summary>
        /// <param name="playerIndex">玩家索引</param>
        /// <param name="player">输出的玩家实例</param>
        /// <returns>若索引有效且玩家存活则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        public static bool TryGetPlayer(this int playerIndex, out Player player) {
            player = null;
            if (!playerIndex.IsValidIndex(Main.player)) {
                return false;
            }
            Player instance = Main.player[playerIndex];
            if (!instance.Alives()) {
                return false;
            }
            player = instance;
            return true;
        }
        /// <summary>
        /// 尝试根据索引获取玩家实例
        /// </summary>
        /// <param name="playerIndex">玩家索引</param>
        /// <param name="player">输出的玩家实例</param>
        /// <returns>若索引有效且玩家存活则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        public static bool TryGetPlayer(this float playerIndex, out Player player) => TryGetPlayer((int)playerIndex, out player);

        /// <summary>
        /// 尝试根据索引获取NPC实例
        /// </summary>
        /// <param name="npcIndex">NPC索引</param>
        /// <param name="npc">输出的NPC实例</param>
        /// <returns>若索引有效且NPC存活则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        public static bool TryGetNPC(this int npcIndex, out NPC npc) {
            npc = null;
            if (!npcIndex.IsValidIndex(Main.npc)) {
                return false;
            }
            NPC instance = Main.npc[npcIndex];
            if (!instance.Alives()) {
                return false;
            }
            npc = instance;
            return true;
        }
        /// <summary>
        /// 尝试根据索引获取NPC实例
        /// </summary>
        /// <param name="npcIndex">NPC索引</param>
        /// <param name="npc">输出的NPC实例</param>
        /// <returns>若索引有效且NPC存活则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        public static bool TryGetNPC(this float npcIndex, out NPC npc) => TryGetNPC((int)npcIndex, out npc);

        /// <summary>
        /// 尝试根据索引获取弹幕实例
        /// </summary>
        /// <param name="projectileIndex">弹幕索引</param>
        /// <param name="proj">输出的弹幕实例</param>
        /// <returns>若索引有效且弹幕存活则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        public static bool TryGetProjectile(this int projectileIndex, out Projectile proj) {
            proj = null;
            if (!projectileIndex.IsValidIndex(Main.projectile)) {
                return false;
            }
            Projectile instance = Main.projectile[projectileIndex];
            if (!instance.Alives()) {
                return false;
            }
            proj = instance;
            return true;
        }
        /// <summary>
        /// 尝试根据索引获取弹幕实例
        /// </summary>
        /// <param name="projectileIndex">弹幕索引</param>
        /// <param name="proj">输出的弹幕实例</param>
        /// <returns>若索引有效且弹幕存活则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        public static bool TryGetProjectile(this float projectileIndex, out Projectile proj) => TryGetProjectile((int)projectileIndex, out proj);

        /// <summary>
        /// 赋予玩家无敌状态，这个函数与<see cref="Player.SetImmuneTimeForAllTypes(int)"/>类似
        /// </summary>
        /// <param name="player">要赋予无敌状态的玩家</param>
        /// <param name="time">无敌的帧数</param>
        /// <param name="blink">是否允许玩家在无敌状态下闪烁默认为 false</param>
        public static void GivePlayerImmuneState(this Player player, int time, bool blink = false) {
            player.immuneNoBlink = !blink;
            player.immune = true;
            player.immuneTime = time;
            for (int k = 0; k < player.hurtCooldowns.Length; k++) {
                player.hurtCooldowns[k] = player.immuneTime;
            }
        }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static int GetSourceNPC(int npcID) => -1;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static int[] SourceNPCByHoverNPC(int npcID) => [];

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool HasStaticImmunity(int npcID) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool HasStaticImmunity(this NPC npc, int whoAmI) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool HasStaticImmunity(int npcID, int whoAmI) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool HasStaticImmunity(NPC npc, Player player, Item item) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool HasStaticImmunity(NPC npc, Player player, Projectile projectile) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool AddStaticImmunity(NPC npc, Player player, Projectile projectile, int customCooldowns = -2, bool netUpdate = true) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool AddStaticImmunity(NPC npc, Player player, Item item, int customCooldowns = -2, bool netUpdate = true) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool AddStaticImmunity(Dictionary<HitByHitData, int[]> data, int npcID, int whoAmI
            , int hitID, int customCooldowns = -2, bool netUpdate = true, byte messageType = default) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool AddStaticImmunity(this NPC npc, int whoAmI, bool netUpdate = true) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool AddStaticImmunity(int npcID, int whoAmI, bool netUpdate = true) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool AddStaticImmunity(this NPC npc, int whoAmI, short localNPCHitCooldown, bool netUpdate = true) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static bool AddStaticImmunity(int npcID, int whoAmI, short localNPCHitCooldown, bool netUpdate = true) => false;

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void SendAddStaticImmunityData(int npcID, int whoAmI, short localNPCHitCooldown = -2) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void SendSetStaticImmunityData(int npcID, int whoAmI, int immunity) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void LoadenNPCStaticImmunityData(int npcSourceID, int npcID, int staticImmuneCool = 0) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void LoadenNPCStaticImmunityData(int npcSourceID, IEnumerable<int> npcIDs, int staticImmuneCool = 0) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void NormalizeStaticImmunityCooldowns() { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void SetStaticImmunity(int npcID, int whoAmI, int immunity, bool netUpdate = true) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void EnableStaticImmunity(this NPC npc, bool netUpdate = true) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void EnableStaticImmunity(int npcID, bool netUpdate = true) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void DisableStaticImmunity(this NPC npc, bool netUpdate = true) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void DisableStaticImmunity(int npcID, bool netUpdate = true) { }

        /// <summary>
        /// [已弃用] 该系统已移除
        /// </summary>
        [Obsolete("StaticImmunity系统已弃用，该系统存在性能问题已被移除，请移除对此方法的使用")]
        public static void ConfigureStaticImmunityUsage(int npcID, bool enabled, bool netUpdate = true) { }

        /// <summary>
        /// 获取指定NPC的所有掉落物品ID
        /// </summary>
        /// <param name="npcId">NPC的ID</param>
        /// <param name="includeGlobalRules">是否包含全局掉落规则（如钱币、稀有生物掉落等）</param>
        /// <returns>掉落物品ID的集合</returns>
        public static HashSet<int> GetNPCDrops(int npcId, bool includeGlobalRules = false) {
            HashSet<int> drops = new HashSet<int>();

            //从游戏数据库获取该NPC的掉落规则
            List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForNPCID(npcId, includeGlobalRules);

            //创建掉落率信息列表
            List<DropRateInfo> dropRateInfoList = new List<DropRateInfo>();
            DropRateInfoChainFeed ratesInfo = new DropRateInfoChainFeed(1f);

            //解析每个掉落规则
            foreach (IItemDropRule rule in dropRules) {
                rule.ReportDroprates(dropRateInfoList, ratesInfo);
            }

            //收集所有物品ID
            foreach (DropRateInfo dropRateInfo in dropRateInfoList) {
                drops.Add(dropRateInfo.itemId);
            }

            return drops;
        }

        /// <summary>
        /// 获取指定NPC的所有掉落物品ID及其掉落概率
        /// </summary>
        /// <param name="npcId">NPC的ID</param>
        /// <param name="includeGlobalRules">是否包含全局掉落规则</param>
        /// <returns>物品ID和掉落概率的字典</returns>
        public static Dictionary<int, float> GetNPCDropsWithRates(int npcId, bool includeGlobalRules = false) {
            Dictionary<int, float> dropsWithRates = new Dictionary<int, float>();

            List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForNPCID(npcId, includeGlobalRules);

            List<DropRateInfo> dropRateInfoList = new List<DropRateInfo>();
            DropRateInfoChainFeed ratesInfo = new DropRateInfoChainFeed(1f);

            foreach (IItemDropRule rule in dropRules) {
                rule.ReportDroprates(dropRateInfoList, ratesInfo);
            }

            foreach (DropRateInfo dropRateInfo in dropRateInfoList) {
                //如果物品已存在，保留较高的掉落率
                if (dropsWithRates.TryGetValue(dropRateInfo.itemId, out float value)) {
                    dropsWithRates[dropRateInfo.itemId] = Math.Max(value, dropRateInfo.dropRate);
                }
                else {
                    dropsWithRates.Add(dropRateInfo.itemId, dropRateInfo.dropRate);
                }
            }

            return dropsWithRates;
        }

        /// <summary>
        /// 获取指定NPC的详细掉落信息
        /// </summary>
        /// <param name="npcId">NPC的ID</param>
        /// <param name="includeGlobalRules">是否包含全局掉落规则</param>
        /// <returns>完整的掉落率信息列表</returns>
        public static List<DropRateInfo> GetNPCDropDetails(int npcId, bool includeGlobalRules = false) {
            List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForNPCID(npcId, includeGlobalRules);

            List<DropRateInfo> dropRateInfoList = new List<DropRateInfo>();
            DropRateInfoChainFeed ratesInfo = new DropRateInfoChainFeed(1f);

            foreach (IItemDropRule rule in dropRules) {
                rule.ReportDroprates(dropRateInfoList, ratesInfo);
            }

            return dropRateInfoList;
        }

        /// <summary>
        /// 向掉落表添加一条固定分母的普通掉落规则，等价于 <see cref="ItemDropRule.Common"/> 加 <see cref="ILoot.Add"/>
        /// </summary>
        /// <param name="loot">目标掉落表</param>
        /// <param name="itemID">掉落的物品类型</param>
        /// <param name="chanceDenominator">掉率分母，1 即必掉，4 即四分之一</param>
        /// <param name="minQuantity">最小数量</param>
        /// <param name="maxQuantity">最大数量</param>
        /// <returns>被添加的规则，可继续挂接 <c>OnSuccess</c></returns>
        public static IItemDropRule AddCommon(this ILoot loot, int itemID, int chanceDenominator = 1, int minQuantity = 1, int maxQuantity = 1)
            => loot.Add(ItemDropRule.Common(itemID, chanceDenominator, minQuantity, maxQuantity));

        /// <summary>
        /// 给领头条件规则挂一条固定分母的普通掉落规则，条件成立时才会尝试掉落
        /// </summary>
        /// <param name="mainRule">领头条件规则，如 <c>new LeadingConditionRule(new Conditions.NotExpert())</c></param>
        /// <param name="itemID">掉落的物品类型</param>
        /// <param name="chanceDenominator">掉率分母，1 即必掉，4 即四分之一</param>
        /// <param name="minQuantity">最小数量</param>
        /// <param name="maxQuantity">最大数量</param>
        /// <param name="hideLootReport">为 <see langword="true"/> 时不在掉落一览里显示这条规则</param>
        /// <returns>被添加的规则，可继续挂接 <c>OnSuccess</c></returns>
        public static IItemDropRule AddCommon(this LeadingConditionRule mainRule, int itemID, int chanceDenominator = 1, int minQuantity = 1, int maxQuantity = 1, bool hideLootReport = false)
            => mainRule.OnSuccess(ItemDropRule.Common(itemID, chanceDenominator, minQuantity, maxQuantity), hideLootReport);

        /// <summary>
        /// 尝试获取指定 <see cref="Item"/> 类型的全部 <see cref="ItemOverride"/> 映射
        /// </summary>
        /// <param name="item">要查询的物品实例</param>
        /// <param name="value">
        /// 输出参数如果成功，则包含该物品类型对应的 <see cref="ItemOverride"/> 字典；
        /// 若失败则为 <c>null</c>
        /// </param>
        /// <returns>
        /// 如果当前不在主菜单中且成功从 <see cref="ItemOverride.ByID"/> 中获取到对应的映射，则返回 <c>true</c>；
        /// 否则返回 <c>false</c>
        /// </returns>
        public static bool TryGetOverride(this Item item, out Dictionary<Type, ItemOverride> value) {
            value = null;
            if (Main.gameMenu) {
                return false;
            }
            if (ItemOverride.ByID.TryGetValue(item.type, out value)) {
                return true;
            }
            return value != null;
        }

        /// <summary>
        /// 尝试获取指定 <see cref="Item"/> 类型对应的特定 <typeparamref name="T"/> 类型的 <see cref="ItemOverride"/>
        /// </summary>
        /// <typeparam name="T">
        /// 期望获取的重写类型，必须继承自 <see cref="ItemOverride"/>
        /// </typeparam>
        /// <param name="item">要查询的物品实例</param>
        /// <param name="value">
        /// 输出参数如果成功，则包含该类型的重写实例；
        /// 若失败则为 <c>null</c>
        /// </param>
        /// <returns>
        /// 如果当前不在主菜单中，且存在该类型的重写映射，则返回 <c>true</c>；
        /// 否则返回 <c>false</c>
        /// </returns>
        public static bool TryGetOverride<T>(this Item item, out T value) where T : ItemOverride {
            value = null;
            if (Main.gameMenu) {
                return false;
            }
            if (!ItemOverride.TypeToInstance.TryGetValue(typeof(T), out var value2)) {
                return false;
            }
            if (item.type != value2.TargetID && value2.TargetID != -1) {
                return false;
            }
            value = value2 as T;
            return value != null;
        }

        /// <summary>
        /// 获取指定类型 <typeparamref name="T"/> 的 <see cref="NPCOverride"/> 实例<br/>
        /// 若未在 <see cref="NPCRebuildLoader"/> 中注册对应类型，会抛出异常
        /// </summary>
        /// <typeparam name="T">要获取的重制节点类型</typeparam>
        /// <param name="npc">目标 NPC 实例</param>
        /// <returns><typeparamref name="T"/> 类型对应的 <see cref="NPCOverride"/> 实例</returns>
        /// <exception cref="KeyNotFoundException">如果未注册指定类型的节点</exception>
        public static T GetOverride<T>(this NPC npc) where T : NPCOverride
            => npc.GetGlobalNPC<NPCRebuildLoader>().NPCOverrides[typeof(T)] as T;

        /// <summary>
        /// 尝试获取目标 <paramref name="npc"/> 的全部 <see cref="NPCOverride"/> 节点集合
        /// </summary>
        /// <param name="npc">目标 NPC 实例</param>
        /// <param name="values">返回对应的重制节点字典，键为类型，值为 <see cref="NPCOverride"/> 实例</param>
        /// <returns>
        /// 如果获取成功，则返回 <see langword="true"/>；
        /// 否则返回 <see langword="false"/>，此时 <paramref name="values"/> 为 <see langword="null"/>
        /// </returns>
        public static bool TryGetOverride(this NPC npc, out Dictionary<Type, NPCOverride> values) {
            values = null;
            if (npc is null) {
                return false;
            }
            if (npc.TryGetGlobalNPC(out NPCRebuildLoader globalInstance)) {
                values = globalInstance.NPCOverrides;
            }
            return values != null;
        }

        /// <summary>
        /// 尝试获取目标 <paramref name="npc"/> 的特定类型 <typeparamref name="T"/> 的 <see cref="NPCOverride"/> 实例
        /// </summary>
        /// <typeparam name="T">要尝试获取的重制节点类型</typeparam>
        /// <param name="npc">目标 NPC 实例</param>
        /// <param name="value">返回的 <see cref="NPCOverride"/> 实例，如果未找到则为 <see langword="null"/></param>
        /// <returns>
        /// 如果找到指定类型的重制节点并成功获取，则返回 <see langword="true"/>；
        /// 否则返回 <see langword="false"/>
        /// </returns>
        public static bool TryGetOverride<T>(this NPC npc, out T value) where T : NPCOverride {
            value = null;
            if (npc is null || !npc.TryGetGlobalNPC(out NPCRebuildLoader globalInstance)) {
                return false;
            }
            if (globalInstance.NPCOverrides is null) {
                return false;
            }
            if (!globalInstance.NPCOverrides.TryGetValue(typeof(T), out var value2)) {
                return false;
            }
            value = value2 as T;
            return value != null;
        }

        /// <summary>
        /// 获取指定类型的 <see cref="ProjOverride"/> 实例
        /// </summary>
        /// <typeparam name="T">要获取的 Override 类型，必须继承自 <see cref="ProjOverride"/></typeparam>
        /// <param name="proj">目标弹幕实例</param>
        /// <returns>对应类型的 Override 实例，如果不存在则返回 <see langword="null"/></returns>
        public static T GetOverride<T>(this Projectile proj) where T : ProjOverride
            => proj.TryGetOverride(out T value) ? value : null;

        /// <summary>
        /// 尝试从弹幕中获取所有已附加的 <see cref="ProjOverride"/> 实例集合
        /// </summary>
        /// <param name="proj">目标弹幕实例</param>
        /// <param name="values">输出参数，用于接收类型到 Override 的映射表</param>
        /// <returns>若成功获取到映射表，返回 <see langword="true"/>；否则返回 <see langword="false"/></returns>
        public static bool TryGetOverride(this Projectile proj, out Dictionary<Type, ProjOverride> values) {
            values = null;
            if (Main.gameMenu || proj is null) {
                return false;
            }
            if (proj.TryGetGlobalProjectile(out ProjRebuildLoader globalInstance)) {
                values = globalInstance.ProjOverrides;
            }
            return values != null;
        }

        /// <summary>
        /// 尝试获取指定类型的 <see cref="ProjOverride"/> 实例
        /// </summary>
        /// <typeparam name="T">要获取的 Override 类型，必须继承自 <see cref="ProjOverride"/></typeparam>
        /// <param name="proj">目标弹幕实例</param>
        /// <param name="value">输出参数，用于接收对应类型的 Override 实例</param>
        /// <returns>若成功获取到指定类型的 Override，返回 <see langword="true"/>；否则返回 <see langword="false"/></returns>
        public static bool TryGetOverride<T>(this Projectile proj, out T value) where T : ProjOverride {
            value = null;
            if (Main.gameMenu) {
                return false;
            }
            if (proj is null || !proj.TryGetGlobalProjectile(out ProjRebuildLoader globalInstance)) {
                return false;
            }
            if (globalInstance.ProjOverrides is null) {
                return false;
            }
            if (!globalInstance.ProjOverrides.TryGetValue(typeof(T), out var value2)) {
                return false;
            }
            value = value2 as T;
            return value != null;
        }

        /// <summary>
        /// 获取指定类型 <typeparamref name="T"/> 的 <see cref="PlayerOverride"/> 实例<br/>
        /// 若未在 <see cref="PlayerOverride.TypeToInstance"/> 中注册对应类型，会抛出异常
        /// </summary>
        /// <typeparam name="T">要获取的重制节点类型</typeparam>
        /// <param name="player">目标 玩家 实例</param>
        /// <returns><typeparamref name="T"/> 类型对应的 <see cref="PlayerOverride"/> 实例</returns>
        /// <exception cref="KeyNotFoundException">如果未注册指定类型的节点</exception>
        public static T GetOverride<T>(this Player player) where T : PlayerOverride {
            if (!PlayerOverride.TryFetchByPlayer(player, out var keyValuePairs)) {
                return null;
            }
            return keyValuePairs[typeof(T)] as T;
        }

        /// <summary>
        /// 尝试获取指定类型的 <see cref="PlayerOverride"/> 实例
        /// </summary>
        /// <typeparam name="T">要获取的 Override 类型，必须继承自 <see cref="PlayerOverride"/></typeparam>
        /// <param name="player">目标玩家实例</param>
        /// <param name="value">输出参数，用于接收对应类型的 Override 实例</param>
        /// <returns>若成功获取到指定类型的 Override，返回 <see langword="true"/>；否则返回 <see langword="false"/></returns>
        public static bool TryGetOverride<T>(this Player player, out T value) where T : PlayerOverride {
            value = null;
            if (!VaultLoad.LoadenContent) {
                return false;
            }
            if (PlayerOverride.TryFetchByPlayer(player, out var keyValuePairs)
                && keyValuePairs.TryGetValue(typeof(T), out var playerOverride)) {
                value = playerOverride as T;
            }
            return value != null;
        }

        /// <summary>
        /// 获取指定物品的本地化名字
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static LocalizedText GetLocalizedItemName<T>() where T : ModItem => GetLocalizedItemName(ModContent.ItemType<T>());

        /// <summary>
        /// 获取指定物品的本地化名字
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static LocalizedText GetLocalizedItemName(int id) {
            if (id <= ItemID.None) {
                return null;
            }

            if (id < ItemID.Count) {
                return Language.GetText("ItemName." + ItemID.Search.GetName(id));
            }
            else {
                return ItemLoader.GetItem(id).GetLocalization("DisplayName");
            }
        }

        /// <summary>
        /// 获取指定物品的本地化描述
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static LocalizedText GetLocalizedItemTooltip<T>() where T : ModItem => GetLocalizedItemTooltip(ModContent.ItemType<T>());

        /// <summary>
        /// 获取指定物品的本地化描述
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static LocalizedText GetLocalizedItemTooltip(int id) {
            if (id <= ItemID.None) {
                return null;
            }

            if (id < ItemID.Count) {
                return Language.GetText("ItemTooltip." + ItemID.Search.GetName(id));
            }
            else {
                return ItemLoader.GetItem(id).GetLocalization("Tooltip");
            }
        }

        /// <summary>
        /// 解析字符串键并获取对应的物品类型
        /// </summary>
        /// <param name="fullName">用于解析的字符串键，可以是整数类型或模组/物品名称的组合</param>
        /// <param name="loadVanillaItem">是否自动加载一次原版物品</param>
        /// <returns>解析后得到的物品类型</returns>
        public static int GetItemTypeFromFullName(string fullName, bool loadVanillaItem = false) {
            if (fullName == "Null/Null") {
                return ItemID.None;
            }

            if (int.TryParse(fullName, out int intValue)) {
                if (loadVanillaItem && !isServer) {
                    Main.instance.LoadItem(intValue);
                }
                return intValue;
            }
            else {
                string[] fruits = fullName.Split('/');
                if (ModLoader.TryGetMod(fruits[0], out Mod mod)
                    && mod.TryFind(fruits[1], out ModItem modItem)) {
                    return modItem.Type;
                }

                return ItemID.None;
            }
        }

        /// <summary>
        /// 解析字符串键并获取对应的物块类型
        /// </summary>
        /// <param name="fullName">用于解析的字符串键，可以是整数类型或模组/物块名称的组合</param>
        /// <returns>解析后得到的物块类型</returns>
        public static int GetTileTypeFromFullName(string fullName) {
            if (fullName == "Null/Null") {
                return 0; //Terraria.TileID.None = 0
            }

            if (int.TryParse(fullName, out int intValue)) {
                return intValue;
            }
            else {
                string[] parts = fullName.Split('/');
                if (parts.Length != 2) {
                    return 0;
                }

                if (ModLoader.TryGetMod(parts[0], out Mod mod)
                    && mod.TryFind(parts[1], out ModTile modTile)) {
                    return modTile.Type;
                }

                return 0;
            }
        }

        /// <summary>
        /// 解析字符串键并获取对应的墙壁类型
        /// </summary>
        /// <param name="fullName">用于解析的字符串键，可以是整数类型或模组/墙壁名称的组合</param>
        /// <param name="loadVanillaWall">是否自动加载一次原版墙壁</param>
        /// <returns>解析后得到的墙壁类型</returns>
        public static int GetWallTypeFromFullName(string fullName, bool loadVanillaWall = false) {
            if (fullName == "Null/Null") {
                return 0; //Terraria.WallID.None = 0
            }

            if (int.TryParse(fullName, out int intValue)) {
                if (loadVanillaWall && !isServer) {
                    Main.instance.LoadWall(intValue);
                }
                return intValue;
            }
            else {
                string[] parts = fullName.Split('/');
                if (parts.Length != 2) {
                    return 0;
                }

                if (ModLoader.TryGetMod(parts[0], out Mod mod)
                    && mod.TryFind(parts[1], out ModWall modWall)) {
                    return modWall.Type;
                }

                return 0;
            }
        }

        /// <summary>
        /// 安全加载物品资源
        /// </summary>
        /// <param name="id"></param>
        public static void SafeLoadItem(int id) {
            if (!Main.dedServ && id > 0 && id < TextureAssets.Item.Length && Main.Assets != null && TextureAssets.Item[id] != null) {
                Main.instance.LoadItem(id);
            }
        }
        /// <summary>
        /// 安全加载物品资源
        /// </summary>
        /// <param name="item"></param>
        public static void SafeLoadItem(this Item item) => SafeLoadItem(item.type);

        /// <summary>
        /// 安全加载弹幕资源
        /// </summary>
        /// <param name="id"></param>
        public static void SafeLoadProj(int id) {
            if (!Main.dedServ && id > 0 && id < TextureAssets.Projectile.Length && Main.Assets != null && TextureAssets.Projectile[id] != null) {
                Main.instance.LoadProjectile(id);
            }
        }
        /// <summary>
        /// 安全加载弹幕资源
        /// </summary>
        /// <param name="proj"></param>
        public static void SafeLoadProj(this Projectile proj) => SafeLoadProj(proj.type);

        /// <summary>
        /// 检查指定玩家是否按下了鼠标键
        /// </summary>
        /// <param name="player">要检查的玩家</param>
        /// <param name="leftCed">是否检查左鼠标键，否则检测右鼠标键</param>
        /// <param name="netCed">是否进行网络同步检查</param>
        /// <returns>如果按下了指定的鼠标键，则返回true，否则返回false</returns>
        public static bool PressKey(this Player player, bool leftCed = true, bool netCed = true) {
            return (!netCed || Main.myPlayer == player.whoAmI) && (leftCed ? PlayerInput.Triggers.Current.MouseLeft : PlayerInput.Triggers.Current.MouseRight);
        }

        /// <summary>
        /// 让一个NPC可以正常的掉落物品而不触发其他死亡事件，只应该在非服务端上调用该方法
        /// </summary>
        /// <param name="npc"></param>
        public static void DropItem(this NPC npc) {
            DropAttemptInfo dropAttemptInfo = default;
            dropAttemptInfo.player = Main.LocalPlayer;
            dropAttemptInfo.npc = npc;
            dropAttemptInfo.IsExpertMode = Main.expertMode;
            dropAttemptInfo.IsMasterMode = Main.masterMode;
            dropAttemptInfo.IsInSimulation = false;
            dropAttemptInfo.rng = Main.rand;
            DropAttemptInfo info = dropAttemptInfo;
            Main.ItemDropSolver.TryDropping(info);
        }

        /// <summary>
        /// 设置玩家鼠标指向物块的信息状态
        /// </summary>
        /// <param name="player"></param>
        /// <param name="itemID"></param>
        public static void SetMouseOverByTile(this Player player, int itemID) {
            player.noThrow = 2;
            player.mouseInterface = true;
            player.cursorItemIconEnabled = true;
            if (itemID > 0) {
                player.cursorItemIconID = itemID;//当玩家鼠标悬停在物块之上时，显示该物品的材质
            }
        }

        /// <summary>
        /// 设置玩家鼠标指向物块的信息状态
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="player"></param>
        public static void SetMouseOverByTile<T>(this Player player) where T : ModItem
            => SetMouseOverByTile(player, ModContent.ItemType<T>());

        /// <summary>
        /// 利用<see cref="Projectile.identity"/>搜索对应的弹幕实例
        /// </summary>
        /// <param name="projectiles"></param>
        /// <param name="identity"></param>
        /// <returns></returns>
        public static Projectile FindByIdentity(this Projectile[] projectiles, int identity) => projectiles.FirstOrDefault(x => x.identity == identity);

        /// <summary>
        /// 实时计算当前所有激活弹幕中，指定ID的弹幕数量
        /// </summary>
        /// <param name="projID">要统计的弹幕类型<see cref="Projectile.type"/></param>
        /// <param name="owner">玩家索引 <see cref="Projectile.owner"/> , 默认为-1，即不启用玩家主人排查</param>
        /// <returns>符合条件的弹幕数量</returns>
        public static int CountProjectilesOfID(int projID, int owner = -1) {
            int num = 0;
            foreach (var proj in Main.ActiveProjectiles) {
                if (owner >= 0 && owner != proj.owner) {
                    continue;
                }
                if (proj.type == projID) {
                    num++;
                }
            }
            return num;
        }
        /// <summary>
        /// 实时计算当前所有激活弹幕中，指定ID的弹幕数量
        /// </summary>
        /// <typeparam name="T">弹幕类型</typeparam>
        /// <param name="owner">玩家索引 <see cref="Projectile.owner"/> , 默认为-1，即不启用玩家主人排查</param>
        /// <returns></returns>
        public static int CountProjectilesOfID<T>(int owner = -1) where T : ModProjectile
            => CountProjectilesOfID(ModContent.ProjectileType<T>(), owner);
        /// <summary>
        /// 实时计算当前所有激活弹幕中，指定ID的弹幕数量
        /// </summary>
        /// <param name="player">玩家实例</param>
        /// <param name="projID">要统计的弹幕类型<see cref="Projectile.type"/></param>
        /// <returns></returns>
        public static int CountProjectilesOfID(this Player player, int projID) => CountProjectilesOfID(projID, player.whoAmI);
        /// <summary>
        /// 实时计算当前所有激活弹幕中，指定ID的弹幕数量
        /// </summary>
        /// <typeparam name="T">弹幕类型</typeparam>
        /// <param name="player">玩家索引 <see cref="Projectile.owner"/> , 默认为-1，即不启用玩家主人排查</param>
        /// <returns></returns>
        public static int CountProjectilesOfID<T>(this Player player) where T : ModProjectile
            => CountProjectilesOfID(ModContent.ProjectileType<T>(), player.whoAmI);

        /// <summary>
        /// 一个模拟原版机制的消耗判定，考虑了大多数情况下的弹药消耗概率因素
        /// </summary>
        /// <param name="player"></param>
        /// <param name="ammo"></param>
        /// <returns>如果返回<see langword="true"/>则代表不消耗</returns>
        public static bool IsRangedAmmoFreeThisShot(this Player player, Item ammo) {
            bool flag2 = false;
            if (player.magicQuiver && ammo.ammo == AmmoID.Arrow && Main.rand.NextBool(5)) {
                flag2 = true;
            }

            if (player.ammoBox && Main.rand.NextBool(5)) {
                flag2 = true;
            }

            if (player.ammoPotion && Main.rand.NextBool(5)) {
                flag2 = true;
            }

            if (player.huntressAmmoCost90 && Main.rand.NextBool(10)) {
                flag2 = true;
            }

            if (player.chloroAmmoCost80 && Main.rand.NextBool(5)) {
                flag2 = true;
            }

            if (player.ammoCost80 && Main.rand.NextBool(5)) {
                flag2 = true;
            }

            if (player.ammoCost75 && Main.rand.NextBool(4)) {
                flag2 = true;
            }

            return flag2;
        }

        /// <summary>
        /// 处理对物品集合的堆叠添加
        /// </summary>
        /// <param name="itemList"></param>
        /// <param name="itemToAdd"></param>
        public static void MergeItemStacks(List<Item> itemList, Item itemToAdd) {
            //查找是否有相同类型的物品
            var existingItem = itemList.FirstOrDefault(i => i.type == itemToAdd.type);

            if (existingItem != null) {
                //合并物品堆叠数
                int totalStack = existingItem.stack + itemToAdd.stack;
                int maxStack = existingItem.maxStack;

                //如果堆叠超过最大堆叠数，分配新的堆叠物品
                while (totalStack > maxStack) {
                    existingItem.stack = maxStack;
                    totalStack -= maxStack;

                    //创建新的物品并添加剩余堆叠
                    var newItem = itemToAdd.Clone(); //确保不会修改原物品
                    newItem.stack = Math.Min(totalStack, newItem.maxStack);
                    itemList.Add(newItem);
                }

                //最后将剩余堆叠数添加到现有物品
                if (totalStack > 0) {
                    existingItem.stack = totalStack;
                }
            }
            else {
                //没有相同类型物品，直接添加
                itemList.Add(itemToAdd);
            }
        }

        /// <summary>
        /// 统计物品列表中指定类型的物品总数量（累加堆叠）
        /// </summary>
        /// <param name="items">物品列表，如 <see cref="Player.inventory"/></param>
        /// <param name="itemType">要统计的物品类型</param>
        public static int CountItems(this IList<Item> items, int itemType) {
            int num = 0;
            for (int i = 0; i < items.Count; i++) {
                Item item = items[i];
                if (item.Alives() && item.type == itemType) {
                    num += item.stack;
                }
            }
            return num;
        }

        /// <summary>
        /// 统计物品列表中属于任一指定类型的物品总数量（累加堆叠）<br/>
        /// 类型集合用集合表达式传入即可，不产生堆分配，如 <c>items.CountItems([ItemID.IronOre, ItemID.LeadOre])</c>
        /// </summary>
        /// <param name="items">物品列表</param>
        /// <param name="itemTypes">要统计的物品类型集合</param>
        public static int CountItems(this IList<Item> items, ReadOnlySpan<int> itemTypes) {
            int num = 0;
            for (int i = 0; i < items.Count; i++) {
                Item item = items[i];
                if (item.Alives() && itemTypes.Contains(item.type)) {
                    num += item.stack;
                }
            }
            return num;
        }

        /// <summary>
        /// 统计玩家背包中指定类型的物品总数量，可选一并统计四个银行（猪猪银行、保险箱、护卫熔炉、虚空保险箱）<br/>
        /// 背包部分统计整个 <see cref="Player.inventory"/> 数组，含钱币栏、弹药栏与鼠标物品
        /// </summary>
        /// <param name="player">目标玩家</param>
        /// <param name="itemType">要统计的物品类型</param>
        /// <param name="includeBanks">是否包含四个银行，默认只统计背包</param>
        public static int CountItems(this Player player, int itemType, bool includeBanks = false) {
            int num = player.inventory.CountItems(itemType);
            if (includeBanks) {
                num += player.bank.item.CountItems(itemType);
                num += player.bank2.item.CountItems(itemType);
                num += player.bank3.item.CountItems(itemType);
                num += player.bank4.item.CountItems(itemType);
            }
            return num;
        }

        /// <summary>
        /// 统计玩家背包中属于任一指定类型的物品总数量，可选一并统计四个银行<br/>
        /// 类型集合用集合表达式传入，如 <c>player.CountItems([ItemID.IronOre, ItemID.LeadOre], true)</c>
        /// </summary>
        /// <param name="player">目标玩家</param>
        /// <param name="itemTypes">要统计的物品类型集合</param>
        /// <param name="includeBanks">是否包含四个银行，默认只统计背包</param>
        public static int CountItems(this Player player, ReadOnlySpan<int> itemTypes, bool includeBanks = false) {
            int num = player.inventory.CountItems(itemTypes);
            if (includeBanks) {
                num += player.bank.item.CountItems(itemTypes);
                num += player.bank2.item.CountItems(itemTypes);
                num += player.bank3.item.CountItems(itemTypes);
                num += player.bank4.item.CountItems(itemTypes);
            }
            return num;
        }

        /// <summary>
        /// 送东西给玩家：优先塞进背包，塞不下的那份才落地。仅对本地玩家生效<br/>
        /// 别用 <see cref="Player.QuickSpawnItem(IEntitySource, int, int)"/> 代替：它造的是掉落物。
        /// 单人下 <c>Item.NewItem</c> 会立刻把掉落物预定给本人，看着像直接给；
        /// 多人客户端没有这一步，实际只是请求服务端造个普通掉落物，归属由服务端按“最近的可拾取者”重算，
        /// 于是拾取范围更大的队友、水火、掉落物槽位回收都可能把这份东西吃掉
        /// </summary>
        /// <param name="player">接收玩家，必须是本地玩家</param>
        /// <param name="source">物品来源</param>
        /// <param name="itemType">物品类型</param>
        /// <param name="stack">总数量，超过单堆上限时自动拆堆，小于等于 0 按 1 处理</param>
        /// <returns>有任何一份落到地上则为 <see langword="true"/></returns>
        public static bool GiveItem(this Player player, IEntitySource source, int itemType, int stack = 1) {
            if (itemType <= ItemID.None || player == null || !player.active || player.whoAmI != Main.myPlayer) {
                return false;
            }

            bool dropped = false;
            int remaining = stack <= 0 ? 1 : stack;
            while (remaining > 0) {
                Item gift = new(itemType);
                gift.stack = Math.Min(remaining, Math.Max(1, gift.maxStack));
                remaining -= gift.stack;
                dropped |= player.GiveItem(source, gift);
            }
            return dropped;
        }

        /// <summary>
        /// 送一件已配好数据的物品，语义同 <see cref="GiveItem(Player, IEntitySource, int, int)"/><br/>
        /// <paramref name="gift"/> 会被直接放进背包，调用方不要再复用
        /// </summary>
        /// <param name="player">接收玩家，必须是本地玩家</param>
        /// <param name="source">物品来源</param>
        /// <param name="gift">要送出的物品</param>
        /// <returns>有任何一份落到地上则为 <see langword="true"/></returns>
        public static bool GiveItem(this Player player, IEntitySource source, Item gift) {
            if (player == null || !player.active || player.whoAmI != Main.myPlayer || gift == null || gift.IsAir) {
                return false;
            }

            gift.position = player.Center;
            Item overflow = player.GetItem(player.whoAmI, gift, GetItemSettings.NPCEntityToPlayerInventorySettings);
            if (overflow.IsAir || overflow.stack <= 0) {
                return false;
            }

            player.QuickSpawnItem(source, overflow, overflow.stack);
            return true;
        }

        /// <summary>
        /// 向指定的 <see cref="Chest"/> 中添加一个物品，支持自动堆叠与空格插入
        /// </summary>
        /// <param name="chest">目标箱子实例</param>
        /// <param name="item">要添加的物品对象</param>
        /// <param name="throwingExcessItems">
        /// 是否在物品无法全部放入箱子时，将剩余部分掉落在箱子实体位置处，默认为<see langword="false"/>
        /// </param>
        public static void AddItem(this Chest chest, Item item, bool throwingExcessItems = false) {
            if (item == null || item.IsAir || item.stack <= 0) {
                return;
            }

            Item toAdd = item.Clone();

            //1.先尝试堆叠到已有相同类型的物品
            for (int i = 0; i < chest.item.Length && toAdd.stack > 0; i++) {
                Item slot = chest.item[i];
                if (slot == null || slot.IsAir) {
                    continue;
                }

                if (slot.type == toAdd.type && slot.stack < slot.maxStack) {
                    int transferable = Math.Min(toAdd.stack, slot.maxStack - slot.stack);
                    slot.stack += transferable;
                    toAdd.stack -= transferable;
                }
            }

            //2.然后尝试放到空格子中
            for (int i = 0; i < chest.item.Length && toAdd.stack > 0; i++) {
                Item slot = chest.item[i];
                if (slot == null || slot.IsAir || slot.type == ItemID.None) {
                    chest.item[i] = toAdd.Clone();
                    chest.item[i].stack = Math.Min(toAdd.stack, chest.item[i].maxStack);
                    toAdd.stack -= chest.item[i].stack;
                }
            }

            if (toAdd == null || toAdd.IsAir || toAdd.stack <= 0) {
                return;
            }

            //3.如果还有剩余物品，考虑丢弃
            if (throwingExcessItems) {
                toAdd.SpwanItem(chest.FromObjectGetParent(), chest.GetPoint16().ToWorldCoordinates());
            }
        }

        /// <summary>
        /// 获取箱子的坐标
        /// </summary>
        /// <param name="chest"></param>
        /// <returns></returns>
        public static Point16 GetPoint16(this Chest chest) => new Point16(chest.x, chest.y);

        /// <summary>
        /// 判断一个物品是否可以完整放入指定的箱子中
        /// </summary>
        /// <param name="chest">目标箱子</param>
        /// <param name="item">要尝试放入的物品</param>
        /// <returns>如果该物品可以完全放入箱子，返回 <see langword="true"/>；否则返回 <see langword="false"/></returns>
        public static bool CanItemBeAddedToChest(this Chest chest, Item item) {
            if (item == null || item.IsAir || item.stack <= 0) {
                return false;
            }

            int remaining = item.stack;

            for (int i = 0; i < chest.item.Length && remaining > 0; i++) {
                Item slot = chest.item[i];

                //可堆叠
                if (slot != null && !slot.IsAir && slot.type == item.type && slot.stack < slot.maxStack) {
                    int space = slot.maxStack - slot.stack;
                    remaining -= Math.Min(remaining, space);
                }
                //空格子可用
                else if (slot == null || slot.IsAir || slot.type == ItemID.None) {
                    remaining -= Math.Min(remaining, item.maxStack);
                }
            }

            return remaining <= 0;
        }

        /// <summary>
        /// 判断一个物品是否可以完整放入指定的箱子中
        /// </summary>
        public static bool CanItemBeAddedToChest(this Chest chest) {
            for (int i = 0; i < chest.item.Length; i++) {
                Item item = chest.item[i];
                if (item == null || item.IsAir || item.stack < item.maxStack) {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 在指定位置生成一个物品，生成区域为以 <paramref name="spwanPos"/> 为中心，尺寸为 <paramref name="randomSize"/> 的矩形区域
        /// </summary>
        /// <param name="source">物品生成源（通常为玩家、NPC、事件等）</param>
        /// <param name="spwanPos">中心生成位置</param>
        /// <param name="randomSize">生成区域尺寸，用于制造掉落的“偏移感”</param>
        /// <param name="spwanItem">要生成的物品实例</param>
        /// <param name="netUpdate">是否进行网络同步，默认为 true</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(IEntitySource source, Vector2 spwanPos, Vector2 randomSize, Item spwanItem, bool netUpdate = true) {
            int whoAmi = Item.NewItem(source, spwanPos.GetRectangle(randomSize), spwanItem.Clone());
            if (!isSinglePlayer && netUpdate) {
                NetMessage.SendData(MessageID.SyncItem, -1, -1, null, whoAmi, 0f, 0f, 0f, 0, 0, 0);
            }
            return whoAmi;
        }

        /// <summary>
        /// 在指定位置生成一个物品
        /// </summary>
        /// <param name="spwanItem">要生成的物品</param>
        /// <param name="source">物品生成源</param>
        /// <param name="spwanPos">中心生成位置</param>
        /// <param name="randomSize">生成偏移尺寸</param>
        /// <param name="netUpdate">是否网络同步</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(this Item spwanItem, IEntitySource source, Vector2 spwanPos, Vector2 randomSize, bool netUpdate = true)
            => SpwanItem(source, spwanPos, randomSize, spwanItem, netUpdate);

        /// <summary>
        /// 在指定的矩形区域内生成一个物品
        /// </summary>
        /// <param name="source">物品生成源</param>
        /// <param name="spwanBox">生成区域的矩形框</param>
        /// <param name="spwanItem">要生成的物品实例</param>
        /// <param name="netUpdate">是否网络同步</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(IEntitySource source, Rectangle spwanBox, Item spwanItem, bool netUpdate = true) {
            int whoAmi = Item.NewItem(source, spwanBox, spwanItem.Clone());
            if (!isSinglePlayer && netUpdate) {
                NetMessage.SendData(MessageID.SyncItem, -1, -1, null, whoAmi, 0f, 0f, 0f, 0, 0, 0);
            }
            return whoAmi;
        }

        /// <summary>
        /// 在指定矩形区域内生成一个物品
        /// </summary>
        /// <param name="spwanItem">要生成的物品</param>
        /// <param name="source">生成源</param>
        /// <param name="spwanBox">生成区域</param>
        /// <param name="netUpdate">是否网络同步</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(this Item spwanItem, IEntitySource source, Rectangle spwanBox, bool netUpdate = true)
            => SpwanItem(source, spwanBox, spwanItem, netUpdate);

        /// <summary>
        /// 在指定中心位置生成一个物品，其生成区域大小为该物品尺寸的一半
        /// </summary>
        /// <param name="source">生成源</param>
        /// <param name="spwanPos">生成中心位置</param>
        /// <param name="spwanItem">要生成的物品实例</param>
        /// <param name="netUpdate">是否网络同步</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(IEntitySource source, Vector2 spwanPos, Item spwanItem, bool netUpdate = true) {
            int whoAmi = Item.NewItem(source, spwanPos.GetRectangle(spwanItem.Size / 2), spwanItem.Clone());
            if (!isSinglePlayer && netUpdate) {
                NetMessage.SendData(MessageID.SyncItem, -1, -1, null, whoAmi, 0f, 0f, 0f, 0, 0, 0);
            }
            return whoAmi;
        }

        /// <summary>
        /// 在指定位置生成物品，区域大小为物品尺寸一半
        /// </summary>
        /// <param name="spwanItem">要生成的物品</param>
        /// <param name="source">生成源</param>
        /// <param name="spwanPos">中心生成位置</param>
        /// <param name="netUpdate">是否网络同步</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(this Item spwanItem, IEntitySource source, Vector2 spwanPos, bool netUpdate = true)
            => SpwanItem(source, spwanPos, spwanItem, netUpdate);

        /// <summary>
        /// 在指定中心位置生成一个物品，其生成区域大小为该物品尺寸的一半
        /// </summary>
        /// <param name="source">生成源</param>
        /// <param name="spwanItem">要生成的物品实例</param>
        /// <param name="netUpdate">是否网络同步</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(IEntitySource source, Item spwanItem, bool netUpdate = true) {
            int whoAmi = Item.NewItem(source, spwanItem.position.GetRectangle(spwanItem.Size / 2), spwanItem.Clone());
            if (!isSinglePlayer && netUpdate) {
                NetMessage.SendData(MessageID.SyncItem, -1, -1, null, whoAmi, 0f, 0f, 0f, 0, 0, 0);
            }
            return whoAmi;
        }

        /// <summary>
        /// 在指定位置生成物品，区域大小为物品尺寸一半
        /// </summary>
        /// <param name="spwanItem">要生成的物品</param>
        /// <param name="source">生成源</param>
        /// <param name="netUpdate">是否网络同步</param>
        /// <returns>生成物品的索引 ID</returns>
        public static int SpwanItem(this Item spwanItem, IEntitySource source, bool netUpdate = true)
            => SpwanItem(source, spwanItem, netUpdate);

        /// <summary>
        /// 在游戏中发送文本消息
        /// </summary>
        /// <param name="message">要发送的消息文本</param>
        /// <param name="colour">消息的颜色,默认为 <see langword="null"/></param>
        public static void Text(string message, Color? colour = null) {
            Color newColor = (Color)(colour == null ? Color.White : colour);
            if (isServer) {
                ChatHelper.BroadcastChatMessage(NetworkText.FromLiteral(message), (Color)(colour == null ? Color.White : colour));
                return;
            }
            Main.NewText(message, newColor);
        }

        /// <summary>
        /// 一个根据语言选项返回字符的方法
        /// </summary>
        public static string Translation(string Chinese = null, string English = null, string Spanish = null, string Russian = null) {
            English ??= "Invalid Character";
            string text = Language.ActiveCulture.LegacyId switch {
                (int)GameCulture.CultureName.Chinese => Chinese,
                (int)GameCulture.CultureName.Russian => Russian,
                (int)GameCulture.CultureName.Spanish => Spanish,
                (int)GameCulture.CultureName.English => English,
                _ => English,
            };
            return text;
        }

        /// <summary>
        /// 销毁关于傀儡的物块结构
        /// </summary>
        /// <param name="point16">输入这个傀儡所占图格的任意一点</param>
        public static void KillPuppet(Point16 point16) {
            if (SafeGetTopLeft(point16.X, point16.Y, out Point16 tilePos)) {
                TileObjectData data = TileObjectData.GetTileData(Main.tile[point16]);
                for (int i = 0; i < data.Width; i++) {
                    for (int j = 0; j < data.Height; j++) {
                        Point16 newPoint = point16 + new Point16(i, j);
                        Tile newTile = Main.tile[newPoint];
                        if (newTile.TileType == TileID.TargetDummy) {
                            newTile.TileType = TileID.Dirt;
                            newTile.HasTile = false;
                            WorldGen.SquareTileFrame(newPoint.X, newPoint.Y);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 将文本拆分为多行，并为每行分别添加颜色代码
        /// </summary>
        /// <param name="textContent">输入的文本内容，支持换行符</param>
        /// <param name="color">颜色对象</param>
        /// <returns>格式化后的多行带颜色文本</returns>
        public static string FormatColorTextMultiLine(string textContent, Color color) {
            if (string.IsNullOrEmpty(textContent)) {
                return string.Empty;
            }

            //将颜色转换为 16 进制字符串
            string hexColor = $"{color.R:X2}{color.G:X2}{color.B:X2}";

            //按换行符分割文本
            string[] lines = textContent.Split('\n');

            //对每一行添加颜色代码
            for (int i = 0; i < lines.Length; i++) {
                lines[i] = $"[c/{hexColor}:{lines[i]}]";
            }

            //使用换行符重新组合
            return string.Join("\n", lines);
        }

        /// <summary>
        /// 获取玩家对象一个稳定的中心位置，考虑斜坡矫正与坐骑矫正，适合用于处理手持弹幕的位置获取
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public static Vector2 GetPlayerStabilityCenter(this Player player) => player.MountedCenter.Floor() + new Vector2(0, player.gfxOffY);

        /// <summary>
        /// 计算并获取物品的前缀附加属性
        /// 根据物品的前缀ID，确定前缀所提供的各种属性加成，包括伤害倍率、击退倍率、使用时间倍率、尺寸倍率、射速倍率、法力消耗倍率以及暴击加成，
        /// 并根据这些加成计算出前缀的总体强度。对于模组的前缀，使用自定义的逻辑处理属性加成
        /// </summary>
        /// <param name="item">带有前缀的物品实例</param>
        /// <returns>
        /// 返回包含前缀附加属性的结构体<see cref="PrefixState"/>，
        /// 该结构体中包括前缀ID以及计算得到的属性加成与前缀强度
        /// </returns>
        public static PrefixState GetPrefixState(this Item item) {
            int prefixID = item.prefix;

            PrefixState additionStruct = new PrefixState();

            float strength;
            float damageMult = 1f;
            float knockbackMult = 1f;
            float useTimeMult = 1f;
            float scaleMult = 1f;
            float shootSpeedMult = 1f;
            float manaMult = 1f;
            int critBonus = 0;

            if (prefixID >= PrefixID.Count && prefixID < PrefixLoader.PrefixCount) {
                additionStruct.isModPreFix = true;
                PrefixLoader.GetPrefix(prefixID).SetStats(ref damageMult, ref knockbackMult
                    , ref useTimeMult, ref scaleMult, ref shootSpeedMult, ref manaMult, ref critBonus);
            }
            else {
                additionStruct.isModPreFix = false;
                switch (prefixID) {
                    case 1:
                        scaleMult = 1.12f;
                        break;
                    case 2:
                        scaleMult = 1.18f;
                        break;
                    case 3:
                        damageMult = 1.05f;
                        critBonus = 2;
                        scaleMult = 1.05f;
                        break;
                    case 4:
                        damageMult = 1.1f;
                        scaleMult = 1.1f;
                        knockbackMult = 1.1f;
                        break;
                    case 5:
                        damageMult = 1.15f;
                        break;
                    case 6:
                        damageMult = 1.1f;
                        break;
                    case 81:
                        knockbackMult = 1.15f;
                        damageMult = 1.15f;
                        critBonus = 5;
                        useTimeMult = 0.9f;
                        scaleMult = 1.1f;
                        break;
                    case 7:
                        scaleMult = 0.82f;
                        break;
                    case 8:
                        knockbackMult = 0.85f;
                        damageMult = 0.85f;
                        scaleMult = 0.87f;
                        break;
                    case 9:
                        scaleMult = 0.9f;
                        break;
                    case 10:
                        damageMult = 0.85f;
                        break;
                    case 11:
                        useTimeMult = 1.1f;
                        knockbackMult = 0.9f;
                        scaleMult = 0.9f;
                        break;
                    case 12:
                        knockbackMult = 1.1f;
                        damageMult = 1.05f;
                        scaleMult = 1.1f;
                        useTimeMult = 1.15f;
                        break;
                    case 13:
                        knockbackMult = 0.8f;
                        damageMult = 0.9f;
                        scaleMult = 1.1f;
                        break;
                    case 14:
                        knockbackMult = 1.15f;
                        useTimeMult = 1.1f;
                        break;
                    case 15:
                        knockbackMult = 0.9f;
                        useTimeMult = 0.85f;
                        break;
                    case 16:
                        damageMult = 1.1f;
                        critBonus = 3;
                        break;
                    case 17:
                        useTimeMult = 0.85f;
                        shootSpeedMult = 1.1f;
                        break;
                    case 18:
                        useTimeMult = 0.9f;
                        shootSpeedMult = 1.15f;
                        break;
                    case 19:
                        knockbackMult = 1.15f;
                        shootSpeedMult = 1.05f;
                        break;
                    case 20:
                        knockbackMult = 1.05f;
                        shootSpeedMult = 1.05f;
                        damageMult = 1.1f;
                        useTimeMult = 0.95f;
                        critBonus = 2;
                        break;
                    case 21:
                        knockbackMult = 1.15f;
                        damageMult = 1.1f;
                        break;
                    case 82:
                        knockbackMult = 1.15f;
                        damageMult = 1.15f;
                        critBonus = 5;
                        useTimeMult = 0.9f;
                        shootSpeedMult = 1.1f;
                        break;
                    case 22:
                        knockbackMult = 0.9f;
                        shootSpeedMult = 0.9f;
                        damageMult = 0.85f;
                        break;
                    case 23:
                        useTimeMult = 1.15f;
                        shootSpeedMult = 0.9f;
                        break;
                    case 24:
                        useTimeMult = 1.1f;
                        knockbackMult = 0.8f;
                        break;
                    case 25:
                        useTimeMult = 1.1f;
                        damageMult = 1.15f;
                        critBonus = 1;
                        break;
                    case 58:
                        useTimeMult = 0.85f;
                        damageMult = 0.85f;
                        break;
                    case 26:
                        manaMult = 0.85f;
                        damageMult = 1.1f;
                        break;
                    case 27:
                        manaMult = 0.85f;
                        break;
                    case 28:
                        manaMult = 0.85f;
                        damageMult = 1.15f;
                        knockbackMult = 1.05f;
                        break;
                    case 83:
                        knockbackMult = 1.15f;
                        damageMult = 1.15f;
                        critBonus = 5;
                        useTimeMult = 0.9f;
                        manaMult = 0.9f;
                        break;
                    case 29:
                        manaMult = 1.1f;
                        break;
                    case 30:
                        manaMult = 1.2f;
                        damageMult = 0.9f;
                        break;
                    case 31:
                        knockbackMult = 0.9f;
                        damageMult = 0.9f;
                        break;
                    case 32:
                        manaMult = 1.15f;
                        damageMult = 1.1f;
                        break;
                    case 33:
                        manaMult = 1.1f;
                        knockbackMult = 1.1f;
                        useTimeMult = 0.9f;
                        break;
                    case 34:
                        manaMult = 0.9f;
                        knockbackMult = 1.1f;
                        useTimeMult = 1.1f;
                        damageMult = 1.1f;
                        break;
                    case 35:
                        manaMult = 1.2f;
                        damageMult = 1.15f;
                        knockbackMult = 1.15f;
                        break;
                    case 52:
                        manaMult = 0.9f;
                        damageMult = 0.9f;
                        useTimeMult = 0.9f;
                        break;
                    case 84:
                        knockbackMult = 1.17f;
                        damageMult = 1.17f;
                        critBonus = 8;
                        break;
                    case 36:
                        critBonus = 3;
                        break;
                    case 37:
                        damageMult = 1.1f;
                        critBonus = 3;
                        knockbackMult = 1.1f;
                        break;
                    case 38:
                        knockbackMult = 1.15f;
                        break;
                    case 53:
                        damageMult = 1.1f;
                        break;
                    case 54:
                        knockbackMult = 1.15f;
                        break;
                    case 55:
                        knockbackMult = 1.15f;
                        damageMult = 1.05f;
                        break;
                    case 59:
                        knockbackMult = 1.15f;
                        damageMult = 1.15f;
                        critBonus = 5;
                        break;
                    case 60:
                        damageMult = 1.15f;
                        critBonus = 5;
                        break;
                    case 61:
                        critBonus = 5;
                        break;
                    case 39:
                        damageMult = 0.7f;
                        knockbackMult = 0.8f;
                        break;
                    case 40:
                        damageMult = 0.85f;
                        break;
                    case 56:
                        knockbackMult = 0.8f;
                        break;
                    case 41:
                        knockbackMult = 0.85f;
                        damageMult = 0.9f;
                        break;
                    case 57:
                        knockbackMult = 0.9f;
                        damageMult = 1.18f;
                        break;
                    case 42:
                        useTimeMult = 0.9f;
                        break;
                    case 43:
                        damageMult = 1.1f;
                        useTimeMult = 0.9f;
                        break;
                    case 44:
                        useTimeMult = 0.9f;
                        critBonus = 3;
                        break;
                    case 45:
                        useTimeMult = 0.95f;
                        break;
                    case 46:
                        critBonus = 3;
                        useTimeMult = 0.94f;
                        damageMult = 1.07f;
                        break;
                    case 47:
                        useTimeMult = 1.15f;
                        break;
                    case 48:
                        useTimeMult = 1.2f;
                        break;
                    case 49:
                        useTimeMult = 1.08f;
                        break;
                    case 50:
                        damageMult = 0.8f;
                        useTimeMult = 1.15f;
                        break;
                    case 51:
                        knockbackMult = 0.9f;
                        useTimeMult = 0.9f;
                        damageMult = 1.05f;
                        critBonus = 2;
                        break;
                }
            }

            strength = 1f * damageMult * (2f - useTimeMult) * (2f - manaMult) * scaleMult
                * knockbackMult * shootSpeedMult * (1f + critBonus * 0.02f);
            if (prefixID == 62 || prefixID == 69 || prefixID == 73 || prefixID == 77)
                strength *= 1.05f;

            if (prefixID == 63 || prefixID == 70 || prefixID == 74 || prefixID == 78 || prefixID == 67)
                strength *= 1.1f;

            if (prefixID == 64 || prefixID == 71 || prefixID == 75 || prefixID == 79 || prefixID == 66)
                strength *= 1.15f;

            if (prefixID == 65 || prefixID == 72 || prefixID == 76 || prefixID == 80 || prefixID == 68)
                strength *= 1.2f;

            additionStruct.prefixID = prefixID;
            additionStruct.damageMult = damageMult;
            additionStruct.knockbackMult = knockbackMult;
            additionStruct.useTimeMult = useTimeMult;
            additionStruct.scaleMult = scaleMult;
            additionStruct.shootSpeedMult = shootSpeedMult;
            additionStruct.manaMult = manaMult;
            additionStruct.critBonus = critBonus;
            additionStruct.strength = strength;

            return additionStruct;
        }

        /// <summary>
        /// 获取玩家当前射击状态，包括武器的伤害、击退、弹药类型等信息
        /// 该方法根据玩家当前装备的武器以及所用的弹药类型来计算并返回完整的射击状态
        /// </summary>
        /// <param name="player">玩家实例，代表调用该方法的玩家对象</param>
        /// <param name="shootKey">一个可选的标识符，用于区分不同的射击事件，默认为 "Null" 表示不使用特定键值</param>
        /// <returns>返回一个包含射击相关信息的 <see cref="ShootState"/> 结构体</returns>
        public static ShootState GetShootState(this Player player, string shootKey = "Null") {
            ShootState shootState = new();
            Item item = player.GetItem();
            if (item.useAmmo == AmmoID.None) {
                shootState.WeaponDamage = player.GetWeaponDamage(item);
                shootState.WeaponKnockback = item.knockBack;
                shootState.AmmoTypes = item.shoot;
                shootState.ShootSpeed = item.shootSpeed;
                shootState.UseAmmoItemType = ItemID.None;
                shootState.HasAmmo = false;
                if (shootState.AmmoTypes == 0 || shootState.AmmoTypes == 10) {
                    shootState.AmmoTypes = ProjectileID.Bullet;
                }
                return shootState;
            }
            shootState.HasAmmo = player.PickAmmo(item, out shootState.AmmoTypes, out shootState.ShootSpeed
                , out shootState.WeaponDamage, out shootState.WeaponKnockback, out shootState.UseAmmoItemType, true);
            if (shootKey == "Null") {
                shootKey = null;
            }
            shootState.Source = new EntitySource_ItemUse_WithAmmo(player, item, shootState.UseAmmoItemType, shootKey);
            return shootState;
        }

        /// <summary>
        /// 获取玩家当前的弹药状态，包括所有有效的弹药类型、对应的物品、以及物品的数量等信息
        /// </summary>
        /// <param name="player">玩家实例，代表调用该方法的玩家对象</param>
        /// <param name="assignAmmoType">指定的弹药类型，默认为 0，表示不限制弹药类型。如果指定某个类型，则只返回该类型的弹药</param>
        /// <param name="numSort">是否对弹药物品进行排序，默认为 false。如果为 true，则按照物品堆叠数量降序排序</param>
        /// <returns>返回一个包含当前弹药状态信息的 <see cref="AmmoState"/> 结构体</returns>
        public static AmmoState GetAmmoState(this Player player, int assignAmmoType = 0, bool numSort = false) {
            AmmoState ammoState = new();
            int num = 0;  //当前弹药总数量
            List<Item> itemInds = new();  //存储有效的弹药物品
            List<int> itemTypes = new();  //存储弹药物品的类型
            List<int> itemShootTypes = new();  //存储弹药发射类型（即射击类型）

            //遍历玩家背包中的所有物品
            foreach (Item item in player.inventory) {
                //跳过没有弹药的物品
                if (item.ammo == AmmoID.None) {
                    continue;
                }

                //如果指定了弹药类型并且物品的弹药类型不匹配，跳过该物品
                if (assignAmmoType != 0 && item.ammo != assignAmmoType) {
                    continue;
                }

                //添加物品类型、射击类型及堆叠数量
                itemTypes.Add(item.type);
                itemShootTypes.Add(item.shoot);
                num += item.stack;  //累加物品的堆叠数量
            }

            //遍历玩家快捷栏中的物品（位置从54到57）
            for (int i = 54; i < 58; i++) {
                Item item = player.inventory[i];
                //如果指定了弹药类型并且物品的弹药类型不匹配，或者物品没有弹药，跳过
                if ((assignAmmoType != 0 && item.ammo != assignAmmoType) || item.ammo == AmmoID.None) {
                    continue;
                }
                itemInds.Add(player.inventory[i]);
            }

            //遍历玩家背包的前54个物品
            for (int i = 0; i < 54; i++) {
                Item item = player.inventory[i];
                //如果指定了弹药类型并且物品的弹药类型不匹配，或者物品没有弹药，跳过
                if ((assignAmmoType != 0 && item.ammo != assignAmmoType) || item.ammo == AmmoID.None) {
                    continue;
                }
                itemInds.Add(player.inventory[i]);
            }

            //如果需要排序，则按堆叠数量降序排序
            if (numSort) {
                itemInds = itemInds.OrderByDescending(item => item.stack).ToList();
            }

            //设置返回的弹药状态信息
            ammoState.ValidProjectileIDs = itemShootTypes.ToArray();  //有效的弹药发射类型
            ammoState.CurrentItems = itemInds.ToArray();  //当前有效的弹药物品
            ammoState.ValidItemIDs = itemTypes.ToArray();  //有效的弹药物品类型
            ammoState.CurrentAmount = num;  //当前弹药总数量

            //设置最大和最小数量的物品
            if (itemInds.Count > 0) {
                ammoState.MaxAmountItem = itemInds[0];  //最大数量的物品
                ammoState.MinAmountItem = itemInds[^1];  //最小数量的物品
            }
            else {
                ammoState.MaxAmountItem = new Item();  //若无有效物品，返回空物品
                ammoState.MinAmountItem = new Item();  //若无有效物品，返回空物品
            }

            return ammoState;
        }

        /// <summary>
        /// 获取玩家选中的物品实例
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public static Item GetItem(this Player player) => Main.mouseItem.IsAir ? player.inventory[player.selectedItem] : Main.mouseItem;

        /// <summary>
        /// 物品掉落扫描工具
        /// </summary>
        public static class ItemDropScanner
        {
            #region 基础扫描方法，不进行条件判断

            /// <summary>
            /// 获取物品右键打开后可能掉落的所有物品类型ID
            /// </summary>
            /// <param name="itemType">要扫描的物品类型ID（如宝藏袋）</param>
            /// <param name="includeConditional">是否包含有条件的掉落物</param>
            /// <returns>所有可能掉落的物品类型ID集合</returns>
            public static HashSet<int> GetItemDrops(int itemType, bool includeConditional = true) {
                HashSet<int> drops = [];

                List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForItemID(itemType);

                foreach (var rule in dropRules) {
                    CollectDropsFromRule(rule, drops, includeConditional);
                }

                return drops;
            }

            /// <summary>
            /// 获取物品右键打开后可能掉落的所有物品，包含数量信息
            /// </summary>
            /// <param name="itemType">要扫描的物品类型ID</param>
            /// <param name="includeConditional">是否包含有条件的掉落物</param>
            /// <returns>物品掉落信息列表</returns>
            public static List<DropInfo> GetItemDropsWithInfo(int itemType, bool includeConditional = true) {
                List<DropInfo> drops = [];

                List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForItemID(itemType);

                foreach (var rule in dropRules) {
                    CollectDropInfoFromRule(rule, drops, includeConditional);
                }

                return drops;
            }

            #endregion

            #region 带条件判断的扫描方法

            /// <summary>
            /// 创建用于物品掉落的 DropAttemptInfo 上下文
            /// </summary>
            /// <param name="player">玩家实例</param>
            /// <param name="item">触发掉落的物品（可选）</param>
            /// <param name="npc">关联的NPC（可选，用于Boss袋等）</param>
            /// <param name="isExpertMode">是否专家模式（默认使用当前世界设置）</param>
            /// <param name="isMasterMode">是否大师模式（默认使用当前世界设置）</param>
            /// <returns>构建好的 DropAttemptInfo</returns>
            public static DropAttemptInfo CreateDropContext(
                Player player = null,
                Item item = null,
                NPC npc = null,
                bool? isExpertMode = null,
                bool? isMasterMode = null) {
                return new DropAttemptInfo {
                    player = player ?? Main.LocalPlayer,
                    item = (item == null ? ItemID.None : item.type),
                    npc = npc,
                    IsExpertMode = isExpertMode ?? Main.expertMode,
                    IsMasterMode = isMasterMode ?? Main.masterMode,
                    IsInSimulation = false,
                    rng = Main.rand
                };
            }

            /// <summary>
            /// 获取物品右键打开后满足条件的掉落物品类型ID
            /// </summary>
            /// <param name="itemType">要扫描的物品类型ID</param>
            /// <param name="context">掉落上下文信息</param>
            /// <returns>满足条件的物品类型ID集合</returns>
            public static HashSet<int> GetItemDropsWithContext(int itemType, DropAttemptInfo context) {
                HashSet<int> drops = [];

                List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForItemID(itemType);

                foreach (var rule in dropRules) {
                    CollectDropsFromRuleWithContext(rule, drops, context);
                }

                return drops;
            }

            /// <summary>
            /// 获取物品右键打开后满足条件的掉落物品，包含数量信息
            /// </summary>
            /// <param name="itemType">要扫描的物品类型ID</param>
            /// <param name="context">掉落上下文信息</param>
            /// <returns>满足条件的物品掉落信息列表</returns>
            public static List<DropInfo> GetItemDropsWithInfoAndContext(int itemType, DropAttemptInfo context) {
                List<DropInfo> drops = [];

                List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForItemID(itemType);

                foreach (var rule in dropRules) {
                    CollectDropInfoFromRuleWithContext(rule, drops, context);
                }

                return drops;
            }

            /// <summary>
            /// 使用玩家上下文获取满足条件的掉落物品
            /// </summary>
            /// <param name="itemType">要扫描的物品类型ID</param>
            /// <param name="player">玩家实例</param>
            /// <param name="npc">关联的NPC（可选）</param>
            /// <returns>满足条件的物品掉落信息列表</returns>
            public static List<DropInfo> GetItemDropsForPlayer(int itemType, Player player, NPC npc = null) {
                var context = CreateDropContext(player: player, npc: npc);
                return GetItemDropsWithInfoAndContext(itemType, context);
            }

            /// <summary>
            /// 模拟一次完整的物品掉落，返回实际会掉落的物品
            /// </summary>
            /// <param name="itemType">要扫描的物品类型ID</param>
            /// <param name="context">掉落上下文信息</param>
            /// <param name="simulateRandomChance">是否模拟随机概率（true则按概率决定是否掉落，false则返回所有可能掉落）</param>
            /// <returns>模拟掉落的物品列表</returns>
            public static List<DropInfo> SimulateItemDrops(int itemType, DropAttemptInfo context, bool simulateRandomChance = false) {
                List<DropInfo> drops = [];

                List<IItemDropRule> dropRules = Main.ItemDropsDB.GetRulesForItemID(itemType);

                foreach (var rule in dropRules) {
                    SimulateDropFromRule(rule, drops, context, simulateRandomChance);
                }

                return drops;
            }

            #endregion

            #region 带条件判断的递归收集方法

            /// <summary>
            /// 从掉落规则中递归收集物品类型，带条件判断
            /// </summary>
            private static void CollectDropsFromRuleWithContext(IItemDropRule rule, HashSet<int> drops, DropAttemptInfo context) {
                //首先检查规则的条件是否满足
                if (!CheckRuleCondition(rule, context)) {
                    return;
                }

                switch (rule) {
                    case CommonDrop commonDrop:
                        drops.Add(commonDrop.itemId);
                        break;

                    case DropOneByOne dropOneByOne:
                        drops.Add(dropOneByOne.itemId);
                        break;

                    case DropBasedOnExpertMode expertDrop:
                        if (context.IsExpertMode) {
                            CollectDropsFromRuleWithContext(expertDrop.ruleForExpertMode, drops, context);
                        }
                        else {
                            CollectDropsFromRuleWithContext(expertDrop.ruleForNormalMode, drops, context);
                        }
                        break;

                    case DropBasedOnMasterMode masterDrop:
                        if (context.IsMasterMode) {
                            CollectDropsFromRuleWithContext(masterDrop.ruleForMasterMode, drops, context);
                        }
                        else {
                            CollectDropsFromRuleWithContext(masterDrop.ruleForDefault, drops, context);
                        }
                        break;

                    case LeadingConditionRule leadingRule:
                        if (leadingRule.condition.CanDrop(context)) {
                            foreach (var chainedRule in leadingRule.ChainedRules) {
                                CollectDropsFromRuleWithContext(chainedRule.RuleToChain, drops, context);
                            }
                        }
                        break;

                    case OneFromOptionsDropRule oneFromOptions:
                        foreach (int dropId in oneFromOptions.dropIds) {
                            drops.Add(dropId);
                        }
                        break;

                    case OneFromOptionsNotScaledWithLuckDropRule oneFromOptionsNoLuck:
                        foreach (int dropId in oneFromOptionsNoLuck.dropIds) {
                            drops.Add(dropId);
                        }
                        break;

                    case OneFromRulesRule oneFromRules:
                        foreach (var subRule in oneFromRules.options) {
                            CollectDropsFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case FewFromRulesRule fewFromRules:
                        foreach (var subRule in fewFromRules.options) {
                            CollectDropsFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case AlwaysAtleastOneSuccessDropRule atLeastOne:
                        foreach (var subRule in atLeastOne.rules) {
                            CollectDropsFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case SequentialRulesRule sequentialRules:
                        foreach (var subRule in sequentialRules.rules) {
                            CollectDropsFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case SequentialRulesNotScalingWithLuckRule sequentialNoLuck:
                        foreach (var subRule in sequentialNoLuck.rules) {
                            CollectDropsFromRuleWithContext(subRule, drops, context);
                        }
                        break;
                }

                //处理链式规则
                if (rule.ChainedRules != null) {
                    foreach (var chainedRule in rule.ChainedRules) {
                        CollectDropsFromRuleWithContext(chainedRule.RuleToChain, drops, context);
                    }
                }
            }

            /// <summary>
            /// 从掉落规则中递归收集物品信息（带条件判断）
            /// </summary>
            private static void CollectDropInfoFromRuleWithContext(IItemDropRule rule, List<DropInfo> drops, DropAttemptInfo context) {
                //首先检查规则的条件是否满足
                if (!CheckRuleCondition(rule, context)) {
                    return;
                }

                switch (rule) {
                    case CommonDrop commonDrop:
                        drops.Add(new DropInfo {
                            ItemType = commonDrop.itemId,
                            MinStack = commonDrop.amountDroppedMinimum,
                            MaxStack = commonDrop.amountDroppedMaximum,
                            DropChanceDenominator = commonDrop.chanceDenominator,
                            IsConditional = false
                        });
                        break;

                    case DropOneByOne dropOneByOne:
                        drops.Add(new DropInfo {
                            ItemType = dropOneByOne.itemId,
                            MinStack = dropOneByOne.parameters.MinimumItemDropsCount,
                            MaxStack = dropOneByOne.parameters.MaximumItemDropsCount,
                            DropChanceDenominator = dropOneByOne.parameters.ChanceDenominator,
                            IsConditional = false
                        });
                        break;

                    case DropBasedOnExpertMode expertDrop:
                        if (context.IsExpertMode) {
                            CollectDropInfoFromRuleWithContext(expertDrop.ruleForExpertMode, drops, context);
                        }
                        else {
                            CollectDropInfoFromRuleWithContext(expertDrop.ruleForNormalMode, drops, context);
                        }
                        break;

                    case DropBasedOnMasterMode masterDrop:
                        if (context.IsMasterMode) {
                            CollectDropInfoFromRuleWithContext(masterDrop.ruleForMasterMode, drops, context);
                        }
                        else {
                            CollectDropInfoFromRuleWithContext(masterDrop.ruleForDefault, drops, context);
                        }
                        break;

                    case LeadingConditionRule leadingRule:
                        if (leadingRule.condition.CanDrop(context)) {
                            foreach (var chainedRule in leadingRule.ChainedRules) {
                                CollectDropInfoFromRuleWithContext(chainedRule.RuleToChain, drops, context);
                            }
                        }
                        break;

                    case OneFromOptionsDropRule oneFromOptions:
                        foreach (int dropId in oneFromOptions.dropIds) {
                            drops.Add(new DropInfo {
                                ItemType = dropId,
                                MinStack = 1,
                                MaxStack = 1,
                                DropChanceDenominator = oneFromOptions.chanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case OneFromOptionsNotScaledWithLuckDropRule oneFromOptionsNoLuck:
                        foreach (int dropId in oneFromOptionsNoLuck.dropIds) {
                            drops.Add(new DropInfo {
                                ItemType = dropId,
                                MinStack = 1,
                                MaxStack = 1,
                                DropChanceDenominator = oneFromOptionsNoLuck.chanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case OneFromRulesRule oneFromRules:
                        foreach (var subRule in oneFromRules.options) {
                            CollectDropInfoFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case FewFromRulesRule fewFromRules:
                        foreach (var subRule in fewFromRules.options) {
                            CollectDropInfoFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case AlwaysAtleastOneSuccessDropRule atLeastOne:
                        foreach (var subRule in atLeastOne.rules) {
                            CollectDropInfoFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case SequentialRulesRule sequentialRules:
                        foreach (var subRule in sequentialRules.rules) {
                            CollectDropInfoFromRuleWithContext(subRule, drops, context);
                        }
                        break;

                    case SequentialRulesNotScalingWithLuckRule sequentialNoLuck:
                        foreach (var subRule in sequentialNoLuck.rules) {
                            CollectDropInfoFromRuleWithContext(subRule, drops, context);
                        }
                        break;
                }

                //处理链式规则
                if (rule.ChainedRules != null) {
                    foreach (var chainedRule in rule.ChainedRules) {
                        CollectDropInfoFromRuleWithContext(chainedRule.RuleToChain, drops, context);
                    }
                }
            }

            /// <summary>
            /// 模拟掉落规则
            /// </summary>
            private static void SimulateDropFromRule(IItemDropRule rule, List<DropInfo> drops, DropAttemptInfo context, bool simulateRandomChance) {
                //首先检查规则的条件是否满足
                if (!CheckRuleCondition(rule, context)) {
                    return;
                }

                switch (rule) {
                    case CommonDrop commonDrop:
                        if (!simulateRandomChance || context.rng.Next(commonDrop.chanceDenominator) < commonDrop.chanceNumerator) {
                            int stack = context.rng.Next(commonDrop.amountDroppedMinimum, commonDrop.amountDroppedMaximum + 1);
                            drops.Add(new DropInfo {
                                ItemType = commonDrop.itemId,
                                MinStack = stack,
                                MaxStack = stack,
                                DropChanceDenominator = commonDrop.chanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case DropOneByOne dropOneByOne:
                        if (!simulateRandomChance || context.rng.Next(dropOneByOne.parameters.ChanceDenominator) < dropOneByOne.parameters.ChanceNumerator) {
                            int stack = context.rng.Next(dropOneByOne.parameters.MinimumItemDropsCount, dropOneByOne.parameters.MaximumItemDropsCount + 1);
                            drops.Add(new DropInfo {
                                ItemType = dropOneByOne.itemId,
                                MinStack = stack,
                                MaxStack = stack,
                                DropChanceDenominator = dropOneByOne.parameters.ChanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case DropBasedOnExpertMode expertDrop:
                        if (context.IsExpertMode) {
                            SimulateDropFromRule(expertDrop.ruleForExpertMode, drops, context, simulateRandomChance);
                        }
                        else {
                            SimulateDropFromRule(expertDrop.ruleForNormalMode, drops, context, simulateRandomChance);
                        }
                        break;

                    case DropBasedOnMasterMode masterDrop:
                        if (context.IsMasterMode) {
                            SimulateDropFromRule(masterDrop.ruleForMasterMode, drops, context, simulateRandomChance);
                        }
                        else {
                            SimulateDropFromRule(masterDrop.ruleForDefault, drops, context, simulateRandomChance);
                        }
                        break;

                    case LeadingConditionRule leadingRule:
                        if (leadingRule.condition.CanDrop(context)) {
                            foreach (var chainedRule in leadingRule.ChainedRules) {
                                SimulateDropFromRule(chainedRule.RuleToChain, drops, context, simulateRandomChance);
                            }
                        }
                        break;

                    case OneFromOptionsDropRule oneFromOptions:
                        if (!simulateRandomChance || context.rng.Next(oneFromOptions.chanceDenominator) < oneFromOptions.chanceNumerator) {
                            int selectedIndex = context.rng.Next(oneFromOptions.dropIds.Length);
                            drops.Add(new DropInfo {
                                ItemType = oneFromOptions.dropIds[selectedIndex],
                                MinStack = 1,
                                MaxStack = 1,
                                DropChanceDenominator = oneFromOptions.chanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case OneFromOptionsNotScaledWithLuckDropRule oneFromOptionsNoLuck:
                        if (!simulateRandomChance || context.rng.Next(oneFromOptionsNoLuck.chanceDenominator) < oneFromOptionsNoLuck.chanceNumerator) {
                            int selectedIndex = context.rng.Next(oneFromOptionsNoLuck.dropIds.Length);
                            drops.Add(new DropInfo {
                                ItemType = oneFromOptionsNoLuck.dropIds[selectedIndex],
                                MinStack = 1,
                                MaxStack = 1,
                                DropChanceDenominator = oneFromOptionsNoLuck.chanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case OneFromRulesRule oneFromRules:
                        if (simulateRandomChance) {
                            int selectedIndex = context.rng.Next(oneFromRules.options.Length);
                            SimulateDropFromRule(oneFromRules.options[selectedIndex], drops, context, simulateRandomChance);
                        }
                        else {
                            foreach (var subRule in oneFromRules.options) {
                                SimulateDropFromRule(subRule, drops, context, simulateRandomChance);
                            }
                        }
                        break;

                    case FewFromRulesRule fewFromRules:
                        foreach (var subRule in fewFromRules.options) {
                            SimulateDropFromRule(subRule, drops, context, simulateRandomChance);
                        }
                        break;

                    case AlwaysAtleastOneSuccessDropRule atLeastOne:
                        foreach (var subRule in atLeastOne.rules) {
                            SimulateDropFromRule(subRule, drops, context, simulateRandomChance);
                        }
                        break;

                    case SequentialRulesRule sequentialRules:
                        foreach (var subRule in sequentialRules.rules) {
                            SimulateDropFromRule(subRule, drops, context, simulateRandomChance);
                        }
                        break;

                    case SequentialRulesNotScalingWithLuckRule sequentialNoLuck:
                        foreach (var subRule in sequentialNoLuck.rules) {
                            SimulateDropFromRule(subRule, drops, context, simulateRandomChance);
                        }
                        break;
                }

                //处理链式规则
                if (rule.ChainedRules != null) {
                    foreach (var chainedRule in rule.ChainedRules) {
                        SimulateDropFromRule(chainedRule.RuleToChain, drops, context, simulateRandomChance);
                    }
                }
            }

            /// <summary>
            /// 检查掉落规则的条件是否满足
            /// </summary>
            private static bool CheckRuleCondition(IItemDropRule rule, DropAttemptInfo context) {
                //使用规则自身的 CanDrop 方法来检查条件
                return rule.CanDrop(context);
            }

            #endregion

            #region 基础递归收集方法，不进行条件判断

            /// <summary>
            /// 从掉落规则中递归收集物品类型
            /// </summary>
            private static void CollectDropsFromRule(IItemDropRule rule, HashSet<int> drops, bool includeConditional) {
                //检查规则类型并提取物品ID
                switch (rule) {
                    case CommonDrop commonDrop:
                        drops.Add(commonDrop.itemId);
                        break;

                    case DropOneByOne dropOneByOne:
                        drops.Add(dropOneByOne.itemId);
                        break;

                    case DropBasedOnExpertMode expertDrop:
                        CollectDropsFromRule(expertDrop.ruleForNormalMode, drops, includeConditional);
                        CollectDropsFromRule(expertDrop.ruleForExpertMode, drops, includeConditional);
                        break;

                    case DropBasedOnMasterMode masterDrop:
                        CollectDropsFromRule(masterDrop.ruleForDefault, drops, includeConditional);
                        CollectDropsFromRule(masterDrop.ruleForMasterMode, drops, includeConditional);
                        break;

                    case LeadingConditionRule leadingRule:
                        if (includeConditional) {
                            foreach (var chainedRule in leadingRule.ChainedRules) {
                                CollectDropsFromRule(chainedRule.RuleToChain, drops, includeConditional);
                            }
                        }
                        break;

                    case OneFromOptionsDropRule oneFromOptions:
                        foreach (int dropId in oneFromOptions.dropIds) {
                            drops.Add(dropId);
                        }
                        break;

                    case OneFromOptionsNotScaledWithLuckDropRule oneFromOptionsNoLuck:
                        foreach (int dropId in oneFromOptionsNoLuck.dropIds) {
                            drops.Add(dropId);
                        }
                        break;

                    case OneFromRulesRule oneFromRules:
                        foreach (var subRule in oneFromRules.options) {
                            CollectDropsFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case FewFromRulesRule fewFromRules:
                        foreach (var subRule in fewFromRules.options) {
                            CollectDropsFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case AlwaysAtleastOneSuccessDropRule atLeastOne:
                        foreach (var subRule in atLeastOne.rules) {
                            CollectDropsFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case SequentialRulesRule sequentialRules:
                        foreach (var subRule in sequentialRules.rules) {
                            CollectDropsFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case SequentialRulesNotScalingWithLuckRule sequentialNoLuck:
                        foreach (var subRule in sequentialNoLuck.rules) {
                            CollectDropsFromRule(subRule, drops, includeConditional);
                        }
                        break;
                }

                //处理链式规则
                if (rule.ChainedRules != null) {
                    foreach (var chainedRule in rule.ChainedRules) {
                        CollectDropsFromRule(chainedRule.RuleToChain, drops, includeConditional);
                    }
                }
            }

            /// <summary>
            /// 从掉落规则中递归收集物品信息
            /// </summary>
            private static void CollectDropInfoFromRule(IItemDropRule rule, List<DropInfo> drops, bool includeConditional) {
                switch (rule) {
                    case CommonDrop commonDrop:
                        drops.Add(new DropInfo {
                            ItemType = commonDrop.itemId,
                            MinStack = commonDrop.amountDroppedMinimum,
                            MaxStack = commonDrop.amountDroppedMaximum,
                            DropChanceDenominator = commonDrop.chanceDenominator,
                            IsConditional = false
                        });
                        break;

                    case DropOneByOne dropOneByOne:
                        drops.Add(new DropInfo {
                            ItemType = dropOneByOne.itemId,
                            MinStack = dropOneByOne.parameters.MinimumItemDropsCount,
                            MaxStack = dropOneByOne.parameters.MaximumItemDropsCount,
                            DropChanceDenominator = dropOneByOne.parameters.ChanceDenominator,
                            IsConditional = false
                        });
                        break;

                    case DropBasedOnExpertMode expertDrop:
                        CollectDropInfoFromRule(expertDrop.ruleForNormalMode, drops, includeConditional);
                        CollectDropInfoFromRule(expertDrop.ruleForExpertMode, drops, includeConditional);
                        break;

                    case DropBasedOnMasterMode masterDrop:
                        CollectDropInfoFromRule(masterDrop.ruleForDefault, drops, includeConditional);
                        CollectDropInfoFromRule(masterDrop.ruleForMasterMode, drops, includeConditional);
                        break;

                    case LeadingConditionRule leadingRule:
                        if (includeConditional) {
                            foreach (var chainedRule in leadingRule.ChainedRules) {
                                CollectDropInfoFromRule(chainedRule.RuleToChain, drops, includeConditional);
                            }
                        }
                        break;

                    case OneFromOptionsDropRule oneFromOptions:
                        foreach (int dropId in oneFromOptions.dropIds) {
                            drops.Add(new DropInfo {
                                ItemType = dropId,
                                MinStack = 1,
                                MaxStack = 1,
                                DropChanceDenominator = oneFromOptions.chanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case OneFromOptionsNotScaledWithLuckDropRule oneFromOptionsNoLuck:
                        foreach (int dropId in oneFromOptionsNoLuck.dropIds) {
                            drops.Add(new DropInfo {
                                ItemType = dropId,
                                MinStack = 1,
                                MaxStack = 1,
                                DropChanceDenominator = oneFromOptionsNoLuck.chanceDenominator,
                                IsConditional = false
                            });
                        }
                        break;

                    case OneFromRulesRule oneFromRules:
                        foreach (var subRule in oneFromRules.options) {
                            CollectDropInfoFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case FewFromRulesRule fewFromRules:
                        foreach (var subRule in fewFromRules.options) {
                            CollectDropInfoFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case AlwaysAtleastOneSuccessDropRule atLeastOne:
                        foreach (var subRule in atLeastOne.rules) {
                            CollectDropInfoFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case SequentialRulesRule sequentialRules:
                        foreach (var subRule in sequentialRules.rules) {
                            CollectDropInfoFromRule(subRule, drops, includeConditional);
                        }
                        break;

                    case SequentialRulesNotScalingWithLuckRule sequentialNoLuck:
                        foreach (var subRule in sequentialNoLuck.rules) {
                            CollectDropInfoFromRule(subRule, drops, includeConditional);
                        }
                        break;
                }

                //处理链式规则
                if (rule.ChainedRules != null) {
                    foreach (var chainedRule in rule.ChainedRules) {
                        CollectDropInfoFromRule(chainedRule.RuleToChain, drops, includeConditional);
                    }
                }
            }

            /// <summary>
            /// 掉落物信息结构
            /// </summary>
            public struct DropInfo
            {
                /// <summary>
                /// 物品类型ID
                /// </summary>
                public int ItemType;
                /// <summary>
                /// 最小堆叠数量
                /// </summary>
                public int MinStack;
                /// <summary>
                /// 最大堆叠数量
                /// </summary>
                public int MaxStack;
                /// <summary>
                /// 掉落概率分母（1/N 的概率）
                /// </summary>
                public int DropChanceDenominator;
                /// <summary>
                /// 是否是有条件的掉落
                /// </summary>
                public bool IsConditional;

                /// <summary>
                /// 获取物品名称
                /// </summary>
                public readonly string GetItemName() {
                    Item item = new Item();
                    item.SetDefaults(ItemType);
                    return item.Name;
                }

                /// <summary>
                /// 获取掉落概率百分比字符串
                /// </summary>
                public readonly string GetChancePercent() {
                    if (DropChanceDenominator <= 0) return "100%";
                    float percent = 100f / DropChanceDenominator;
                    return $"{percent:F1}%";
                }
            }

            #endregion
        }
        #endregion

        #region Net
#pragma warning disable IDE1006 //命名样式
        /// <summary>
        /// 判断是否处于客户端状态，如果是在单人或者服务端下将返回 <see langword="false"/>
        /// </summary>
        public static bool isClient => Main.netMode == NetmodeID.MultiplayerClient;
        /// <summary>
        /// 判断是否处于服务端状态，如果是在单人或者客户端下将返回 <see langword="false"/>
        /// </summary>
        public static bool isServer => Main.netMode == NetmodeID.Server;
        /// <summary>
        /// 仅判断是否处于单人状态，在单人模式下返回 <see langword="true"/>
        /// </summary>
        public static bool isSinglePlayer => Main.netMode == NetmodeID.SinglePlayer;
#pragma warning restore IDE1006 //命名样式
        /// <summary>
        /// 检查一个 <see cref="Projectile"/> 对象是否属于当前客户端玩家拥有的，如果是，返回 <see langword="true"/>
        /// </summary>
        public static bool IsOwnedByLocalPlayer(this Projectile projectile) => projectile.owner == Main.myPlayer;

        /// <summary>
        /// 尝试在考虑网络状态的前提下生成一个 Boss NPC
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="player">触发生成的玩家实例</param>
        /// <param name="checkLocalPlayer">是否只允许本地玩家触发生成</param>
        /// <returns></returns>
        public static bool TrySpawnBossWithNet<T>(Player player, bool checkLocalPlayer = true) where T : ModNPC
            => TrySpawnBossWithNet(player, ModContent.NPCType<T>(), checkLocalPlayer);

        /// <summary>
        /// 尝试在考虑网络状态的前提下生成一个 Boss NPC
        /// </summary>
        /// <param name="player">触发生成的玩家实例</param>
        /// <param name="bossType">要生成的 Boss 的类型</param>
        /// <param name="checkLocalPlayer">是否只允许本地玩家触发生成</param>
        /// <returns>是否成功发起了 Boss 的生成请求</returns>
        public static bool TrySpawnBossWithNet(Player player, int bossType, bool checkLocalPlayer = true) {
            //若启用了本地玩家检查，但当前玩家不是本地玩家，则中止
            if (checkLocalPlayer && player.whoAmI != Main.myPlayer) {
                return false;
            }

            SoundEngine.PlaySound(SoundID.Roar, player.position);

            if (isSinglePlayer || isServer) {
                //本地或服务器：直接生成 Boss
                NPC.SpawnOnPlayer(player.whoAmI, bossType);
                return true;
            }
            else if (isClient) {
                //多人客户端：发送生成请求给服务器
                NetMessage.SendData(MessageID.SpawnBossUseLicenseStartEvent, number: player.whoAmI, number2: bossType);
                return true;
            }

            //不在任何有效模式下
            return false;
        }


        /// <summary>
        /// 发送关于一个<see cref="Point16"/>结构的网络数据
        /// </summary>
        /// <param name="modPacket"></param>
        /// <param name="point16"></param>
        public static void WritePoint16(this ModPacket modPacket, Point16 point16) {
            modPacket.Write(point16.X);
            modPacket.Write(point16.Y);
        }

        /// <summary>
        /// 发送关于一个<see cref="Point16"/>结构的网络数据
        /// </summary>
        /// <param name="writer"></param>
        /// <param name="point16"></param>
        public static void WritePoint16(this BinaryWriter writer, Point16 point16) {
            writer.Write(point16.X);
            writer.Write(point16.Y);
        }

        /// <summary>
        /// 接收关于一个<see cref="Point16"/>结构的网络数据
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static Point16 ReadPoint16(this BinaryReader reader) => new Point16(reader.ReadInt16(), reader.ReadInt16());

        /// <summary>
        /// 发送关于一个<see cref="Point"/>结构的网络数据
        /// </summary>
        /// <param name="writer"></param>
        /// <param name="point"></param>
        public static void WritePoint(this BinaryWriter writer, Point point) {
            writer.Write(point.X);
            writer.Write(point.Y);
        }

        /// <summary>
        /// 接收关于一个<see cref="Point"/>结构的网络数据
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static Point ReadPoint(this BinaryReader reader) => new Point(reader.ReadInt32(), reader.ReadInt32());
        #endregion

        #region Tile
        /// <summary>
        /// 获取给定坐标的物块左上角位置，并判断该位置是否为多结构物块的左上角
        /// </summary>
        /// <param name="i">物块的x坐标</param>
        /// <param name="j">物块的y坐标</param>
        /// <returns>
        /// 如果物块存在并且位于一个多结构物块的左上角，返回其左上角坐标，否则返回null
        /// </returns>
        public static Point16? GetTopLeftOrNull(int i, int j) {
            //获取给定坐标的物块
            Tile tile = Framing.GetTileSafely(i, j);

            //一个关于TP的G钩子，用于修改一些特殊物块对于TP的实体的判定
            if (TileProcessorLoader.TargetTileTypes.Contains(tile.TileType)) {
                Point16? gPoint = null;
                foreach (var gTP in TileProcessorLoader.HookGetTopLeftOrNull.Enumerate()) {
                    Point16? newGPoint = gTP.GetTopLeftOrNull(tile, i, j);
                    if (newGPoint.HasValue) {
                        gPoint = newGPoint;
                    }
                }
                if (gPoint.HasValue) {
                    return gPoint.Value;
                }
            }

            //如果没有物块，返回null
            if (!tile.HasTile) {
                return null;
            }

            //获取物块的数据结构，如果为null则认为是单个物块
            TileObjectData data = TileObjectData.GetTileData(tile);

            //如果是单个物块，直接返回当前坐标
            if (data == null) {
                return new Point16(i, j);
            }

            //计算物块的帧位置偏移量
            int frameX = tile.TileFrameX % (data.Width * 18);
            int frameY = tile.TileFrameY % (data.Height * 18);

            //计算左上角的位置
            int topLeftX = i - (frameX / 18);
            int topLeftY = j - (frameY / 18);

            //返回左上角位置
            return new Point16(topLeftX, topLeftY);
        }

        /// <summary>
        /// 获取给定坐标的物块左上角位置，并判断该位置是否为多结构物块的左上角
        /// </summary>
        /// <param name="point">物块的坐标</param>
        /// <returns>
        /// 如果物块存在并且位于一个多结构物块的左上角，返回其左上角坐标，否则返回null
        /// </returns>
        public static Point16? GetTopLeftOrNull(Point16 point) => GetTopLeftOrNull(point.X, point.Y);

        /// <summary>
        /// 判断给定坐标是否为多结构物块的左上角位置，并输出左上角的坐标
        /// </summary>
        /// <param name="i">物块的x坐标</param>
        /// <param name="j">物块的y坐标</param>
        /// <param name="point">输出的左上角坐标，如果不是左上角则为(0,0)</param>
        /// <returns>如果是左上角，返回true，否则返回false </returns>
        public static bool IsTopLeft(int i, int j, out Point16 point) {
            //使用合并后的函数获取左上角位置
            Point16? topLeft = GetTopLeftOrNull(i, j);

            //如果没有有效的左上角坐标，返回false，并将输出参数设为(0, 0)
            if (!topLeft.HasValue) {
                point = new Point16(0, 0);
                return false;
            }

            //获取左上角的实际坐标
            point = topLeft.Value;

            //如果左上角位置与当前坐标相同，说明是左上角
            return point.X == i && point.Y == j;
        }

        /// <summary>
        /// 判断给定坐标是否为多结构物块的左上角位置，并输出左上角的坐标
        /// </summary>
        /// <param name="origPoint">物块的坐标</param>
        /// <param name="point">输出的左上角坐标，如果不是左上角则为(0,0)</param>
        /// <returns>如果是左上角，返回true，否则返回false </returns>
        public static bool IsTopLeft(Point16 origPoint, out Point16 point) => IsTopLeft(origPoint.X, origPoint.Y, out point);

        /// <summary>
        /// 安全的获取多结构物块左上角的位置，给定一个物块坐标，自动寻找到该坐标对应的左上原点位置输出
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="point"></param>
        /// <returns>如果没能找到，则输出(0,0)，并返回<see langword="false"/></returns>
        public static bool SafeGetTopLeft(int i, int j, out Point16 point) {
            Point16? topLeft = GetTopLeftOrNull(i, j);
            if (topLeft.HasValue) {
                point = topLeft.Value;
                return true;
            }
            else {
                point = new Point16(0, 0);
                return false;
            }
        }

        /// <summary>
        /// 安全的获取多结构物块左上角的位置，给定一个物块坐标，自动寻找到该坐标对应的左上原点位置输出
        /// </summary>
        /// <param name="origPoint"></param>
        /// <param name="point"></param>
        /// <returns>如果没能找到，则输出(0,0)，并返回<see langword="false"/></returns>
        public static bool SafeGetTopLeft(Point16 origPoint, out Point16 point) => SafeGetTopLeft(origPoint.X, origPoint.Y, out point);

        /// <summary>
        /// 获取一个物块的掉落物ID
        /// </summary>
        /// <param name="tile"></param>
        /// <returns></returns>
        [Obsolete("此方法已经弃用")]
        public static int GetTileDorp(this Tile tile) {
            int stye = TileObjectData.GetTileStyle(tile);
            if (stye == -1) {
                stye = 0;
            }

            return TileLoader.GetItemDropFromTypeAndStyle(tile.TileType, stye);
        }

        /// <summary>
        /// 获取一个物块的掉落物ID
        /// </summary>
        /// <param name="tile"></param>
        /// <returns></returns>
        public static int GetTileDrop(this Tile tile) {
            int style = TileObjectData.GetTileStyle(tile);
            if (style <= 0) {
                style = 0;
            }
            return TileLoader.GetItemDropFromTypeAndStyle(tile.TileType, style);
        }

        /// <summary>
        /// 获取<see cref="WorldGen"/>中的私有方法 KillTile_GetItemDrops 的信息
        /// </summary>
        public readonly static MethodInfo KillTile_GetItemDrops_Method
            = typeof(WorldGen).GetMethod("KillTile_GetItemDrops", BindingFlags.Static | BindingFlags.NonPublic);

        /// <summary>
        /// 获取一个物块的掉落物ID
        /// </summary>
        /// <param name="tile"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public static int GetTileDrop(this Tile tile, int x, int y) {
            int id = GetTileDrop(tile);
            if (id > 0) {
                return id;
            }

            //如果失败则用反射调用原版方法
            object[] parameters = [
                x,
                y,
                tile, //Tile tileCache
                0,    //out int dropItem
                0,    //out int dropItemStack
                0,    //out int secondaryItem
                0,    //out int secondaryItemStack
                false //includeLargeObjectDrops
            ];

            KillTile_GetItemDrops_Method.Invoke(null, parameters);

            id = (int)parameters[3];//dropItem
            return id;
        }

        /// <summary>
        /// 检查给定的 <see cref="Vector2"/> 坐标点是否位于世界范围内
        /// </summary>
        /// <param name="vector">要检查的世界坐标，以像素为单位</param>
        /// <returns>如果坐标转换为 <see cref="Point16"/> 后仍然位于世界范围内，则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        /// <remarks>
        /// 由于世界的物块坐标是 16×16 像素的网格，因此本方法会将 <paramref name="vector"/> 的 X 和 Y 坐标
        /// 除以 16 并取整，以转换为 tile 坐标，然后调用 <see cref="InWorld(Point16)"/> 进行判断
        /// </remarks>
        public static bool InWorld(Vector2 vector) => InWorld(new Point16((int)(vector.X / 16), (int)(vector.Y / 16)));

        /// <summary>
        /// 检查给定的 <see cref="Point16"/> 坐标点是否位于世界范围内
        /// </summary>
        /// <param name="point">要检查的 tile 坐标，以 <see cref="Point16"/> 形式表示</param>
        /// <returns>如果点位于世界范围内，则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        /// <remarks>
        /// 本方法是对 <see cref="WorldGen.InWorld"/> 方法的封装，以支持 <see cref="Point16"/> 类型的参数
        /// 适用于 tile 级别的世界范围判断，而非像素级别的坐标检查
        /// </remarks>
        public static bool InWorld(Point16 point) => WorldGen.InWorld(point.X, point.Y);

        /// <summary>
        /// 检查多个 <see cref="Point16"/> 坐标点是否全部位于世界范围内
        /// </summary>
        /// <param name="points">要检查的多个 tile 坐标点</param>
        /// <returns>如果所有点都位于世界范围内，则返回<see langword="true"/>，否则返回<see langword="false"/></returns>
        public static bool InWorld(params Point16[] points) {
            foreach (var point in points) {
                if (!WorldGen.InWorld(point.X, point.Y)) {
                    return false; //只要有一个点不在世界范围内，就返回 false
                }
            }
            return true; //所有点都在世界范围内
        }

        /// <summary>
        /// 检测该位置是否存在一个实心的固体方块
        /// </summary>
        public static bool HasSolidTile(this Tile tile) => tile.HasTile && Main.tileSolid[tile.TileType] && !Main.tileSolidTop[tile.TileType];
        #endregion

        #region Draw
        /// <summary>
        /// 按完整资源路径请求贴图，路径为空或资源不存在时回落到 <see cref="VaultAsset.placeholder3"/>，
        /// 不抛异常也不写日志，可以放心在绘制里每帧调用
        /// </summary>
        /// <param name="fullPath">带模组名前缀的资源路径，如 <c>"InnoVault/Assets/Foo"</c></param>
        /// <param name="immediateLoad">为 <see langword="true"/> 时同步加载，否则异步加载</param>
        public static Asset<Texture2D> RequestTexture(string fullPath, bool immediateLoad = false) {
            if (string.IsNullOrEmpty(fullPath) || !ModContent.HasAsset(fullPath)) {
                return VaultAsset.placeholder3;
            }
            return ModContent.Request<Texture2D>(fullPath, immediateLoad ? AssetRequestMode.ImmediateLoad : AssetRequestMode.AsyncLoad);
        }

        /// <summary>
        /// 释放显存资源并保证在主线程执行<br/>
        /// FNA3D 只接受主线程销毁 GPU 对象，而 <see cref="ModSystem.ClearWorld"/>、<see cref="ModSystem.OnWorldUnload"/>
        /// 与模组卸载都可能跑在别的线程上，在那些路径里直接 <c>Dispose</c> 会抛 <see cref="ThreadStateException"/> 打断流程<br/>
        /// 当前不在主线程时，释放推迟到下一帧的主线程队列；资源为空或已释放则什么也不做
        /// </summary>
        public static void SafeDispose(this GraphicsResource resource) {
            if (resource == null || resource.IsDisposed) {
                return;
            }
            if (Program.IsMainThread) {
                resource.Dispose();
                return;
            }
            Main.QueueMainThreadAction(resource.Dispose);
        }

        /// <summary>
        /// 获取一个值，该值指示UI空间的染色效果当前是否已激活
        /// </summary>
        public static bool UIEffectActive { get; private set; } = false;
        /// <summary>
        /// 获取一个值，该值指示世界空间的染色效果当前是否已激活
        /// </summary>
        public static bool WorldEffectActive { get; private set; } = false;

        /// <summary>
        /// 为UI绘制开启一个着色器染色效果
        /// 此方法会中断当前的SpriteBatch，应用着色器后以新的配置重启
        /// </summary>
        /// <param name="entity">应用着色器的实体，着色器可能会使用此实体的位置、速度等信息进行计算</param>
        /// <param name="dyeItemID">染料物品的ID，用于获取对应的着色器实例</param>
        /// <param name="customBegin">一个可选的委托，用于在需要时执行自定义的SpriteBatch.Begin调用</param>
        /// <remarks>
        /// 每次调用此方法后，都必须在绘制完需要染色的内容后立即调用 <see cref="EndDyeEffectForUI(Action{SpriteBatch})"/> 来恢复画布的默认状态，否则会扰乱后续的UI绘制
        /// </remarks>
        public static void BeginDyeEffectForUI(this Entity entity, int dyeItemID, Action<SpriteBatch> customBegin = null) {
            if (dyeItemID <= 0) {
                return;
            }
            if (UIEffectActive) {
                EndDyeEffectForUI();
            }
            BeginSpriteBatch(customBegin, Main.UIScaleMatrix);
            GameShaders.Armor.GetShaderFromItemId(dyeItemID)?.Apply(entity, null);
            UIEffectActive = true;
        }

        /// <summary>
        /// 结束当前的UI染色效果，并恢复SpriteBatch的默认绘制状态
        /// </summary>
        /// <param name="customBegin">一个可选的委托，用于在需要时执行自定义的SpriteBatch.Begin调用来恢复状态</param>
        public static void EndDyeEffectForUI(Action<SpriteBatch> customBegin = null) {
            if (!UIEffectActive) {
                return;
            }
            BeginSpriteBatch(customBegin, Main.UIScaleMatrix);
            UIEffectActive = false;
        }
        /// <summary>
        /// 结束当前的UI染色效果，并恢复SpriteBatch的默认绘制状态
        /// </summary>
        /// <param name="_"></param>
        /// <param name="customBegin">一个可选的委托，用于在需要时执行自定义的SpriteBatch.Begin调用来恢复状态</param>
        public static void EndDyeEffectForUI(this Entity _, Action<SpriteBatch> customBegin = null) => EndDyeEffectForUI(customBegin);

        /// <summary>
        /// 为世界内绘制开启一个着色器染色效果
        /// 此方法会中断当前的SpriteBatch，应用着色器后以应用于世界坐标的变换矩阵重启
        /// </summary>
        /// <param name="entity">应用着色器的实体，着色器可能会使用此实体的位置、速度等信息进行计算</param>
        /// <param name="dyeItemID">染料物品的ID，用于获取对应的着色器实例</param>
        /// <param name="customBegin">一个可选的委托，用于在需要时执行自定义的SpriteBatch.Begin调用</param>
        /// <remarks>
        /// 每次调用此方法后，都必须在绘制完需要染色的内容后立即调用 <see cref="EndDyeEffectForWorld(Action{SpriteBatch})"/> 来恢复画布的默认状态，否则会扰乱后续的世界内绘制
        /// </remarks>
        public static void BeginDyeEffectForWorld(this Entity entity, int dyeItemID, Action<SpriteBatch> customBegin = null) {
            if (dyeItemID <= 0) {
                return;
            }
            if (WorldEffectActive) {
                EndDyeEffectForWorld();
            }
            BeginSpriteBatch(customBegin, Main.GameViewMatrix.ZoomMatrix);
            GameShaders.Armor.GetShaderFromItemId(dyeItemID)?.Apply(entity, null);
            WorldEffectActive = true;
        }

        /// <summary>
        /// 结束当前的世界染色效果，并恢复SpriteBatch的默认绘制状态
        /// </summary>
        /// <param name="customBegin">一个可选的委托，用于在需要时执行自定义的SpriteBatch.Begin调用来恢复状态</param>
        public static void EndDyeEffectForWorld(Action<SpriteBatch> customBegin = null) {
            if (!WorldEffectActive) {
                return;
            }
            BeginSpriteBatch(customBegin, Main.GameViewMatrix.ZoomMatrix);
            WorldEffectActive = false;
        }
        /// <summary>
        /// 结束当前的世界染色效果，并恢复SpriteBatch的默认绘制状态
        /// </summary>
        /// <param name="_"></param>
        /// <param name="customBegin">一个可选的委托，用于在需要时执行自定义的SpriteBatch.Begin调用来恢复状态</param>
        public static void EndDyeEffectForWorld(this Entity _, Action<SpriteBatch> customBegin = null) => EndDyeEffectForWorld(customBegin);

        /// <summary>
        /// 私有辅助方法，用于结束当前的SpriteBatch并以指定的配置重新开始
        /// 这是实现着色器效果的核心，因为应用着色器需要SpriteBatch在 <see cref="SpriteSortMode.Immediate"/> 模式下启动
        /// </summary>
        /// <param name="customBegin">一个可选的委托，如果提供，则使用它来代替默认的Begin调用</param>
        /// <param name="transformMatrix">应用于SpriteBatch的变换矩阵，用于区分UI绘制和世界绘制</param>
        private static void BeginSpriteBatch(Action<SpriteBatch> customBegin, Matrix transformMatrix) {
            Main.spriteBatch.End();
            if (customBegin != null) {
                customBegin.Invoke(Main.spriteBatch);
            }
            else {
                Main.spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend,
                    Main.DefaultSamplerState, DepthStencilState.None,
                    RasterizerState.CullCounterClockwise, null, transformMatrix);
            }
        }

        /// <summary>
        /// 计算并返回屏幕变换矩阵（World-View-Projection 矩阵）
        /// </summary>
        /// <param name="offset">
        /// 世界坐标的平移偏移量（默认值为 -Main.screenPosition）
        /// 这用于调整世界空间的原点，使其相对于屏幕中心进行渲染
        /// </param>
        /// <param name="matrix">
        /// 视图矩阵（View Matrix），默认为 Main.GameViewMatrix.TransformationMatrix
        /// 该矩阵用于从世界空间转换到摄像机视角，控制视角的缩放、旋转和偏移
        /// </param>
        /// <param name="screenWidth">
        /// 屏幕宽度（默认值为 Main.screenWidth）
        /// 该参数用于定义投影矩阵的宽度，通常与游戏窗口的宽度保持一致
        /// </param>
        /// <param name="screenHeight">
        /// 屏幕高度（默认值为 Main.screenHeight）
        /// 该参数用于定义投影矩阵的高度，通常与游戏窗口的高度保持一致
        /// </param>
        /// <returns>
        /// 返回一个组合后的变换矩阵（World * View * Projection）
        /// 该矩阵用于将世界空间坐标转换为屏幕坐标，适用于 2D 渲染（如 UI 元素、精灵绘制）
        /// </returns>
        public static Matrix GetTransfromMatrix(Vector3? offset = null, Matrix? matrix = null, int? screenWidth = null, int? screenHeight = null) {
            Matrix world = Matrix.CreateTranslation(offset ?? -Main.screenPosition.ToVector3());
            Matrix view = matrix ?? Main.GameViewMatrix.TransformationMatrix;
            Matrix projection = Matrix.CreateOrthographicOffCenter(0, screenWidth ?? Main.screenWidth, screenHeight ?? Main.screenHeight, 0, -1, 1);
            return world * view * projection;
        }

        /// <summary>
        /// 世界坐标转屏幕像素坐标，经过 <see cref="Main.GameViewMatrix"/> 的完整变换（缩放、反重力翻转、半像素修正），
        /// 与拷屏得到的 <see cref="Main.screenTarget"/> 画面逐像素对齐
        /// 只减 <see cref="Main.screenPosition"/> 的写法在游戏缩放不为 1 时会偏，全屏后处理定位请用本方法
        /// </summary>
        /// <param name="worldPosition">世界坐标</param>
        /// <returns>屏幕像素坐标，左上角为原点</returns>
        public static Vector2 WorldToScreen(Vector2 worldPosition)
            => Vector2.Transform(worldPosition - Main.screenPosition, Main.GameViewMatrix.TransformationMatrix);

        /// <summary>
        /// 世界坐标转归一化屏幕 UV（0~1，左上角为原点），供全屏着色器的中心点、光源位置等参数使用
        /// 缩放与翻转处理同 <see cref="WorldToScreen"/>
        /// </summary>
        /// <param name="worldPosition">世界坐标</param>
        /// <returns>归一化屏幕坐标，屏幕外的点会落在 0~1 之外</returns>
        public static Vector2 WorldToScreenUV(Vector2 worldPosition) {
            Vector2 screen = WorldToScreen(worldPosition);
            return new Vector2(screen.X / Main.screenWidth, screen.Y / Main.screenHeight);
        }

        /// <summary>
        /// 屏幕像素坐标转世界坐标，<see cref="WorldToScreen"/> 的逆运算，
        /// 用于把拷屏画面上的一点（或鼠标屏幕位置）还原到世界
        /// </summary>
        /// <param name="screenPosition">屏幕像素坐标，左上角为原点</param>
        /// <returns>世界坐标</returns>
        public static Vector2 ScreenToWorld(Vector2 screenPosition)
            => Vector2.Transform(screenPosition, Matrix.Invert(Main.GameViewMatrix.TransformationMatrix)) + Main.screenPosition;
        /// <summary>
        /// 绘制具有旋转边框效果的纹理
        /// 该方法通过两层旋转光圈模拟出一种动态发光的边缘效果
        /// </summary>
        /// <param name="spriteBatch">用于绘制的 SpriteBatch 对象</param>
        /// <param name="texture">要绘制的纹理</param>
        /// <param name="drawTimer">用于控制旋转动画的计时器（通常递增）</param>
        /// <param name="position">纹理绘制的位置</param>
        /// <param name="sourceRectangle">纹理裁剪区域（可选）</param>
        /// <param name="color">绘制颜色</param>
        /// <param name="rotation">纹理的旋转角度（弧度制）</param>
        /// <param name="origin">纹理的原点</param>
        /// <param name="scale">纹理的缩放比例</param>
        /// <param name="effects">纹理的 SpriteEffects <see cref="SpriteEffects.None"/></param>
        public static void DrawRotatingMarginEffect(SpriteBatch spriteBatch, Texture2D texture, int drawTimer, Vector2 position,
            Rectangle? sourceRectangle, Color color, float rotation, Vector2 origin, float scale, SpriteEffects effects = SpriteEffects.None) {
            //计算全局时间因子（用于同步动画效果）
            float globalTime = Main.GlobalTimeWrappedHourly;
            //计算旋转计时器，用于控制旋转速度
            float timer = drawTimer / 240f + globalTime * 0.04f;

            //控制时间的周期性变化，使光圈明暗有呼吸感
            float timeFactor = globalTime % 4f;
            timeFactor /= 2f;
            if (timeFactor >= 1f)
                timeFactor = 2f - timeFactor;
            timeFactor = timeFactor * 0.5f + 0.5f;

            //外层旋转光圈效果（间隔0.25，较大的偏移）
            for (float offset = 0f; offset < 1f; offset += 0.25f) {
                float radians = (offset + timer) * MathHelper.TwoPi;
                Vector2 offsetPosition = position + new Vector2(0f, 8f).RotatedBy(radians) * timeFactor;
                Color transparentColor = new Color(color.R, color.G, color.B, 50); //较透明的颜色
                spriteBatch.Draw(texture, offsetPosition, sourceRectangle, transparentColor, rotation, origin, scale, effects, 0f);
            }

            //内层旋转光圈效果（间隔0.34，较小的偏移）
            for (float offset = 0f; offset < 1f; offset += 0.34f) {
                float radians = (offset + timer) * MathHelper.TwoPi;
                Vector2 offsetPosition = position + new Vector2(0f, 4f).RotatedBy(radians) * timeFactor;
                Color semiTransparentColor = new Color(color.R, color.G, color.B, 77); //半透明的颜色
                spriteBatch.Draw(texture, offsetPosition, sourceRectangle, semiTransparentColor, rotation, origin, scale, effects, 0f);
            }
        }

        private static FieldInfo SpriteBatch_BeginCalled_Field = typeof(SpriteBatch).GetField("beginCalled", BindingFlags.NonPublic | BindingFlags.Instance);
        /// <summary>
        /// 获取画布的 beginCalled 字段值：优先走 <see cref="SpriteBatchStateExtensions.IsBegun"/> 的零开销访问器，不可用时退回反射
        /// </summary>
        /// <param name="spriteBatch"></param>
        /// <returns></returns>
        public static bool GetBeginCalledBool(this SpriteBatch spriteBatch) {
            if (SpriteBatchState.Available) {
                return spriteBatch.IsBegun();
            }
            return SpriteBatch_BeginCalled_Field != null && (bool)SpriteBatch_BeginCalled_Field.GetValue(spriteBatch);
        }

        /// <summary>
        /// 获取完整纹理的矩形区域
        /// </summary>
        /// <param name="value">纹理对象</param>
        /// <returns>完整纹理的 Rectangle 区域</returns>
        public static Rectangle GetRectangle(this Texture2D value)
            => new Rectangle(0, 0, value.Width, value.Height);

        /// <summary>
        /// 获取分帧后的某一帧对应的矩形区域
        /// </summary>
        /// <param name="value">纹理对象</param>
        /// <param name="frame">当前帧索引</param>
        /// <param name="maxFrame">总帧数</param>
        /// <returns>对应帧的 Rectangle 区域</returns>
        public static Rectangle GetRectangle(this Texture2D value, int frame, int maxFrame = 1) {
            int singleFrameY = value.Height / maxFrame;
            return new Rectangle(0, singleFrameY * frame, value.Width, singleFrameY);
        }

        /// <summary>
        /// 获取纹理的中心点作为绘制原点
        /// </summary>
        /// <param name="value">纹理对象</param>
        /// <returns>原点坐标</returns>
        public static Vector2 GetOrig(this Texture2D value) => value.Size() / 2;

        /// <summary>
        /// 获取分帧纹理中某一帧的中心点作为绘制原点
        /// </summary>
        /// <param name="value">纹理对象</param>
        /// <param name="maxFrame">帧总数</param>
        /// <returns>某帧的原点坐标</returns>
        public static Vector2 GetOrig(this Texture2D value, int maxFrame) =>
            new Vector2(value.Width / 2, value.Height / maxFrame / 2);

        /// <summary>
        /// 控制帧动画的播放，基于游戏更新频率定时播放
        /// </summary>
        /// <param name="frame">当前帧引用</param>
        /// <param name="intervalFrame">每几帧切换一次动画</param>
        /// <param name="maxFrame">帧上限（包含）</param>
        /// <param name="minFrame">帧起始（默认 0）</param>
        public static void ClockFrame(ref int frame, int intervalFrame, int maxFrame, int minFrame = 0) {
            if (frame < minFrame) {
                frame = minFrame;
            }

            if (Main.GameUpdateCount % intervalFrame == 0) {
                frame++;
            }

            if (frame > maxFrame) {
                frame = minFrame;
            }
        }

        /// <summary>
        /// 控制帧动画的播放，基于游戏更新频率定时播放
        /// </summary>
        /// <param name="frame">当前帧引用</param>
        /// <param name="intervalFrame">每几帧切换一次动画</param>
        /// <param name="maxFrame">帧上限</param>
        /// <param name="minFrame">帧起始，默认0</param>
        public static void ClockFrame(ref double frame, int intervalFrame, int maxFrame, int minFrame = 0) {
            if (frame < minFrame) {
                frame = minFrame;
            }

            if (Main.GameUpdateCount % intervalFrame == 0) {
                frame++;
            }

            if (frame > maxFrame) {
                frame = minFrame;
            }
        }

        /// <summary>
        /// 控制帧动画的播放，基于游戏更新频率定时播放
        /// </summary>
        /// <param name="frame">当前帧引用</param>
        /// <param name="intervalFrame">每几帧切换一次动画</param>
        /// <param name="maxFrame">帧上限</param>
        /// <param name="minFrame">帧起始，默认0</param>
        public static void ClockFrame(ref float frame, int intervalFrame, int maxFrame, int minFrame = 0) {
            if (frame < minFrame) {
                frame = minFrame;
            }

            if (Main.GameUpdateCount % intervalFrame == 0) {
                frame++;
            }

            if (frame > maxFrame) {
                frame = minFrame;
            }
        }
        #endregion

        #region UI
        /// <summary>
        /// 绘制一个带有边框的矩形，支持缩放及缩放中心自定义
        /// </summary>
        /// <param name="spriteBatch">用于绘制的SpriteBatch对象</param>
        /// <param name="borderTexture">边框纹理，用于绘制矩形边框</param>
        /// <param name="borderWidth">边框的宽度（像素）</param>
        /// <param name="rectangle">描述这个方框的矩形构造体</param>
        /// <param name="borderColor">边框的颜色</param>
        /// <param name="borderCenterColor">矩形内部区域的颜色</param>
        /// <param name="scale">整体缩放比例（默认为1，即不缩放）</param>
        /// <param name="scaleCenter">缩放中心，决定缩放时的参照点（默认为矩形中心）</param>
        public static void DrawBorderedRectangle(SpriteBatch spriteBatch, Texture2D borderTexture, int borderWidth
            , Rectangle rectangle, Color borderColor, Color borderCenterColor, float scale = 1, Vector2 scaleCenter = default)
            => DrawBorderedRectangle(spriteBatch, borderTexture, borderWidth, rectangle.TopLeft(), rectangle.Width, rectangle.Height, borderColor, borderCenterColor, scale, scaleCenter);

        /// <summary>
        /// 绘制一个带有边框的矩形，支持缩放及缩放中心自定义
        /// </summary>
        /// <param name="spriteBatch">用于绘制的SpriteBatch对象</param>
        /// <param name="borderTexture">边框纹理，用于绘制矩形边框</param>
        /// <param name="borderWidth">边框的宽度（像素）</param>
        /// <param name="drawPosition">绘制矩形的起始位置（左上角坐标）</param>
        /// <param name="drawWidth">矩形的宽度（未缩放）</param>
        /// <param name="drawHeight">矩形的高度（未缩放）</param>
        /// <param name="borderColor">边框的颜色</param>
        /// <param name="borderCenterColor">矩形内部区域的颜色</param>
        /// <param name="scale">整体缩放比例（默认为1，即不缩放）</param>
        /// <param name="scaleCenter">缩放中心，决定缩放时的参照点（默认为矩形中心）</param>
        public static void DrawBorderedRectangle(SpriteBatch spriteBatch, Texture2D borderTexture, int borderWidth
            , Vector2 drawPosition, int drawWidth, int drawHeight, Color borderColor, Color borderCenterColor, float scale = 1, Vector2 scaleCenter = default) {
            if (scaleCenter == default) {
                scaleCenter = new Vector2(0.5f, 0.5f);
            }
            //计算缩放后的整体尺寸
            int scaledWidth = (int)(drawWidth * scale);
            int scaledHeight = (int)(drawHeight * scale);
            //计算缩放偏移量，以缩放中心为基准
            float offsetX = (scaledWidth - drawWidth) * scaleCenter.X;
            float offsetY = (scaledHeight - drawHeight) * scaleCenter.Y;
            //调整后的绘制起始位置
            Vector2 adjustedPosition = new Vector2(drawPosition.X - offsetX, drawPosition.Y - offsetY);
            //重新定义外部和内部的矩形区域
            Rectangle outerRect = new Rectangle((int)adjustedPosition.X, (int)adjustedPosition.Y, scaledWidth, scaledHeight);
            Rectangle innerRect = new Rectangle(
                outerRect.X + borderWidth,
                outerRect.Y + borderWidth,
                scaledWidth - 2 * borderWidth,
                scaledHeight - 2 * borderWidth
            );
            spriteBatch.Draw(borderTexture, new Rectangle(outerRect.X, outerRect.Y, scaledWidth, borderWidth), borderColor);
            spriteBatch.Draw(borderTexture, new Rectangle(outerRect.X, outerRect.Bottom - borderWidth, scaledWidth, borderWidth), borderColor);
            spriteBatch.Draw(borderTexture, new Rectangle(outerRect.X, outerRect.Y + borderWidth, borderWidth, scaledHeight - 2 * borderWidth), borderColor);
            spriteBatch.Draw(borderTexture, new Rectangle(outerRect.Right - borderWidth, outerRect.Y + borderWidth, borderWidth, scaledHeight - 2 * borderWidth), borderColor);
            spriteBatch.Draw(borderTexture, innerRect, borderCenterColor);
        }

        /// <summary>
        /// 判断给定的二维点是否在屏幕内（考虑一个小范围的边界扩展）
        /// </summary>
        /// <param name="pos">要判断的点的坐标</param>
        /// <returns>如果点在屏幕范围内（包括扩展边界），返回 true；否则返回 false</returns>
        public static bool IsPointOnScreen(Vector2 pos)
            => pos.X > -16 && pos.X < Main.screenWidth + 16 && pos.Y > -16 && pos.Y < Main.screenHeight + 16;

        /// <summary>
        /// 判断给定的二维点是否在屏幕内（考虑一个小范围的边界扩展）
        /// </summary>
        /// <param name="pos">要判断的点的坐标</param>
        /// <param name="extend">扩张范围</param>
        /// <returns>如果点在屏幕范围内（包括扩展边界），返回 true；否则返回 false</returns>
        public static bool IsPointOnScreen(Vector2 pos, int extend)
            => pos.X > -extend && pos.X < Main.screenWidth + extend && pos.Y > -extend && pos.Y < Main.screenHeight + extend;

        /// <summary>
        /// 判断给定的矩形是否与屏幕范围有交集
        /// </summary>
        /// <param name="rect">要判断的矩形</param>
        /// <returns>如果矩形与屏幕范围有交集，返回 true；否则返回 false</returns>
        public static bool IsRectangleOnScreen(Rectangle rect)
            => rect.Intersects(new Rectangle(0, 0, Main.screenWidth, Main.screenHeight));

        /// <summary>
        /// 判断以指定位置和尺寸定义的矩形是否在屏幕范围内（使用辅助方法实现矩形判断）
        /// </summary>
        /// <param name="pos">矩形的左上角位置</param>
        /// <param name="size">矩形的尺寸</param>
        /// <returns>如果矩形在屏幕范围内，返回 true；否则返回 false</returns>
        public static bool IsAreaOnScreen(Vector2 pos, Vector2 size)
            => IsRectangleOnScreen(new Rectangle((int)pos.X, (int)pos.Y, (int)size.X, (int)size.Y));

        /// <summary>
        /// 生成一个二维网格的坐标数组 用于按行列排列元素
        /// </summary>
        /// <param name="elementCount">元素总数 必须是正整数</param>
        /// <param name="withNum">每行元素数量 必须是正整数</param>
        /// <returns>
        /// 返回一个 <see cref="Point"/> 数组 每个点表示元素在网格中的坐标 (x, y)
        /// x 表示列索引 y 表示行索引
        /// </returns>
        /// <exception cref="ArgumentException"></exception>
        public static Point[] GenerateGridCoordinates(int elementCount, int withNum) {
            if (elementCount <= 0 || withNum <= 0) {
                throw new ArgumentException("elementCount and withNum must be positive integers.");
            }
            Point[] result = new Point[elementCount];
            for (int i = 0; i < elementCount; i++) {
                result[i] = new Point(i % withNum, i / withNum);
            }

            return result;
        }

        /// <summary>
        /// 计算一个基于输入矩形的剪裁区域 用于确保绘制区域在当前屏幕视口内
        /// </summary>
        /// <param name="spriteBatch">当前的 <see cref="SpriteBatch"/> 实例 用于获取视口信息</param>
        /// <param name="r">输入的原始矩形区域</param>
        /// <returns>一个被剪裁后的矩形区域 保证其在视口内</returns>
        /// <remarks>
        /// 输入矩形首先通过 UIScaleMatrix 转换为屏幕坐标
        /// 然后对矩形区域的坐标及大小进行裁剪 使其不会超出屏幕的有效范围
        /// 适用于 UI 绘制时需要限制在屏幕显示区域内的场景
        /// </remarks>
        public static Rectangle GetClippingRectangle(SpriteBatch spriteBatch, Rectangle r) {
            //转换矩形的左上角和右下角到屏幕坐标系
            Vector2 topLeft = Vector2.Transform(new Vector2(r.X, r.Y), Main.UIScaleMatrix);
            Vector2 bottomRight = Vector2.Transform(new Vector2(r.Right, r.Bottom), Main.UIScaleMatrix);

            //计算转换后的矩形
            Rectangle result = new(
                x: (int)topLeft.X,
                y: (int)topLeft.Y,
                width: (int)(bottomRight.X - topLeft.X),
                height: (int)(bottomRight.Y - topLeft.Y)
            );

            //获取当前屏幕视口尺寸
            int viewportWidth = spriteBatch.GraphicsDevice.Viewport.Width;
            int viewportHeight = spriteBatch.GraphicsDevice.Viewport.Height;

            //裁剪矩形到屏幕范围内
            result.X = Utils.Clamp(result.X, 0, viewportWidth);
            result.Y = Utils.Clamp(result.Y, 0, viewportHeight);
            result.Width = Utils.Clamp(result.Width, 0, viewportWidth - result.X);
            result.Height = Utils.Clamp(result.Height, 0, viewportHeight - result.Y);

            return result;
        }

        /// <summary>
        /// 获取物品绘制的大小，确保根据纹理尺寸和给定宽度比例调整物品的大小
        /// </summary>
        /// <param name="item">物品实例</param>
        /// <param name="sizeW">宽度用于计算缩放比例，默认值为 32</param>
        /// <returns>返回缩放比例</returns>
        public static float GetDrawItemSize(this Item item, int sizeW = 32) {
            Rectangle rectangle = Main.itemAnimations[item.type] != null ?
                        Main.itemAnimations[item.type].GetFrame(TextureAssets.Item[item.type].Value)
                        : TextureAssets.Item[item.type].Value.Frame(1, 1, 0, 0);

            float size = 1f;
            if (rectangle.Width > sizeW) {
                size = sizeW / (float)rectangle.Width;
            }
            if (size * rectangle.Height > sizeW) {
                size = sizeW / (float)rectangle.Height;
            }
            return size;
        }

        /// <summary>
        /// 获取物品绘制的大小，确保根据纹理尺寸和给定宽度比例调整物品的大小
        /// </summary>
        /// <param name="type">物品类型 ID</param>
        /// <param name="sizeW">宽度用于计算缩放比例，默认值为 32</param>
        /// <returns>返回缩放比例</returns>
        public static float GetDrawItemSize(int type, int sizeW = 32) {
            Rectangle rectangle = Main.itemAnimations[type] != null ?
                        Main.itemAnimations[type].GetFrame(TextureAssets.Item[type].Value)
                        : TextureAssets.Item[type].Value.Frame(1, 1, 0, 0);

            float size = 1f;
            if (rectangle.Width > sizeW) {
                size = sizeW / (float)rectangle.Width;
            }
            if (size * rectangle.Height > sizeW) {
                size = sizeW / (float)rectangle.Height;
            }
            return size;
        }

        /// <summary>
        /// 绘制一个简单的物品图像
        /// </summary>
        /// <param name="spriteBatch">用于绘制的 <see cref="SpriteBatch"/> 实例</param>
        /// <param name="itemType">物品类型 ID</param>
        /// <param name="position">物品绘制的屏幕坐标</param>
        /// <param name="size">绘制缩放比例</param>
        /// <param name="rotation">物品旋转角度（弧度）</param>
        /// <param name="color">绘制颜色</param>
        /// <param name="orig">纹理原点（默认为纹理的中心点）</param>
        public static void SimpleDrawItem(SpriteBatch spriteBatch, int itemType, Vector2 position, float size, float rotation, Color color, Vector2 orig = default(Vector2)) {
            //获取物品的纹理资源
            Texture2D texture = TextureAssets.Item[itemType].Value;

            //获取物品的动画帧区域（如无动画则使用完整纹理）
            Rectangle? frame = Main.itemAnimations[itemType]?.GetFrame(texture) ?? texture.Frame(1, 1, 0, 0);

            //如果未指定原点，则使用纹理帧的中心点作为默认原点
            if (orig == Vector2.Zero) orig = frame.HasValue ? frame.Value.Size() / 2 : texture.Size() / 2;

            //绘制物品
            spriteBatch.Draw(texture, position, frame, color, rotation, orig, size, SpriteEffects.None, 0f);
        }

        /// <summary>
        /// 绘制一个简单的物品图像
        /// </summary>
        /// <param name="spriteBatch">用于绘制的 <see cref="SpriteBatch"/> 实例</param>
        /// <param name="itemType">物品类型 ID</param>
        /// <param name="position">物品绘制的屏幕坐标</param>
        /// <param name="size">绘制缩放比例，若为 0 则自动根据物品尺寸计算</param>
        /// <param name="rotation">物品旋转角度（弧度）</param>
        /// <param name="color">绘制颜色</param>
        /// <param name="orig">纹理原点（默认为纹理的中心点）</param>
        /// <param name="itemWidth">物品绘制框宽度，默认值为 32</param>
        public static void SimpleDrawItem(SpriteBatch spriteBatch, int itemType, Vector2 position, int itemWidth = 32, float size = 0, float rotation = 0, Color color = default, Vector2 orig = default) {
            Texture2D texture = TextureAssets.Item[itemType].Value;
            Rectangle? frame = Main.itemAnimations[itemType]?.GetFrame(texture) ?? texture.Frame(1, 1, 0, 0);
            if (orig == Vector2.Zero) {
                orig = frame.HasValue ? frame.Value.Size() / 2 : texture.Size() / 2;
            }
            //如果未指定大小，则根据物品尺寸和提供的宽度计算缩放比例
            if (size <= 0) {
                size = GetDrawItemSize(itemType, itemWidth);
            }
            else {
                size = GetDrawItemSize(itemType, itemWidth) * size;
            }
            //设置颜色
            if (color == default) {
                color = Color.White;
            }
            //绘制物品
            spriteBatch.Draw(texture, position, frame, color, rotation, orig, size, SpriteEffects.None, 0f);
        }

        /// <summary>
        /// 绘制事件进度条
        /// </summary>
        /// <param name="spriteBatch">绘制使用的 <see cref="SpriteBatch"/> 实例</param>
        /// <param name="pixel">进度条材质</param>
        /// <param name="drawPos">进度条中心位置</param>
        /// <param name="iconAsset">事件图标的纹理资源</param>
        /// <param name="eventKillRatio">事件完成度（0~1）</param>
        /// <param name="size">整体缩放比例</param>
        /// <param name="barWidth">进度条宽度</param>
        /// <param name="barHeight">进度条高度</param>
        /// <param name="eventMainName">事件名称</param>
        /// <param name="eventMainColor">事件背景颜色</param>
        public static void DrawEventProgressBar(SpriteBatch spriteBatch, Texture2D pixel, Vector2 drawPos, Asset<Texture2D> iconAsset
            , float eventKillRatio, float size, int barWidth, int barHeight, string eventMainName, Color eventMainColor) {
            //参数校验
            if (size < 0.1f || eventKillRatio < 0 || eventKillRatio > 1) {
                return;
            }

            //事件标题绘制
            Vector2 eventNameSize = FontAssets.MouseText.Value.MeasureString(eventMainName);
            float titleBackgroundWidth = 120f + Math.Max(0, eventNameSize.X - 200f);
            Vector2 titlePosition = new(Main.screenWidth - titleBackgroundWidth, Main.screenHeight - 80);

            Rectangle titleBackgroundRect = Utils.CenteredRectangle(titlePosition, eventNameSize + new Vector2(iconAsset.Value.Width + 12, 6f));
            Utils.DrawInvBG(spriteBatch, titleBackgroundRect, eventMainColor * 0.5f * size);

            //绘制事件图标
            spriteBatch.Draw(iconAsset.Value, titleBackgroundRect.Left() + Vector2.UnitX * 8f, null, Color.White * size
                , 0f, Vector2.UnitY * iconAsset.Value.Height / 2, 0.8f * size, SpriteEffects.None, 0f);

            //绘制事件名称
            Utils.DrawBorderString(spriteBatch, eventMainName, titleBackgroundRect.Right() - Vector2.UnitX * 16f, Color.White * size, 0.9f * size, 1f, 0.4f, -1);

            //绘制进度条背景
            drawPos += new Vector2(-100, 20);
            Rectangle progressBarRect = new((int)drawPos.X - barWidth / 2, (int)drawPos.Y - barHeight / 2, barWidth, barHeight);
            Utils.DrawInvBG(spriteBatch, progressBarRect, new Color(6, 80, 84, 255) * 0.785f * size);

            //绘制进度条主体
            DrawProgressBar(spriteBatch, pixel, drawPos, eventKillRatio, size, barWidth);

            //绘制完成百分比文本
            string progressText = Language.GetTextValue("Game.WaveCleared", $"{eventKillRatio * 100:N1}%");
            Vector2 progressTextSize = FontAssets.MouseText.Value.MeasureString(progressText);
            float textScale = progressTextSize.Y > 22f ? 22f / progressTextSize.Y : 1f;
            Utils.DrawBorderString(spriteBatch, progressText, drawPos + Vector2.UnitY * 6f, Color.White * size, textScale, 0.5f, 1f, -1);
        }

        /// <summary>
        /// 绘制进度条主体部分
        /// </summary>
        /// <param name="spriteBatch">绘制使用的 <see cref="SpriteBatch"/> 实例</param>
        /// <param name="pixel">进度条材质</param>
        /// <param name="drawPos">进度条中心位置</param>
        /// <param name="progress">完成度（0~1）</param>
        /// <param name="size">缩放比例</param>
        /// <param name="barWidth">进度条宽度</param>
        private static void DrawProgressBar(SpriteBatch spriteBatch, Texture2D pixel, Vector2 drawPos, float progress, float size, float barWidth) {
            //已完成部分
            Vector2 completedBarPos = drawPos + Vector2.UnitX * (progress - 0.5f) * barWidth;
            spriteBatch.Draw(pixel, completedBarPos, new Rectangle(0, 0, 1, 1), new Color(255, 241, 51) * size
                , 0f, new Vector2(1f, 0.5f), new Vector2(barWidth * progress, 8) * size, SpriteEffects.None, 0f);
            //边缘光效
            spriteBatch.Draw(pixel, completedBarPos, new Rectangle(0, 0, 1, 1), new Color(255, 165, 0, 127) * size
                , 0f, new Vector2(1f, 0.5f), new Vector2(2f, 8) * size, SpriteEffects.None, 0f);
            //未完成部分
            Vector2 remainingBarPos = drawPos + Vector2.UnitX * (progress - 0.5f) * barWidth;
            spriteBatch.Draw(pixel, remainingBarPos, new Rectangle(0, 0, 1, 1), Color.Black * size
                , 0f, Vector2.UnitY * 0.5f, new Vector2(barWidth * (1f - progress), 8) * size, SpriteEffects.None, 0f);
        }

        /// <summary>
        /// 菜单状态枚举
        /// </summary>
        public enum MenuState
        {
            /// <summary>
            /// 主菜单
            /// </summary>
            MainMenu,
            /// <summary>
            /// 角色选择
            /// </summary>
            CharacterSelect,
            /// <summary>
            /// 世界选择
            /// </summary>
            WorldSelect,
            /// <summary>
            /// 模组管理
            /// </summary>
            ModManagement,
            /// <summary>
            /// 模组浏览器
            /// </summary>
            ModBrowser,
            /// <summary>
            /// 设置
            /// </summary>
            Settings,
            /// <summary>
            /// 多人游戏
            /// </summary>
            Multiplayer,
            /// <summary>
            /// 游戏中（不在菜单）
            /// </summary>
            InGame,
            /// <summary>
            /// 其他界面
            /// </summary>
            Other
        }

        /// <summary>
        /// 获取当前菜单状态
        /// </summary>
        public static MenuState GetCurrentMenuState() {
            //如果不在游戏菜单中，返回游戏中
            if (!Main.gameMenu)
                return MenuState.InGame;

            //检查标准 menuMode
            switch (Main.menuMode) {
                case 0:
                    return MenuState.MainMenu;

                case 1:
                    return MenuState.CharacterSelect;

                case 6:
                    return MenuState.WorldSelect;

                case 11:
                    return MenuState.Settings;

                case 12:
                    return MenuState.Multiplayer;

                case 888:
                    //menuMode 888 表示使用 MenuUI 系统
                    return GetMenuUIState();

                default:
                    return MenuState.Other;
            }
        }

        /// <summary>
        /// 获取 MenuUI 的具体状态
        /// </summary>
        private static MenuState GetMenuUIState() {
            if (Main.MenuUI == null || !Main.MenuUI.IsVisible)
                return MenuState.Other;

            var currentState = Main.MenuUI.CurrentState;

            if (currentState == null)
                return MenuState.Other;

            //检查是否是角色选择界面
            if (currentState.GetType() == typeof(UICharacterSelect))
                return MenuState.CharacterSelect;

            //检查是否是世界选择界面
            if (currentState.GetType() == typeof(UIWorldSelect))
                return MenuState.WorldSelect;

            //检查是否是模组管理界面
            if (currentState.GetType().Name == "UIMods")
                return MenuState.ModManagement;

            //检查是否是模组浏览器
            if (currentState.GetType().Name == "UIModBrowser")
                return MenuState.ModBrowser;

            return MenuState.Other;
        }

        /// <summary>
        /// 检查是否在主菜单
        /// </summary>
        public static bool IsInMainMenu() {
            return Main.gameMenu && Main.menuMode == 0;
        }

        /// <summary>
        /// 检查是否在角色选择界面
        /// </summary>
        public static bool IsInCharacterSelect() {
            return GetCurrentMenuState() == MenuState.CharacterSelect;
        }

        /// <summary>
        /// 检查是否在世界选择界面
        /// </summary>
        public static bool IsInWorldSelect() {
            return GetCurrentMenuState() == MenuState.WorldSelect;
        }

        /// <summary>
        /// 检查是否在模组管理界面
        /// </summary>
        public static bool IsInModManagement() {
            return GetCurrentMenuState() == MenuState.ModManagement;
        }

        /// <summary>
        /// 检查是否在模组浏览器
        /// </summary>
        public static bool IsInModBrowser() {
            return GetCurrentMenuState() == MenuState.ModBrowser;
        }

        /// <summary>
        /// 检查是否在任何菜单界面（不包括游戏中）
        /// </summary>
        public static bool IsInAnyMenu() {
            return Main.gameMenu;
        }

        /// <summary>
        /// 检查是否应该显示自定义主页UI
        /// 例如：只在主菜单显示，在其他界面隐藏
        /// </summary>
        public static bool ShouldShowCustomMainMenuUI() {
            //只在主菜单显示
            return IsInMainMenu();
        }

        /// <summary>
        /// 检查是否应该隐藏自定义主页UI
        /// 例如：在角色选择、世界选择、模组管理等界面隐藏
        /// </summary>
        public static bool ShouldHideCustomMainMenuUI() {
            var state = GetCurrentMenuState();
            return state == MenuState.CharacterSelect ||
                   state == MenuState.WorldSelect ||
                   state == MenuState.ModManagement ||
                   state == MenuState.ModBrowser;
        }

        /// <summary>
        /// 在按像素纵向堆叠的界面里腾出一段高度，用于往原版页面（世界创建、角色创建等）中间插入新的一行<br/>
        /// <paramref name="container"/> 的直接子元素中，<see cref="Terraria.UI.UIElement.VAlign"/> 为 0、<c>Top</c> 不含百分比且像素值不小于
        /// <paramref name="y"/> 的整体下移 <paramref name="height"/>；贴底对齐的子元素（VAlign 不为 0）不动，它们随容器加高自然下移<br/>
        /// 随后从 <paramref name="container"/> 起逐级向上，把高度为纯像素的元素加高 <paramref name="height"/>（含百分比的会随父级自动变高），
        /// 到 <paramref name="stopAt"/>（不含）或根部的 <see cref="Terraria.UI.UIState"/> 为止<br/>
        /// 不会重新排版，已经排过版的界面需要调用方随后调用 <c>Recalculate</c>
        /// </summary>
        /// <param name="container">子元素按 Top 像素纵向排布的容器</param>
        /// <param name="y">插入位置，容器内坐标</param>
        /// <param name="height">腾出的高度，可以为负（收起一段）</param>
        /// <param name="stopAt">向上加高到此为止，不含它本身；为空时到根部 UIState 为止</param>
        /// <returns>被下移的子元素个数</returns>
        public static int InsertVerticalSpace(this Terraria.UI.UIElement container, float y, float height, Terraria.UI.UIElement stopAt = null) {
            if (container == null || height == 0f) {
                return 0;
            }
            int moved = 0;
            foreach (Terraria.UI.UIElement child in container.Children) {
                if (child.VAlign != 0f || child.Top.Percent != 0f || child.Top.Pixels < y) {
                    continue;
                }
                child.Top.Pixels += height;
                moved++;
            }
            for (Terraria.UI.UIElement element = container; element != null && element != stopAt && element is not Terraria.UI.UIState; element = element.Parent) {
                if (element.Height.Percent == 0f) {
                    element.Height.Pixels += height;
                }
            }
            return moved;
        }

        #endregion

        #region Text
        /// <summary>文本测量，字体缺失时保守兜底</summary>
        public static Vector2 MeasureText(string text, DynamicSpriteFont font, float scale = 1f) {
            if (string.IsNullOrEmpty(text)) {
                return Vector2.Zero;
            }
            font ??= Terraria.GameContent.FontAssets.MouseText?.Value;
            if (font == null) {
                return new Vector2(text.Length * 8f * scale, 16f * scale);
            }
            return font.MeasureString(text) * scale;
        }

        /// <summary>默认鼠标字体测量</summary>
        public static Vector2 MeasureText(string text, float scale = 1f)
            => MeasureText(text, Terraria.GameContent.FontAssets.MouseText?.Value, scale);

        /// <summary>CJK 感知自动换行，替代 Utils.WordwrapString</summary>
        public static List<string> WrapText(string text, DynamicSpriteFont font, float maxWidth
            , float scale = 1f, int maxLines = int.MaxValue, bool ellipsis = false) {
            List<string> result = [];
            if (string.IsNullOrEmpty(text)) {
                return result;
            }
            font ??= Terraria.GameContent.FontAssets.MouseText?.Value;
            if (font == null) {
                result.Add(text);
                return result;
            }

            //折行在未缩放空间内计算
            float effWidth = scale > 0f ? maxWidth / scale : maxWidth;

            string normalized = text.Replace("\r", string.Empty);
            foreach (string block in normalized.Split('\n')) {
                if (string.IsNullOrEmpty(block)) {
                    result.Add(string.Empty);
                    continue;
                }
                WrapBlockCJKAware(block, font, effWidth, result);
            }

            if (maxLines < result.Count) {
                if (ellipsis && maxLines > 0) {
                    result[maxLines - 1] = AppendEllipsis(result[maxLines - 1], font, effWidth);
                }
                result.RemoveRange(maxLines, result.Count - maxLines);
            }

            return result;
        }

        /// <summary>默认鼠标字体换行</summary>
        public static List<string> WrapText(string text, float maxWidth
            , float scale = 1f, int maxLines = int.MaxValue, bool ellipsis = false)
            => WrapText(text, Terraria.GameContent.FontAssets.MouseText?.Value, maxWidth, scale, maxLines, ellipsis);

        /// <summary>换行结果转数组</summary>
        public static string[] WrapTextArray(string text, DynamicSpriteFont font, float maxWidth
            , float scale = 1f, int maxLines = int.MaxValue, bool ellipsis = false)
            => [.. WrapText(text, font, maxWidth, scale, maxLines, ellipsis)];

        /// <summary>与 Utils.WordwrapString 同签名，CJK 感知替代</summary>
        public static string[] WrapTextArray(string text, DynamicSpriteFont font, float maxWidth, int maxLines, out int lineCount) {
            string[] arr = [.. WrapText(text, font, maxWidth, 1f, maxLines)];
            lineCount = arr.Length;
            return arr;
        }

        /// <summary>换行后以换行符拼接</summary>
        public static string WrapTextJoin(string text, DynamicSpriteFont font, float maxWidth
            , float scale = 1f, int maxLines = int.MaxValue, bool ellipsis = false)
            => string.Join('\n', WrapText(text, font, maxWidth, scale, maxLines, ellipsis));

        private static string AppendEllipsis(string line, DynamicSpriteFont font, float maxWidth) {
            const string dots = "…";
            if (string.IsNullOrEmpty(line)) {
                return dots;
            }
            string trimmed = line.TrimEnd();
            while (trimmed.Length > 0 && font.MeasureString(trimmed + dots).X > maxWidth) {
                trimmed = trimmed[..^1].TrimEnd();
            }
            return trimmed + dots;
        }

        /// <summary>单段落 CJK 感知折行</summary>
        private static void WrapBlockCJKAware(string text, DynamicSpriteFont font, float maxWidth, List<string> output) {
            if (string.IsNullOrEmpty(text)) {
                output.Add(string.Empty);
                return;
            }
            if (maxWidth < 1f) {
                output.Add(text);
                return;
            }

            //CJK 参考宽度，测量偏小时用字高近似
            float fontHeight = font.MeasureString("A").Y;
            if (fontHeight < 1f) {
                fontHeight = 18f;
            }
            float cjkRefWidth = font.MeasureString("汉").X;
            float expectedCJKWidth = fontHeight * 0.95f;
            if (cjkRefWidth < expectedCJKWidth * 0.6f) {
                cjkRefWidth = expectedCJKWidth;
            }

            StringBuilder currentLine = new();
            float currentWidth = 0f;
            //当前拉丁词在 currentLine 中的起始下标，-1 表示无
            int latinWordStart = -1;
            float latinWordWidth = 0f;

            for (int i = 0; i < text.Length; i++) {
                char ch = text[i];
                bool isCJK = IsCJKChar(ch);
                bool isWhite = char.IsWhiteSpace(ch);

                float charWidth;
                if (isCJK) {
                    float measured = font.MeasureString(ch.ToString()).X;
                    charWidth = Math.Max(measured, cjkRefWidth);
                }
                else {
                    charWidth = font.MeasureString(ch.ToString()).X;
                }

                bool needWrap = currentWidth + charWidth > maxWidth && currentLine.Length > 0;
                if (needWrap) {
                    //超宽拉丁词硬断，避免死循环
                    if (isCJK || isWhite || latinWordStart <= 0) {
                        output.Add(currentLine.ToString().TrimEnd(' '));
                        currentLine.Clear();
                        currentWidth = 0f;
                        latinWordStart = -1;
                        latinWordWidth = 0f;
                        if (isWhite) {
                            continue;
                        }
                    }
                    else {
                        //整词移到下一行
                        string head = currentLine.ToString(0, latinWordStart).TrimEnd(' ');
                        string tail = currentLine.ToString(latinWordStart, currentLine.Length - latinWordStart);
                        output.Add(head);
                        currentLine.Clear();
                        currentLine.Append(tail);
                        currentWidth = latinWordWidth;
                        latinWordStart = 0;
                    }
                }

                currentLine.Append(ch);
                currentWidth += charWidth;

                if (isCJK || isWhite) {
                    latinWordStart = -1;
                    latinWordWidth = 0f;
                }
                else {
                    if (latinWordStart < 0) {
                        latinWordStart = currentLine.Length - 1;
                        latinWordWidth = charWidth;
                    }
                    else {
                        latinWordWidth += charWidth;
                    }
                }
            }

            if (currentLine.Length > 0) {
                output.Add(currentLine.ToString());
            }
        }

        /// <summary>CJK 表意字符判定</summary>
        private static bool IsCJKChar(char c) {
            return c is >= '\u4E00' and <= '\u9FFF'
                or >= '\u3400' and <= '\u4DBF'
                or >= '\u3040' and <= '\u309F'
                or >= '\u30A0' and <= '\u30FF'
                or >= '\uAC00' and <= '\uD7AF'
                or >= '\uFF00' and <= '\uFFEF'
                or >= '\u3000' and <= '\u303F';
        }
        #endregion
    }
}
