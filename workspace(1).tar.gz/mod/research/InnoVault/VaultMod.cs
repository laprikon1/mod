﻿using InnoVault.GameSystem;
using InnoVault.VaultNetworks;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Terraria;
using Terraria.ModLoader;

namespace InnoVault
{
    /// <summary>
    /// 模组的主类
    /// </summary>
    public class VaultMod : Mod
    {
        /// <summary>
        /// 实时获取整个模组的实例
        /// </summary>
        public static VaultMod Instance => (VaultMod)ModLoader.GetMod("InnoVault");
        /// <summary>
        /// 所有继承了<see cref="IVaultLoader"/>接口的类的实例
        /// </summary>
        public static List<IVaultLoader> Loaders { get; private set; } = new List<IVaultLoader>();
        /// <summary>
        /// 用于模组源查找的性能优化，在加载完成后会立即释放
        /// </summary>
        internal static readonly Dictionary<Assembly, HashSet<Type>> ModTypeSetCache = new();
        /// <summary>
        /// 单个模组程序集的可加载类型数组缓存，服务于 <see cref="VaultUtils.GetCodeTypes(Mod)"/>
        /// </summary>
        internal static readonly Dictionary<Assembly, Type[]> ModTypeArrayCache = new();
        /// <summary>
        /// 单个模组程序集的类型简名索引缓存，服务于 <see cref="VaultUtils.FindTypeByName(Mod, string)"/>
        /// </summary>
        internal static readonly Dictionary<Assembly, Dictionary<string, Type>> ModTypeNameCache = new();
        /// <summary>
        /// 用于模组总程序集查找的性能优化，在加载完成后会立即释放
        /// </summary>
        internal static Type[] AnyModCodeType = null;
        /// <summary>
        /// 存储模组内报错时间戳
        /// </summary>
        internal static readonly ConcurrentDictionary<string, DateTime> lastErrorByKey = new();
        /// <summary>
        /// 报错节流冷却间隔
        /// </summary>
        internal const int LogCooldownSeconds = 5;
        /// <inheritdoc/>
        public override void Load() {
            Loaders = VaultUtils.GetDerivedInstances<IVaultLoader>();
            foreach (var loader in Loaders) {
                loader.LoadData();
            }
            VaultLoad.LoadData();
        }

        /// <inheritdoc/>
        public override void PostSetupContent() {
            foreach (var loader in Loaders) {
                loader.SetupData();
            }
            //标签扫描两端都跑：服务器只放行声明了 LoadOnServer 的自定义加载器（骨架定义一类两端共用的数据），
            //贴图 / 音效 / 着色器仍只在客户端加载；IVaultLoader.LoadAsset 保持客户端专属
            VaultLoad.LoadAsset();
            if (!Main.dedServ) {
                foreach (var loader in Loaders) {
                    loader.LoadAsset();
                }
            }
            //完成加载后就释放，防止在游戏周期中占用不必要的内存
            ModTypeSetCache?.Clear();
            ModTypeArrayCache?.Clear();
            ModTypeNameCache?.Clear();
            AnyModCodeType = null;
        }

        /// <inheritdoc/>
        public override void Unload() {
            foreach (var loader in Loaders) {
                loader.UnLoadData();
            }
            Loaders.Clear();
            VaultLoad.UnLoadData();
            VaultLoad.UnLoadAsset();
            TagCache.Clear();
            ModTypeSetCache?.Clear();
            ModTypeArrayCache?.Clear();
            ModTypeNameCache?.Clear();
            AnyModCodeType = null;
            lastErrorByKey?.Clear();
        }

        internal static void LoggerError(string key, string msg) {
            if (lastErrorByKey.TryGetValue(key, out var time)
                && (DateTime.UtcNow - time).TotalSeconds < LogCooldownSeconds) {
                return; //同类错误短时间内忽略
            }
            Instance.Logger.Error(msg);
            lastErrorByKey[key] = DateTime.UtcNow;
        }

        /// <inheritdoc/>
        public override void HandlePacket(BinaryReader reader, int whoAmI) => VaultNetwork.HandlePacket(reader, this, whoAmI);
    }
}
