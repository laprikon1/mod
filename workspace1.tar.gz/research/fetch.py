import urllib.request, json, os, sys
def get(url, timeout=40):
    req = urllib.request.Request(url, headers={'User-Agent':'research'})
    return urllib.request.urlopen(req, timeout=timeout).read()
def tree(owner, repo, branch):
    u = f'https://api.github.com/repos/{owner}/{repo}/git/trees/{branch}?recursive=1'
    d = json.loads(get(u))
    return d
if __name__ == '__main__':
    owner, repo, branch = sys.argv[1], sys.argv[2], sys.argv[3]
    try:
        d = tree(owner, repo, branch)
        paths = [t['path'] for t in d.get('tree',[]) if t['type']=='blob']
        os.makedirs(f'research/{repo}', exist_ok=True)
        open(f'research/{repo}/_tree.txt','w').write('\n'.join(paths))
        print(len(paths), 'files')
        for p in paths:
            if p.endswith(('.cs','.txt','.md','.csproj','.xml','.fx','.json')):
                print(p)
    except Exception as e:
        print('ERR', e)
