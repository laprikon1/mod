﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ParticleLibrary.Core.V3.Interfaces;
using ParticleLibrary.Utilities;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;

namespace ParticleLibrary.Core.V3.Particles
{
	/// <summary>
	/// Creates a new buffer of particles.
	/// </summary>
	/// <typeparam name="TBehavior"></typeparam>
	public class ParticleBuffer<TBehavior> : GeometryBuffer<VertexPositionTexture, ParticleInstance>, IUpdatable, ICreatable<ParticleInfo>
		where TBehavior : Behavior<ParticleInfo>, new()
	{
		/// <summary>
		/// The <see cref="BlendState"/> of this <see cref="ParticleBuffer{TBehavior}"/>.
		/// </summary>
		public BlendState BlendState { get; private set; }

		/// <summary>
		/// The <see cref="SamplerState"/> of this <see cref="ParticleBuffer{TBehavior}"/>.
		/// </summary>
		public SamplerState SamplerState { get; private set; }

		/// <summary>
		/// The <typeparamref name="TBehavior"/> associated with this <see cref="ParticleBuffer{TBehavior}"/>.
		/// </summary>
		public TBehavior Behavior { get; private set; }

		// Geometry
		private static readonly VertexPositionTexture[] _vertices;
		private static readonly short[] _indices;

		// Data
		private readonly int _maxInstances;
		private readonly ParticleInfo[] _infos;
		private readonly ParticleInstance[] _instances;
		private readonly Stack<int> _inactiveInstances;

		private int Count => _maxInstances - _inactiveInstances.Count;

		static ParticleBuffer()
		{
			_vertices = [
				new(new(-0.5f, -0.5f, 0f), Vector2.Zero),
				new(new(-0.5f, 0.5f, 0f), Vector2.UnitY),
				new(new(0.5f, -0.5f, 0f), Vector2.UnitX),
				new(new(0.5f, 0.5f, 0f), Vector2.One)
			];

			_indices = [0, 2, 3, 0, 3, 1];
		}

		public ParticleBuffer(int maxInstances = 256) : base(maxInstances)
		{
			BlendState = BlendState.AlphaBlend;
			SamplerState = SamplerState.PointClamp;

			Behavior = new TBehavior();
			_maxInstances = GetMaxInstances();
			_infos = new ParticleInfo[_maxInstances];
			_instances = new ParticleInstance[_maxInstances];
			_inactiveInstances = new Stack<int>(_maxInstances);

			for (int i = 0; i < _maxInstances; i++)
			{
				ref var info = ref _infos[i];
				info.Free = true;
			}

			for (int i = _maxInstances - 1; i >= 0; i--)
			{
				_inactiveInstances.Push(i);
			}

			var instanceElements = new VertexElement[3];
			instanceElements[0] = new VertexElement(sizeof(float) * 0, VertexElementFormat.Vector4, VertexElementUsage.Normal, 0);
			instanceElements[1] = new VertexElement(sizeof(float) * 4, VertexElementFormat.Vector2, VertexElementUsage.Normal, 1);
			instanceElements[2] = new VertexElement(sizeof(float) * 6, VertexElementFormat.Color, VertexElementUsage.Color, 0);

			Initialize(_vertices, _indices, instanceElements);
		}

		/// <summary>
		/// Updates the particles.
		/// </summary>
		public void Update()
		{
			for (int i = 0; i < _infos.Length; i++)
			{
				var particle = _infos[i];
				if (particle.Time <= 0)
				{
					if (!particle.Free)
					{
						_infos[i].Free = true;
						_inactiveInstances.Push(i);
						_instances[i].Color = Color.Transparent;
					}

					continue;
				}

				Behavior.Update(ref _infos[i]);

				_instances[i].Position_Scale = new Vector4(particle.Position.X, particle.Position.Y, particle.Scale.X, particle.Scale.Y);
				_instances[i].Rotation_Depth = new Vector2(particle.Rotation, particle.Depth);
				_instances[i].Color = particle.Color;
			}

			// Active instances
			if (Count > 0)
			{
				SetData(_instances);
			}
		}

		/// <summary>
		/// Renders the particles.
		/// </summary>
		public override void Render()
		{
			// No active instances
			if (Count == 0)
			{
				return;
			}

			// Retrieve buffers
			GetBuffers(out VertexBufferBinding[] vertexBuffers, out IndexBuffer indexBuffer);
			var texture = LibUtilities.GetTexture(Behavior.Texture);

			// Set our variables
			Main.graphics.GraphicsDevice.RasterizerState = RasterizerState.CullCounterClockwise;
			Main.graphics.GraphicsDevice.BlendState = BlendState;
			Main.graphics.GraphicsDevice.SamplerStates[0] = SamplerState;
			Main.graphics.GraphicsDevice.SetVertexBuffers(vertexBuffers);
			Main.graphics.GraphicsDevice.Indices = indexBuffer;

			// Apply effect and draw
			Main.graphics.GraphicsDevice.Textures[0] = texture;
			ParticleManagerV3.InstancedParticleEffect.Apply();
			Main.graphics.GraphicsDevice.DrawInstancedPrimitives(PrimitiveType.TriangleList, 0, 0, _vertices.Length, 0, _vertices.Length / 2, _maxInstances);
		}

		/// <summary>
		/// Creates a new particle from the given info.
		/// </summary>
		/// <param name="info">The info.</param>
		public void Create(ParticleInfo info)
		{
			// Don't create particles on the server.
			if (Main.netMode is NetmodeID.Server)
			{
				return;
			}

			// Active instances.
			if (Count == _maxInstances)
			{
				return;
			}

			// Create instance.
			int index = _inactiveInstances.Pop();
			var instance = new ParticleInstance
			{
				Position_Scale = new Vector4(info.Position.X, info.Position.Y, info.Scale.X, info.Scale.Y),
				Rotation_Depth = new Vector2(info.Rotation, info.Depth),
				Color = info.InitialColor
			};
			
			// Initialize info.
			Behavior.Initialize(ref info);

			// Add to buffer.
			_infos[index] = info;
			_instances[index] = instance;
		}

		public ParticleBuffer<TBehavior> SetBlendState(BlendState blendState)
		{
			if (blendState is null)
			{
				return this;
			}

			BlendState = blendState;
			return this;
		}

		public ParticleBuffer<TBehavior> SetSamplerState(SamplerState samplerState)
		{
			if (samplerState is null)
			{
				return this;
			}

			SamplerState = samplerState;
			return this;
		}
	}
}
