using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using NovaChord.Common.Core;
using Terraria;
using Terraria.GameContent;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;

namespace NovaChord.Common.UI
{
    /// <summary>
    ///     The cadence HUD: attunement chip, Tempo pips, the Finale gauge and the
    ///     constellation-draw banner. Inserted just below the mouse text layer and
    ///     fully governed by the client's interface config.
    /// </summary>
    public sealed class CadenceHUD : ModSystem
    {
        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            int index = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Mouse Text"));
            if (index != -1)
                layers.Insert(index, new LegacyGameInterfaceLayer("NovaChord: Cadence HUD", DrawHud, InterfaceScaleType.UI));
        }

        private static bool DrawHud()
        {
            NovaChordConfig config = NovaChordConfig.Instance;
            if (Main.dedServ || Main.gameMenu || !config.ShowHud)
                return true;

            Player player = Main.LocalPlayer;
            CadencePlayer cadence = player.GetModPlayer<CadencePlayer>();
            bool visible = cadence.HoldingBow || cadence.FinaleGauge > 0f || cadence.FinaleActive
                || cadence.TempoStacks > 0 || cadence.IsDrawing;
            if (!visible || player.dead)
                return true;

            float scale = config.HudScale;
            float centerX = Main.screenWidth * 0.5f;
            float baseY = Main.screenHeight - 116f * scale + config.HudVerticalOffset;
            SpriteBatch sb = Main.spriteBatch;
            Texture2D pixel = TextureAssets.MagicPixel.Value;
            Color primary = cadence.Attunement.Primary();
            Color secondary = cadence.Attunement.Secondary();

            // ---- Attunement chip ------------------------------------------------------
            Texture2D glow = NovaChordAssets.SoftGlow.Value;
            Vector2 chipPos = new(centerX - 168f * scale, baseY + 6f * scale);
            sb.Draw(glow, chipPos, null, primary * 0.9f, 0f, glow.Size() * 0.5f, 0.5f * scale, SpriteEffects.None, 0f);
            string attunementName = Language.GetTextValue(cadence.Attunement.NameKey());
            Utils.DrawBorderString(sb, attunementName, chipPos + new Vector2(18f * scale, -8f * scale), primary, scale * 0.9f);
            Utils.DrawBorderString(sb, "[V]", chipPos + new Vector2(18f * scale, 8f * scale), Color.Gray, scale * 0.7f);

            // ---- Tempo pips -----------------------------------------------------------
            Texture2D star = NovaChordAssets.StarSpark.Value;
            for (int i = 0; i < CadencePlayer.TempoCap; i++)
            {
                Vector2 pos = new(centerX - 40f * scale + i * 20f * scale, baseY - 14f * scale);
                Color color = i < cadence.TempoStacks ? secondary : Color.White * 0.18f;
                sb.Draw(star, pos, null, color, 0f, star.Size() * 0.5f, 0.32f * scale, SpriteEffects.None, 0f);
            }

            // ---- Finale gauge ---------------------------------------------------------
            float barWidth = 240f * scale;
            float barHeight = 12f * scale;
            Vector2 barPos = new(centerX - barWidth * 0.5f, baseY + 4f * scale);
            sb.Draw(pixel, barPos, null, Color.Black * 0.6f, 0f, Vector2.Zero, new Vector2(barWidth, barHeight), SpriteEffects.None, 0f);

            float fill = cadence.FinaleGauge / CadencePlayer.GaugeMax;
            if (fill > 0f)
            {
                Color fillColor = Color.Lerp(primary, secondary, fill);
                sb.Draw(pixel, barPos, null, fillColor * 0.95f, 0f, Vector2.Zero, new Vector2(barWidth * fill, barHeight), SpriteEffects.None, 0f);
            }
            // Border.
            sb.Draw(pixel, barPos - Vector2.One, null, Color.White * 0.35f, 0f, Vector2.Zero, new Vector2(barWidth + 2f, 1f), SpriteEffects.None, 0f);
            sb.Draw(pixel, barPos + new Vector2(0f, barHeight), null, Color.White * 0.35f, 0f, Vector2.Zero, new Vector2(barWidth + 2f, 1f), SpriteEffects.None, 0f);

            if (cadence.FinaleGauge >= CadencePlayer.GaugeMax && !cadence.FinaleActive)
            {
                float pulse = 0.6f + 0.4f * MathHelper.Lerp(0f, 1f, (Main.GameUpdateCount % 40) / 40f);
                string ready = Language.GetTextValue("Mods.NovaChord.UI.FinaleReady");
                Utils.DrawBorderString(sb, ready, new Vector2(centerX, baseY + 26f * scale), secondary * pulse, scale, 0.5f);
            }

            // ---- Perfect flash --------------------------------------------------------
            if (cadence.PerfectFlashTimer > 0)
            {
                float alpha = cadence.PerfectFlashTimer / 22f;
                string perfect = Language.GetTextValue("Mods.NovaChord.UI.Perfect");
                Utils.DrawBorderString(sb, perfect, new Vector2(centerX, baseY - 34f * scale), secondary * alpha, scale * 1.1f, 0.5f);
            }

            // ---- Constellation draw banner --------------------------------------------
            if (config.ShowFinaleBanner && cadence.FinaleBannerTimer > 0)
                DrawBanner(sb, cadence, scale);

            return true;
        }

        private static void DrawBanner(SpriteBatch sb, CadencePlayer cadence, float scale)
        {
            float t = cadence.FinaleBannerTimer / 150f;
            float alpha = t > 0.85f ? (1f - t) / 0.15f : (t < 0.2f ? t / 0.2f : 1f);
            float pop = 1f + 0.25f * t;

            string rarityKey = cadence.FinaleRarity switch
            {
                CadenceRarity.Rare => "Mods.NovaChord.UI.RarityRare",
                CadenceRarity.Legendary => "Mods.NovaChord.UI.RarityLegendary",
                _ => "Mods.NovaChord.UI.RarityCommon"
            };
            Color rarityColor = cadence.FinaleRarity switch
            {
                CadenceRarity.Rare => new Color(150, 200, 255),
                CadenceRarity.Legendary => new Color(255, 214, 120),
                _ => Color.White
            };

            Vector2 center = new(Main.screenWidth * 0.5f, 130f);
            string title = Language.GetTextValue("Mods.NovaChord.UI.ConstellationDraw");
            Utils.DrawBorderString(sb, title, center - new Vector2(0f, 26f), Color.White * alpha, scale * 0.9f, 0.5f);

            string rarity = Language.GetTextValue(rarityKey);
            SpriteFont font = FontAssets.DeathText.Value;
            Vector2 size = font.MeasureString(rarity) * pop;
            Vector2 pos = center - size * 0.5f + new Vector2(0f, 14f);
            sb.DrawString(font, rarity, pos + new Vector2(2f, 2f), Color.Black * alpha, 0f, Vector2.Zero, pop, SpriteEffects.None, 0f);
            sb.DrawString(font, rarity, pos, rarityColor * alpha, 0f, Vector2.Zero, pop, SpriteEffects.None, 0f);
        }
    }
}
