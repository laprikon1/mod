using Microsoft.Xna.Framework;
using Luminance.Core.Graphics;
using Terraria;

namespace NovaChord.Common.Core
{
    /// <summary>
    ///     Thin wrapper over Luminance's screen shake that honours the client's visual config.
    ///     All camera work in the mod goes through here so the sliders stay meaningful.
    /// </summary>
    public static class CadenceCamera
    {
        public static void Shake(Vector2 center, float strength)
        {
            NovaChordConfig config = NovaChordConfig.Instance;
            if (Main.dedServ || !config.ScreenShake || !config.CameraEffects)
                return;

            float scaled = strength * config.ScreenEffectStrength;
            if (scaled <= 0f)
                return;

            ScreenShakeSystem.StartShakeAtPoint(center, scaled, MathHelper.TwoPi, null, 0.4f, 1400f, 300f);
        }
    }
}
