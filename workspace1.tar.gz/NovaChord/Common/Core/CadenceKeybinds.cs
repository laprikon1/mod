using Terraria.ModLoader;

namespace NovaChord.Common.Core
{
    /// <summary>Hotkeys for attunement swapping and the Finale ultimate.</summary>
    public sealed class CadenceKeybinds : ModSystem
    {
        public static ModKeybind CycleAttunement;
        public static ModKeybind Finale;

        public override void Load()
        {
            CycleAttunement = KeybindLoader.RegisterKeybind(Mod, "CycleAttunement", "V");
            Finale = KeybindLoader.RegisterKeybind(Mod, "StarfallFinale", "B");
        }

        public override void Unload()
        {
            CycleAttunement = null;
            Finale = null;
        }
    }
}
