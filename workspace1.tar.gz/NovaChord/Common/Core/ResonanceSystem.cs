using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using NovaChord.Content.Buffs;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Common.Core
{
    /// <summary>
    ///     Server-authoritative elemental resonance: mark stacking, overflow bursts and the
    ///     tiny visual protocol that lets every client see (and hear) the results.
    ///     In single player the "server" and "client" halves run back to back.
    /// </summary>
    public sealed class ResonanceSystem : ModSystem
    {
        private const byte KindBurst = 0;
        private const byte KindChain = 1;
        private const byte KindBloom = 2;
        private const byte KindMarkUpdate = 3;
        private const byte KindGauge = 4;

        private const float OverflowBaseDamage = 120f;
        private const float OverflowRadius = 160f;
        private const float ChainRadius = 240f;
        private const int ChainTargets = 4;

        // ---- Server side: marks & overflows -------------------------------------------
        /// <summary>Applies one stack of the attunement's mark; triggers an overflow at the cap.</summary>
        public static void ApplyMark(NPC npc, Attunement attunement, Player owner)
        {
            if (Main.netMode == NetmodeID.MultiplayerClient || !npc.active || npc.life <= 0 || npc.dontTakeDamage)
                return;

            ResonanceGlobalNPC global = npc.GetGlobalNPC<ResonanceGlobalNPC>();
            int index = (int)attunement;
            global.MarkStacks[index]++;
            global.MarkTimers[index] = AttunementData.MarkDuration;
            npc.AddBuff(attunement.MarkBuff(), AttunementData.MarkDuration);
            SendMarkUpdate(npc.whoAmI, attunement, global.MarkStacks[index]);

            if (global.MarkStacks[index] >= AttunementData.MarkCap)
            {
                global.MarkStacks[index] = 0;
                global.MarkTimers[index] = 0;
                Overflow(npc, attunement, owner);
            }
        }

        private static void Overflow(NPC npc, Attunement attunement, Player owner)
        {
            int damage = (int)owner.GetDamage(DamageClass.Ranged).ApplyTo(OverflowBaseDamage);
            Vector2 center = npc.Center;

            switch (attunement)
            {
                case Attunement.Glacial:
                    foreach (NPC other in Main.ActiveNPCs)
                    {
                        if (!other.CanBeChasedBy() || other.Center.Distance(center) > OverflowRadius)
                            continue;
                        other.SimpleStrikeNPC(damage, 0, false, 0f, DamageClass.Ranged);
                        if (!other.boss)
                            other.AddBuff(BuffID.Frozen, 45);
                        else
                            other.GetGlobalNPC<ResonanceGlobalNPC>().BossDampTimer = 30;
                    }
                    SendBurst(attunement, center, owner);
                    break;

                case Attunement.Voltaic:
                    npc.SimpleStrikeNPC(damage, 0, false, 0f, DamageClass.Ranged);
                    List<Vector2> chain = new();
                    NPC current = npc;
                    HashSet<int> hit = new() { npc.whoAmI };
                    for (int i = 0; i < ChainTargets; i++)
                    {
                        NPC next = null;
                        float best = ChainRadius;
                        foreach (NPC other in Main.ActiveNPCs)
                        {
                            if (!other.CanBeChasedBy() || hit.Contains(other.whoAmI))
                                continue;
                            float dist = other.Center.Distance(current.Center);
                            if (dist < best)
                            {
                                best = dist;
                                next = other;
                            }
                        }
                        if (next is null)
                            break;
                        hit.Add(next.whoAmI);
                        next.SimpleStrikeNPC((int)(damage * 0.6f), 0, false, 0f, DamageClass.Ranged);
                        chain.Add(next.Center);
                        current = next;
                    }
                    SendChain(center, chain, owner);
                    break;

                case Attunement.Verdant:
                    foreach (NPC other in Main.ActiveNPCs)
                    {
                        if (!other.CanBeChasedBy() || other.Center.Distance(center) > OverflowRadius * 0.8f)
                            continue;
                        other.SimpleStrikeNPC((int)(damage * 0.6f), 0, false, 0f, DamageClass.Ranged);
                    }
                    int heal = 4;
                    owner.statLife = Math.Min(owner.statLife + heal, owner.statLifeMax2);
                    owner.HealEffect(heal, true);
                    SendBloom(center, owner.whoAmI, owner);
                    break;
            }

            owner.GetModPlayer<CadencePlayer>().AddGauge(CadencePlayer.OverflowGaugeGain);
        }

        // ---- Server -> client visual protocol ------------------------------------------
        private static ModPacket NewPacket(byte kind)
        {
            ModPacket packet = ModContent.GetInstance<NovaChord>().GetPacket();
            packet.Write((byte)NovaChord.Packet.ResonanceVisual);
            packet.Write(kind);
            return packet;
        }

        private static void SendBurst(Attunement attunement, Vector2 center, Player owner)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = NewPacket(KindBurst);
                packet.Write((byte)attunement);
                packet.WriteVector2(center);
                packet.Send();
            }
            else
            {
                ClientBurst(attunement, center);
            }
        }

        private static void SendChain(Vector2 center, List<Vector2> targets, Player owner)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = NewPacket(KindChain);
                packet.WriteVector2(center);
                packet.Write((byte)targets.Count);
                foreach (Vector2 target in targets)
                    packet.WriteVector2(target);
                packet.Send();
            }
            else
            {
                ClientChain(center, targets);
            }
        }

        private static void SendBloom(Vector2 center, int ownerIndex, Player owner)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = NewPacket(KindBloom);
                packet.WriteVector2(center);
                packet.Write((byte)ownerIndex);
                packet.Send();
            }
            else
            {
                ClientBloom(center, ownerIndex);
            }
        }

        private static void SendMarkUpdate(int npcIndex, Attunement attunement, int stacks)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = NewPacket(KindMarkUpdate);
                packet.Write((ushort)npcIndex);
                packet.Write((byte)attunement);
                packet.Write((byte)stacks);
                packet.Send();
            }
            else
            {
                ClientMarkUpdate(npcIndex, attunement, stacks);
            }
        }

        /// <summary>Pushes the authoritative Finale gauge to the owning client.</summary>
        public static void SendGauge(int ownerIndex, float gauge)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = NewPacket(KindGauge);
                packet.Write((byte)ownerIndex);
                packet.Write(gauge);
                packet.Send();
            }
            else
            {
                Main.player[ownerIndex].GetModPlayer<CadencePlayer>().FinaleGauge = gauge;
            }
        }

        /// <summary>Handle a ResonanceVisual packet on a client.</summary>
        public static void ReceiveVisual(BinaryReader reader)
        {
            byte kind = reader.ReadByte();
            switch (kind)
            {
                case KindBurst:
                    ClientBurst((Attunement)reader.ReadByte(), reader.ReadVector2());
                    break;
                case KindChain:
                {
                    Vector2 center = reader.ReadVector2();
                    int count = reader.ReadByte();
                    List<Vector2> targets = new(count);
                    for (int i = 0; i < count; i++)
                        targets.Add(reader.ReadVector2());
                    ClientChain(center, targets);
                    break;
                }
                case KindBloom:
                    ClientBloom(reader.ReadVector2(), reader.ReadByte());
                    break;
                case KindMarkUpdate:
                    ClientMarkUpdate(reader.ReadUInt16(), (Attunement)reader.ReadByte(), reader.ReadByte());
                    break;
                case KindGauge:
                {
                    int ownerIndex = reader.ReadByte();
                    Main.player[ownerIndex].GetModPlayer<CadencePlayer>().FinaleGauge = reader.ReadSingle();
                    break;
                }
            }
        }

        // ---- Client side: particles, sound, camera --------------------------------------
        private static void ClientBurst(Attunement attunement, Vector2 center)
        {
            CadenceParticles.Burst(center, attunement.Primary(), 26, 7f, 18f, 34);
            CadenceParticles.Burst(center, attunement.Secondary(), 12, 4f, 12f, 26);
            SoundStyle sound = attunement switch
            {
                Attunement.Glacial => SoundID.Item27,
                Attunement.Voltaic => SoundID.Item93,
                _ => SoundID.Item4
            };
            SoundEngine.PlaySound(sound with { Volume = 0.8f }, center);
            CadenceCamera.Shake(center, 7f);
        }

        private static void ClientChain(Vector2 center, List<Vector2> targets)
        {
            Color color = Attunement.Voltaic.Primary();
            Vector2 previous = center;
            CadenceParticles.Burst(center, color, 18, 6f, 16f, 30);
            foreach (Vector2 target in targets)
            {
                // Spark along each link so the chain reads as lightning.
                int steps = Math.Max(2, (int)(previous.Distance(target) / 24f));
                for (int i = 0; i <= steps; i++)
                {
                    Vector2 point = Vector2.Lerp(previous, target, i / (float)steps);
                    CadenceParticles.Spark(point, Main.rand.NextVector2Circular(1.5f, 1.5f), color, 12f, 20, Main.rand.NextFloat(-0.3f, 0.3f));
                }
                CadenceParticles.Burst(target, color, 10, 4f, 12f, 24);
                previous = target;
            }
            SoundEngine.PlaySound(SoundID.Item93 with { Volume = 0.85f, Pitch = 0.2f }, center);
            CadenceCamera.Shake(center, 6f);
        }

        private static void ClientBloom(Vector2 center, int ownerIndex)
        {
            Color color = Attunement.Verdant.Primary();
            CadenceParticles.Burst(center, color, 22, 5f, 16f, 36);
            for (int i = 0; i < 10; i++)
                CadenceParticles.Mote(center + Main.rand.NextVector2Circular(40f, 40f), Main.rand.NextVector2Circular(1f, 1f), color, 12f, 80);
            SoundEngine.PlaySound(SoundID.Item4 with { Volume = 0.7f, Pitch = 0.3f }, center);
        }

        private static void ClientMarkUpdate(int npcIndex, Attunement attunement, int stacks)
        {
            if (npcIndex < 0 || npcIndex >= Main.maxNPCs)
                return;
            NPC npc = Main.npc[npcIndex];
            if (!npc.active)
                return;
            ResonanceGlobalNPC global = npc.GetGlobalNPC<ResonanceGlobalNPC>();
            global.MarkStacks[(int)attunement] = stacks;
        }
    }
}
