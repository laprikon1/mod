using System.ComponentModel;
using Terraria.ModLoader;
using Terraria.ModLoader.Config;

namespace NovaChord.Common.Core
{
    /// <summary>Client side presentation settings. Nothing here changes gameplay balance.</summary>
    public sealed class NovaChordConfig : ModConfig
    {
        public override ConfigScope Mode => ConfigScope.ClientSide;

        public static NovaChordConfig Instance => ModContent.GetInstance<NovaChordConfig>();

        [Header("Visuals")]
        [Range(0f, 1f)]
        [Increment(0.05f)]
        [Slider]
        [DefaultValue(0.8f)]
        public float ScreenEffectStrength;

        [Range(0.25f, 2f)]
        [Increment(0.25f)]
        [Slider]
        [DefaultValue(1f)]
        public float ParticleDensity;

        [DefaultValue(true)]
        public bool CameraEffects;

        [DefaultValue(true)]
        public bool ScreenShake;

        [Header("Interface")]
        [DefaultValue(true)]
        public bool ShowHud;

        [DefaultValue(true)]
        public bool ShowFinaleBanner;

        [Range(0.7f, 1.6f)]
        [Increment(0.1f)]
        [Slider]
        [DefaultValue(1f)]
        public float HudScale;

        [Range(-120f, 120f)]
        [Increment(10f)]
        [Slider]
        [DefaultValue(0f)]
        public float HudVerticalOffset;

        /// <summary>How many particles a burst should emit, respecting the density slider.</summary>
        public int Count(int baseCount)
        {
            int count = (int)(baseCount * ParticleDensity);
            return count < 1 ? 1 : count;
        }
    }
}
