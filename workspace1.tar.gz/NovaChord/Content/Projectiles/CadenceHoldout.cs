using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using NovaChord.Common.Core;
using NovaChord.Content.Items;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Content.Projectiles
{
    /// <summary>
    ///     The drawn bow itself. Lives only while the owner channels Starfall Cadence,
    ///     tracks the cadence charge and fires a Resonance Arrow on release. Ammo is
    ///     consumed here (on release), and a Perfect Draw is detected against the window.
    /// </summary>
    public sealed class CadenceHoldout : ModProjectile
    {
        private int ChargeTimer;

        public override void SetStaticDefaults()
        {
            Main.projFrames[Type] = 1;
        }

        public override void SetDefaults()
        {
            Projectile.width = 26;
            Projectile.height = 52;
            Projectile.aiStyle = 0;
            Projectile.friendly = false;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Ranged;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.timeLeft = 600;
            Projectile.netImportant = true;
            Projectile.penetrate = -1;
        }

        private Player Owner => Main.player[Projectile.owner];

        public override void AI()
        {
            if (!Owner.active || Owner.dead)
            {
                Projectile.Kill();
                return;
            }

            bool ownerClient = Projectile.owner == Main.myPlayer && Main.netMode != NetmodeID.Server;
            if (ownerClient)
                OwnerAI();
            else
                RemoteAI();
        }

        private void OwnerAI()
        {
            CadencePlayer cadence = Owner.GetModPlayer<CadencePlayer>();
            bool drawing = Owner.channel && !Owner.CCed && !Owner.noItems
                && Owner.HeldItem.type == ModContent.ItemType<StarfallCadence>();

            if (!drawing)
            {
                Release(cadence);
                return;
            }

            cadence.IsDrawing = true;
            cadence.DrawTimer = ChargeTimer;

            Vector2 toMouse = Main.MouseWorld - Owner.MountedCenter;
            Vector2 dir = toMouse.SafeNormalize(Vector2.UnitX);
            Projectile.rotation = dir.ToRotation();
            if (Math.Abs(toMouse.X) > 0.01f)
                Owner.direction = Math.Sign(toMouse.X);
            Owner.SetCompositeArmFront(true, Player.CompositeArmStretchAmount.Full, Projectile.rotation - MathHelper.PiOver2);
            Projectile.Center = Owner.MountedCenter + dir * 18f;

            // Ambience while drawing, and a spark the instant the perfect window opens.
            if (ChargeTimer % 4 == 0)
                CadenceParticles.Mote(Projectile.Center + dir * 22f, dir * 0.6f, cadence.Attunement.Primary(), 8f, 40);
            if (ChargeTimer == CadencePlayer.PerfectStart)
                CadenceParticles.Spark(Projectile.Center + dir * 24f, dir * 2f, Color.White, 16f, 18);

            ChargeTimer++;
            if (ChargeTimer >= CadencePlayer.MaxDraw)
            {
                Release(cadence);
                return;
            }

            if (Main.netMode == NetmodeID.MultiplayerClient && ChargeTimer % 6 == 0)
                Projectile.netUpdate = true;
        }

        private void RemoteAI()
        {
            Projectile.Center = Owner.MountedCenter + Projectile.rotation.ToRotationVector2() * 18f;
        }

        private void Release(CadencePlayer cadence)
        {
            cadence.IsDrawing = false;
            cadence.DrawTimer = 0;

            if (ChargeTimer < CadencePlayer.MinDraw)
            {
                SoundEngine.PlaySound(SoundID.Item5 with { Volume = 0.25f, Pitch = -0.4f }, Projectile.Center);
                Projectile.Kill();
                return;
            }

            // Find the first arrow in the inventory (vanilla ammo order).
            Item ammo = null;
            foreach (Item item in Owner.inventory)
            {
                if (item is not null && item.stack > 0 && item.ammo == AmmoID.Arrow)
                {
                    ammo = item;
                    break;
                }
            }
            if (ammo is null)
            {
                Projectile.Kill();
                return;
            }

            bool perfect = ChargeTimer >= CadencePlayer.PerfectStart && ChargeTimer <= cadence.PerfectWindowEnd;
            float power;
            if (ChargeTimer < CadencePlayer.PerfectStart)
                power = MathHelper.Lerp(0.45f, 1f, (ChargeTimer - CadencePlayer.MinDraw) / (float)(CadencePlayer.PerfectStart - CadencePlayer.MinDraw));
            else if (perfect)
                power = 1f;
            else
                power = MathHelper.Lerp(1f, 0.8f, MathHelper.Clamp((ChargeTimer - cadence.PerfectWindowEnd) / (float)(CadencePlayer.MaxDraw - cadence.PerfectWindowEnd), 0f, 1f));

            Item bow = Owner.HeldItem;
            float multiplier = power * (perfect ? 1.35f : 1f);
            int damage = (int)(Owner.GetDamage(DamageClass.Ranged).ApplyTo(bow.damage + ammo.damage) * multiplier);
            float knockback = bow.knockBack + ammo.knockBack;

            Vector2 dir = Projectile.rotation.ToRotationVector2();
            float speed = (bow.shootSpeed + ammo.shootSpeed * 0.5f) * (0.8f + 0.4f * power) * (perfect ? 1.12f : 1f);
            Vector2 spawn = Projectile.Center + dir * 22f;

            float ai0 = power * 100f;
            float ai1 = (float)cadence.Attunement + (perfect ? 10f : 0f);
            Projectile.NewProjectile(Owner.GetSource_ItemUse(bow), spawn, dir * speed,
                ModContent.ProjectileType<ResonanceArrow>(), damage, knockback, Owner.whoAmI, ai0, ai1);

            // Encore (active Finale) makes draws free.
            if (!cadence.FinaleActive)
            {
                ammo.stack--;
                if (ammo.stack <= 0)
                    ammo.TurnToAir();
            }

            SoundEngine.PlaySound(SoundID.Item5 with { Volume = 0.7f, Pitch = 0.1f + power * 0.3f }, Projectile.Center);
            if (perfect)
                cadence.OnPerfectRelease();

            Owner.itemTime = Owner.itemAnimation = 14;
            Projectile.Kill();
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D bow = NovaChordAssets.Holdout.Value;
            Vector2 drawPos = Projectile.Center - Main.screenPosition;
            Vector2 origin = bow.Size() * 0.5f;
            CadencePlayer cadence = Owner.GetModPlayer<CadencePlayer>();

            float pulse = 1f;
            if (Projectile.owner == Main.myPlayer)
                pulse = 1f + 0.05f * MathF.Sin(ChargeTimer * 0.3f);

            SpriteEffects effects = Projectile.rotation is > MathHelper.PiOver2 or < -MathHelper.PiOver2
                ? SpriteEffects.FlipVertically : SpriteEffects.None;

            Main.spriteBatch.Draw(bow, drawPos, null, lightColor, Projectile.rotation + MathHelper.PiOver2, origin, pulse, effects, 0f);

            // Owner-only cadence ring around the archer.
            if (Projectile.owner == Main.myPlayer && Main.netMode != NetmodeID.Server)
                DrawCadenceRing(cadence);

            return false;
        }

        private void DrawCadenceRing(CadencePlayer cadence)
        {
            Vector2 center = Owner.MountedCenter - Main.screenPosition;
            float progress = MathHelper.Clamp(ChargeTimer / (float)CadencePlayer.MaxDraw, 0f, 1f);
            bool inWindow = ChargeTimer >= CadencePlayer.PerfectStart && ChargeTimer <= cadence.PerfectWindowEnd;
            Color primary = cadence.Attunement.Primary();

            Texture2D ring = NovaChordAssets.HaloRing.Value;
            Vector2 ringOrigin = ring.Size() * 0.5f;
            float ringScale = 72f / ring.Width;
            Main.spriteBatch.Draw(ring, center, null, primary * (0.25f + 0.45f * progress), 0f, ringOrigin, ringScale, SpriteEffects.None, 0f);

            // Window boundary ticks.
            Texture2D glow = NovaChordAssets.SoftGlow.Value;
            Vector2 glowOrigin = glow.Size() * 0.5f;
            float radius = 36f;
            DrawRingDot(glow, glowOrigin, center, radius, CadencePlayer.PerfectStart, cadence.Attunement.Secondary() * 0.8f, 0.28f);
            DrawRingDot(glow, glowOrigin, center, radius, cadence.PerfectWindowEnd, cadence.Attunement.Secondary() * 0.8f, 0.28f);

            // Moving charge marker.
            float angle = -MathHelper.PiOver2 + MathHelper.TwoPi * progress;
            Vector2 marker = center + angle.ToRotationVector2() * radius;
            Color markerColor = inWindow ? Color.White : primary;
            Main.spriteBatch.Draw(glow, marker, null, markerColor, 0f, glowOrigin, inWindow ? 0.4f : 0.3f, SpriteEffects.None, 0f);
        }

        private static void DrawRingDot(Texture2D texture, Vector2 origin, Vector2 center, float radius, int tick, Color color, float scale)
        {
            float angle = -MathHelper.PiOver2 + MathHelper.TwoPi * (tick / (float)CadencePlayer.MaxDraw);
            Vector2 pos = center + angle.ToRotationVector2() * radius;
            Main.spriteBatch.Draw(texture, pos, null, color, 0f, origin, scale, SpriteEffects.None, 0f);
        }
    }
}
