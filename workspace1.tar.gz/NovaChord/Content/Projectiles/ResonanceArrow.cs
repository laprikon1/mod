using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Luminance.Core.Graphics;
using NovaChord.Common.Core;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Content.Projectiles
{
    /// <summary>
    ///     The cadence arrow. Carries its charge power and attunement in ai[] so the
    ///     server can apply the right mark on hit. Perfect shots glow brighter and hit harder.
    /// </summary>
    public sealed class ResonanceArrow : ModProjectile
    {
        private float Power => Projectile.ai[0] / 100f;
        private Attunement Attunement => (Attunement)((int)Projectile.ai[1] % 10);
        private bool Perfect => Projectile.ai[1] >= 10f;

        public override void SetStaticDefaults()
        {
            Main.projFrames[Type] = 1;
            ProjectileID.Sets.TrailCacheLength[Type] = 14;
            ProjectileID.Sets.TrailingMode[Type] = 2;
        }

        public override void SetDefaults()
        {
            Projectile.width = 10;
            Projectile.height = 10;
            Projectile.aiStyle = 0;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Ranged;
            Projectile.penetrate = 1;
            Projectile.timeLeft = 300;
            Projectile.tileCollide = true;
            Projectile.ignoreWater = true;
            Projectile.extraUpdates = 1;
            Projectile.arrow = true;
        }

        public override void AI()
        {
            // A gentle drop after the arrow has flown a while; keeps long shots honest.
            if (Projectile.timeLeft < 260)
                Projectile.velocity.Y += 0.025f;

            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver2;

            if (Main.rand.NextBool(3))
            {
                Color color = Perfect ? Attunement.Secondary() : Attunement.Primary();
                CadenceParticles.Spark(Projectile.Center, -Projectile.velocity * 0.05f + Main.rand.NextVector2Circular(0.6f, 0.6f), color, Perfect ? 12f : 9f, 18);
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            Player owner = Main.player[Projectile.owner];
            ResonanceSystem.ApplyMark(target, Attunement, owner);
            owner.GetModPlayer<CadencePlayer>().AddGauge(CadencePlayer.HitGaugeGain);

            if (Main.netMode != NetmodeID.Server)
            {
                CadenceParticles.Burst(target.Center, Attunement.Primary(), Perfect ? 14 : 8, 4f, 12f, 24);
                if (Perfect)
                    SoundEngine.PlaySound(SoundID.Item29 with { Volume = 0.4f, Pitch = 0.7f }, target.Center);
            }
        }

        public override void OnKill(int timeLeft)
        {
            if (Main.netMode != NetmodeID.Server)
            {
                CadenceParticles.Burst(Projectile.Center, Attunement.Primary(), 6, 2.5f, 9f, 18);
                SoundEngine.PlaySound(SoundID.Item5 with { Volume = 0.3f, Pitch = 0.5f }, Projectile.Center);
            }
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Color primary = Attunement.Primary();
            float width = Perfect ? 12f : 8f;

            PrimitiveSettings settings = new(
                interpolant => width * (1f - interpolant) * (0.5f + Power * 0.5f),
                interpolant => primary * (1f - interpolant) * (Perfect ? 0.9f : 0.6f),
                smoothen: true);
            PrimitiveRenderer.RenderTrail(TrailCenters(), settings);

            Texture2D texture = TextureAssets.Projectile[Type].Value;
            Vector2 origin = texture.Size() * 0.5f;
            Vector2 drawPos = Projectile.Center - Main.screenPosition;
            Main.spriteBatch.Draw(texture, drawPos, null, lightColor, Projectile.rotation, origin, 1f, SpriteEffects.None, 0f);
            // Additive pass for the elemental glow.
            Main.spriteBatch.Draw(texture, drawPos, null, primary * (Perfect ? 0.7f : 0.4f), Projectile.rotation, origin, 1.05f, SpriteEffects.None, 0f);
            return false;
        }

        private IEnumerable<Vector2> TrailCenters()
        {
            Vector2 offset = Projectile.Size * 0.5f;
            foreach (Vector2 pos in Projectile.oldPos)
            {
                if (pos != Vector2.Zero)
                    yield return pos + offset;
            }
        }
    }
}
