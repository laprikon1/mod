using NovaChord.Common.Core;
using Terraria;
using Terraria.ModLoader;

namespace NovaChord.Content.Buffs
{
    /// <summary>
    ///     Gained by releasing a Perfect Draw. Stacks up to 5 (tracked by CadencePlayer);
    ///     each stack grants +4% ranged damage and +2% ranged attack speed.
    /// </summary>
    public sealed class Tempo : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            CadencePlayer cadence = player.GetModPlayer<CadencePlayer>();
            if (cadence.TempoStacks <= 0 || cadence.TempoTimer <= 0)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
                return;
            }

            cadence.TempoTimer--;
        }
    }
}
